"""backtest-core: quant / cnn / goal 三仓库共享的回测核心。"""

__version__ = "0.1.1"
