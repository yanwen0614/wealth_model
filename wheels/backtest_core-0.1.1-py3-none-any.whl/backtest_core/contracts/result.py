"""评估结果契约（规格 §10/§13）：三层指标命名空间隔离 + 口径元数据 + 版本溯源。"""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Literal

from .account import AccountSnapshot
from .events import TradeEvent
from .order import OrderResult
from .validation import ensure_finite, ensure_non_empty_str

__all__ = [
    "SCHEMA_VERSION",
    "AnnualizationBasis",
    "EvaluationResult",
    "FinalMarkPolicy",
    "MaxDrawdownSign",
    "MetricMethodology",
    "WinRateDefinition",
]

SCHEMA_VERSION = "1.3"

AnnualizationBasis = Literal["trading_days", "calendar_days"]
MaxDrawdownSign = Literal["positive"]
WinRateDefinition = Literal["daily_return", "closed_position"]
FinalMarkPolicy = Literal["last_close", "liquidation", "exclude"]


def _ensure_literal_member(value: str, allowed: tuple[str, ...], field_name: str) -> None:
    """拒绝 Literal 口径之外的值：口径字段必须显式失败，禁止静默归一为默认值。"""
    if value not in allowed:
        allowed_text = ", ".join(repr(item) for item in allowed)
        raise ValueError(f"{field_name} must be one of ({allowed_text}), got {value!r}")


@dataclass(frozen=True)
class MetricMethodology:
    """指标口径元数据：两个结果的数值可比性完全由本声明决定（规格 §13 evaluation 组）。"""

    annualization_basis: AnnualizationBasis = "trading_days"
    trading_days_per_year: int = 242
    risk_free_rate_annual: float = 0.02
    sharpe_ddof: int = 1
    max_drawdown_sign: MaxDrawdownSign = "positive"
    win_rate_definition: WinRateDefinition = "daily_return"
    final_mark_policy: FinalMarkPolicy = "liquidation"

    def __post_init__(self) -> None:
        _ensure_literal_member(self.annualization_basis, ("trading_days", "calendar_days"), "annualization_basis")
        if (
            isinstance(self.trading_days_per_year, bool)
            or not isinstance(self.trading_days_per_year, int)
            or self.trading_days_per_year < 1
        ):
            raise ValueError(f"trading_days_per_year must be a positive int, got {self.trading_days_per_year!r}")
        ensure_finite(self.risk_free_rate_annual, "risk_free_rate_annual")
        if isinstance(self.sharpe_ddof, bool) or not isinstance(self.sharpe_ddof, int) or self.sharpe_ddof not in (0, 1):
            raise ValueError(f"sharpe_ddof must be 0 or 1, got {self.sharpe_ddof!r}")
        _ensure_literal_member(self.max_drawdown_sign, ("positive",), "max_drawdown_sign")
        _ensure_literal_member(self.win_rate_definition, ("daily_return", "closed_position"), "win_rate_definition")
        _ensure_literal_member(self.final_mark_policy, ("last_close", "liquidation", "exclude"), "final_mark_policy")


def _checked_metrics(values: Mapping[str, float], field_name: str) -> dict[str, float]:
    """校验并复制指标映射：NaN/inf 与空键在构造期拒绝，外部 dict 突变不影响结果。"""
    if not isinstance(values, Mapping):
        raise ValueError(f"{field_name} must be a mapping, got {values!r}")  # noqa: TRY004
    checked: dict[str, float] = {}
    for key, value in values.items():
        ensure_non_empty_str(key, f"{field_name} key")
        ensure_finite(value, f"{field_name}[{key!r}]")
        checked[key] = float(value)
    return checked


def _checked_skipped_counts(values: Mapping[str, int], field_name: str) -> dict[str, int]:
    if not isinstance(values, Mapping):
        raise ValueError(f"{field_name} must be a mapping, got {values!r}")  # noqa: TRY004
    checked: dict[str, int] = {}
    for key, value in values.items():
        ensure_non_empty_str(key, f"{field_name} key")
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{field_name}[{key!r}] must be a non-negative int, got {value!r}")
        checked[key] = value
    return checked


def _checked_provenance(values: Mapping[str, str]) -> dict[str, str]:
    if not isinstance(values, Mapping):
        raise ValueError(f"provenance must be a mapping, got {values!r}")  # noqa: TRY004
    checked: dict[str, str] = {}
    for key, value in values.items():
        ensure_non_empty_str(key, "provenance key")
        ensure_non_empty_str(value, f"provenance[{key!r}]")
        checked[key] = value
    return checked


def _check_trades(trades: Sequence[TradeEvent]) -> None:
    """只校验序列形状与元素类型，不物化：分块写入由 io 层实现（规格 §3.4 内存约束）。"""
    if isinstance(trades, (str, bytes)) or not isinstance(trades, Sequence):
        raise ValueError(f"trades must be a sequence of TradeEvent, got {trades!r}")  # noqa: TRY004
    for trade in trades:
        if not isinstance(trade, TradeEvent):
            raise ValueError(f"trades items must be TradeEvent, got {trade!r}")  # noqa: TRY004


def _check_warnings(warnings: Sequence[str]) -> None:
    if isinstance(warnings, (str, bytes)) or not isinstance(warnings, Sequence):
        raise ValueError(f"warnings must be a sequence of str, got {warnings!r}")  # noqa: TRY004
    for warning in warnings:
        ensure_non_empty_str(warning, "warnings item")


def _checked_account_snapshots(values: Sequence[AccountSnapshot]) -> tuple[AccountSnapshot, ...]:
    """物化为 tuple：快照是结果的一部分，禁止调用方后续改动输入列表影响已冻结的结果。"""
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise ValueError(f"account_snapshots must be a sequence of AccountSnapshot, got {values!r}")  # noqa: TRY004
    checked = tuple(values)
    for snapshot in checked:
        if not isinstance(snapshot, AccountSnapshot):
            raise ValueError(f"account_snapshots items must be AccountSnapshot, got {snapshot!r}")  # noqa: TRY004
    return checked


def _checked_order_results(values: Sequence[OrderResult]) -> tuple[OrderResult, ...]:
    """物化为 tuple：订单回报顺序即引擎裁决顺序，调用方不得再改。"""
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise ValueError(f"order_results must be a sequence of OrderResult, got {values!r}")  # noqa: TRY004
    checked = tuple(values)
    for order_result in checked:
        if not isinstance(order_result, OrderResult):
            raise ValueError(f"order_results items must be OrderResult, got {order_result!r}")  # noqa: TRY004
    return checked


@dataclass(frozen=True)
class EvaluationResult:
    """一次回测的完整结果快照：三层指标互不混入（规格 §3.2），版本与来源必填。

    K02 扩展：`account_snapshots`（订单入口逐日快照）与 `order_results`（订单裁决回报）
    默认空 tuple，phase-1 的 13 字段构造调用保持兼容；两字段仅内存结果，阶段 2 不持久化。
    """

    schema_version: str
    engine_version: str
    policy_version: str
    run_id: str
    model_id: str
    signal_metrics: Mapping[str, float]
    paper_metrics: Mapping[str, float]
    account_metrics: Mapping[str, float]
    methodology: MetricMethodology
    trades: Sequence[TradeEvent]
    warnings: Sequence[str]
    skipped_counts: Mapping[str, int]
    provenance: Mapping[str, str]
    account_snapshots: tuple[AccountSnapshot, ...] = ()
    order_results: tuple[OrderResult, ...] = ()

    def __post_init__(self) -> None:
        for field_name in ("schema_version", "engine_version", "policy_version", "run_id", "model_id"):
            ensure_non_empty_str(getattr(self, field_name), field_name)
        if not isinstance(self.methodology, MetricMethodology):
            raise ValueError(f"methodology must be a MetricMethodology, got {self.methodology!r}")  # noqa: TRY004
        object.__setattr__(self, "signal_metrics", _checked_metrics(self.signal_metrics, "signal_metrics"))
        object.__setattr__(self, "paper_metrics", _checked_metrics(self.paper_metrics, "paper_metrics"))
        object.__setattr__(self, "account_metrics", _checked_metrics(self.account_metrics, "account_metrics"))
        _check_trades(self.trades)
        _check_warnings(self.warnings)
        object.__setattr__(self, "skipped_counts", _checked_skipped_counts(self.skipped_counts, "skipped_counts"))
        object.__setattr__(self, "provenance", _checked_provenance(self.provenance))
        object.__setattr__(self, "account_snapshots", _checked_account_snapshots(self.account_snapshots))
        object.__setattr__(self, "order_results", _checked_order_results(self.order_results))

    def flatten_metrics(self, prefix: bool = True) -> dict[str, float]:
        """合并三层指标；prefix=False 跨层同名即抛错，避免口径混淆（规格 §3.2 命名空间隔离）。"""
        layers = (
            ("signal", self.signal_metrics),
            ("paper", self.paper_metrics),
            ("account", self.account_metrics),
        )
        flattened: dict[str, float] = {}
        for layer_name, metrics in layers:
            for key, value in metrics.items():
                flat_key = f"{layer_name}.{key}" if prefix else key
                if not prefix and flat_key in flattened:
                    raise ValueError(f"metric {key!r} appears in multiple layers; use prefix=True")
                flattened[flat_key] = value
        return flattened
