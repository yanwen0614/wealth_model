"""订单引擎给执行策略的权威、可排序反馈契约。"""

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date
from enum import StrEnum
from types import MappingProxyType

from .account import AccountState
from .enums import Side
from .events import TradeEvent
from .validation import ensure_calendar_date, ensure_finite, ensure_non_empty_str


class ExecutionPhase(StrEnum):
    SUBMITTED = "submitted"
    FILL = "fill"
    TERMINAL = "terminal"
    SNAPSHOT = "snapshot"


@dataclass(frozen=True)
class ActiveOrderSnapshot:
    order_id: str
    episode_id: str | None
    instrument_id: str
    side: Side
    remaining_shares: int | None
    execution_date: date | None = None
    status: str = "pending"

    def __post_init__(self) -> None:
        for name in ("order_id", "instrument_id", "status"):
            ensure_non_empty_str(getattr(self, name), name)
        if self.episode_id is not None:
            ensure_non_empty_str(self.episode_id, "episode_id")
        object.__setattr__(self, "side", Side(self.side))
        if self.remaining_shares is not None and (
            isinstance(self.remaining_shares, bool)
            or not isinstance(self.remaining_shares, int)
            or self.remaining_shares < 0
        ):
            raise ValueError(f"remaining_shares must be non-negative, got {self.remaining_shares!r}")
        if self.execution_date is not None:
            ensure_calendar_date(self.execution_date, "execution_date")


@dataclass(frozen=True)
class ExecutionUpdate:
    event_id: str
    sequence_no: int
    phase: ExecutionPhase
    trading_date: date
    episode_id: str | None
    order_id: str | None
    attempt_id: str | None
    fill_id: str | None
    trade: TradeEvent | None
    pre_state: AccountState
    post_state: AccountState
    cash_delta: float
    active_orders: Mapping[str, ActiveOrderSnapshot] = field(default_factory=dict)
    order_status: str | None = None
    reason: str | None = None

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.event_id, "event_id")
        if isinstance(self.sequence_no, bool) or not isinstance(self.sequence_no, int) or self.sequence_no < 1:
            raise ValueError(f"sequence_no must be a positive int, got {self.sequence_no!r}")
        object.__setattr__(self, "phase", ExecutionPhase(self.phase))
        ensure_calendar_date(self.trading_date, "trading_date")
        for name in ("episode_id", "order_id", "attempt_id", "fill_id"):
            value = getattr(self, name)
            if value is not None:
                ensure_non_empty_str(value, name)
        if self.order_status is not None:
            ensure_non_empty_str(self.order_status, "order_status")
        if self.reason is not None:
            ensure_non_empty_str(self.reason, "reason")
        ensure_finite(self.cash_delta, "cash_delta")
        if self.phase is ExecutionPhase.FILL and (self.trade is None or self.fill_id is None):
            raise ValueError("fill phase requires trade and fill_id")
        if not isinstance(self.pre_state, AccountState) or not isinstance(self.post_state, AccountState):
            raise ValueError("pre_state and post_state must be AccountState instances")  # noqa: TRY004
        if self.phase is ExecutionPhase.FILL:
            assert self.trade is not None and self.fill_id is not None
            if self.trade.fill_id != self.fill_id or self.trade.order_id != self.order_id:
                raise ValueError("fill identity must match the original TradeEvent")
        if self.phase is not ExecutionPhase.FILL and (self.trade is not None or self.fill_id is not None):
            raise ValueError("only fill phase may carry trade and fill_id")
        if self.cash_delta != self.post_state.cash - self.pre_state.cash:
            raise ValueError("cash_delta must equal post_state.cash - pre_state.cash")
        frozen = dict(self.active_orders)
        for key, item in frozen.items():
            ensure_non_empty_str(key, "active_orders key")
            if not isinstance(item, ActiveOrderSnapshot) or key != item.order_id:
                raise ValueError(f"active_orders[{key!r}] must match ActiveOrderSnapshot.order_id")
        object.__setattr__(self, "active_orders", MappingProxyType(frozen))
