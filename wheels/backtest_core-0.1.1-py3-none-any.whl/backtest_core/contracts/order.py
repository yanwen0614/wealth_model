"""订单契约（规格 §14.3/§15）：策略提交意图，引擎裁决成交并回报结果。

订单是"请求"而非成交承诺：是否成交 / 部分成交 / 拒绝由引擎按现金、容量、
可交易性与 T+1 锁定统一裁决，策略不得自行推演成交。
"""

from dataclasses import dataclass
from enum import StrEnum

from .enums import Side
from .validation import ensure_enum_member, ensure_finite, ensure_non_empty_str, ensure_non_negative_finite

__all__ = ["OrderIntent", "OrderResult", "OrderStatus"]


def _ensure_positive_shares(value: int) -> None:
    """整股数必须为正整数：bool 是 int 子类但语义非法，浮点股数只出现在 paper 层。"""
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"shares must be a positive int, got {value!r}")


def _ensure_non_negative_shares(value: int, field_name: str) -> None:
    """成交股数允许 0（拒绝路径）：非负整数，bool/浮点显式拒绝。"""
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative int, got {value!r}")


def _ensure_positive_cash(value: float) -> None:
    """现金预算必须为正的有限金额：0/负/NaN 折算不出任何整手，必须显式拒绝。"""
    ensure_finite(value, "cash_amount")
    if value <= 0:
        raise ValueError(f"cash_amount must be positive, got {value!r}")


@dataclass(frozen=True)
class OrderIntent:
    """原子订单意图（规格 §15）：买单 shares/cash_amount 恰选其一，卖单只认 shares。

    买单 cash_amount 为现金预算，由引擎按成交价与费用折算为整手股数并向下取整，
    不构成成交承诺；卖单的可卖量由引擎按 T+1 锁定与持仓裁决。
    """

    instrument_id: str
    side: Side
    shares: int | None = None
    cash_amount: float | None = None
    episode_id: str | None = None
    order_id: str | None = None
    limit_price: float | None = None

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        for field_name in ("episode_id", "order_id"):
            value = getattr(self, field_name)
            if value is not None:
                ensure_non_empty_str(value, field_name)
        # 规格 §10 接口形状允许适配器传字面量字符串，合法值在此归一为枚举成员
        object.__setattr__(self, "side", ensure_enum_member(self.side, Side, "side"))
        if self.limit_price is not None:
            ensure_finite(self.limit_price, "limit_price")
            if self.limit_price <= 0:
                raise ValueError(f"limit_price must be positive, got {self.limit_price!r}")
            if self.cash_amount is not None:
                raise ValueError("limit_price orders require fixed shares; cash_amount is not supported")
            if self.shares is None:
                raise ValueError("limit_price orders require fixed shares")
        if self.side == Side.BUY:
            if (self.shares is None) == (self.cash_amount is None):
                raise ValueError(
                    "buy order requires exactly one of shares or cash_amount, "
                    f"got shares={self.shares!r}, cash_amount={self.cash_amount!r}"
                )
            if self.shares is not None:
                _ensure_positive_shares(self.shares)
            if self.cash_amount is not None:
                _ensure_positive_cash(self.cash_amount)
            return
        if self.cash_amount is not None:
            raise ValueError(f"sell order only accepts shares, got cash_amount={self.cash_amount!r}")
        if self.shares is None:
            raise ValueError("sell order requires shares, got None")
        _ensure_positive_shares(self.shares)


class OrderStatus(StrEnum):
    """引擎对订单意图的裁决三态：partial 为容量截断结果，rejected 必带原因。"""

    FILLED = "filled"
    PARTIAL = "partial"
    REJECTED = "rejected"


@dataclass(frozen=True)
class OrderResult:
    """订单裁决回报（规格 §15）：策略据此对账，不得自行推演成交。

    fees 为成交总费用（佣金 + 印花税 + 过户费 + 滑点成本），允许 0.0；
    不拆分字段以保持最小契约，费用明细由账户层 TradeEvent 承载。
    reason 为拒绝 / 截断原因（通常取 ReasonCode 值），rejected 必填。
    """

    order: OrderIntent
    status: OrderStatus
    filled_shares: int
    fill_price: float | None
    fees: float
    reason: str | None
    attempt_id: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.order, OrderIntent):
            raise ValueError(f"order must be an OrderIntent, got {self.order!r}")  # noqa: TRY004
        object.__setattr__(self, "status", ensure_enum_member(self.status, OrderStatus, "status"))
        _ensure_non_negative_shares(self.filled_shares, "filled_shares")
        ensure_non_negative_finite(self.fees, "fees")
        if self.reason is not None:
            ensure_non_empty_str(self.reason, "reason")
        if self.attempt_id is not None:
            ensure_non_empty_str(self.attempt_id, "attempt_id")
        if self.status == OrderStatus.REJECTED:
            if self.filled_shares != 0 or self.fill_price is not None:
                raise ValueError(
                    "status=rejected requires filled_shares=0 and fill_price=None, "
                    f"got filled_shares={self.filled_shares!r}, fill_price={self.fill_price!r}"
                )
            if self.fees != 0.0:
                raise ValueError(f"status=rejected requires fees=0.0, got {self.fees!r}")
            if self.reason is None:
                raise ValueError("status=rejected requires a reason")
            return
        if self.filled_shares <= 0:
            raise ValueError(f"status={self.status.value!r} requires filled_shares > 0, got {self.filled_shares!r}")
        if self.fill_price is None:
            raise ValueError(f"status={self.status.value!r} requires fill_price")
        ensure_finite(self.fill_price, "fill_price")
        if self.fill_price <= 0:
            raise ValueError(f"fill_price must be positive, got {self.fill_price!r}")
        if self.order.shares is not None and self.filled_shares > self.order.shares:
            raise ValueError(
                f"filled_shares={self.filled_shares!r} exceeds requested shares={self.order.shares!r}"
            )
