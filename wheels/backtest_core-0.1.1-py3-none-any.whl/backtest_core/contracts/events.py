"""成交事件契约（规格 §10/§3.2）：四态语义显式、费用拆分、禁止静默丢弃。"""

from dataclasses import dataclass
from datetime import datetime

from .enums import EventStatus, ReasonCode, Side
from .validation import (
    ensure_enum_member,
    ensure_finite,
    ensure_non_empty_str,
    ensure_non_negative_finite,
    ensure_tz_aware,
)

__all__ = ["TradeEvent"]

# filled/forced_exit 是真实成交（必须有价有量），skipped/locked 是可交易性拒绝状态
_FILL_STATUSES = frozenset({EventStatus.FILLED, EventStatus.FORCED_EXIT})


def _ensure_shares(value: int) -> None:
    """股数必须是非负整数：bool 是 int 子类但语义非法，浮点股数只允许出现在 paper 层。"""
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"shares must be a non-negative int, got {value!r}")


def _ensure_positive_price(value: float | None, field_name: str) -> None:
    """缺价用 None 表达；提供时必须为正的有限价格（0/负价是静默错误源）。"""
    if value is None:
        return
    ensure_finite(value, field_name)
    if value <= 0:
        raise ValueError(f"{field_name} must be positive when provided, got {value!r}")


@dataclass(frozen=True)
class TradeEvent:
    """单笔订单执行结果：signal_time 与 execution_time 分列，status 四态表达不可成交原因。"""

    signal_time: datetime
    execution_time: datetime
    instrument_id: str
    side: Side
    shares: int
    base_price: float | None
    execution_price: float | None
    amount: float
    commission: float
    stamp_tax: float
    transfer_fee: float
    slippage_cost: float
    participation: float | None
    status: EventStatus
    reason: ReasonCode | None
    episode_id: str | None = None
    order_id: str | None = None
    fill_id: str | None = None
    sequence_no: int | None = None

    def __post_init__(self) -> None:
        ensure_tz_aware(self.signal_time, "signal_time")
        ensure_tz_aware(self.execution_time, "execution_time")
        # 防前视红线（规格 §3.2）：成交时间必须严格晚于信号时间，相等即视为同日成交
        if self.execution_time <= self.signal_time:
            raise ValueError(
                "execution_time must be strictly after signal_time, "
                f"got {self.execution_time!r} <= {self.signal_time!r}"
            )
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        for field_name in ("episode_id", "order_id", "fill_id"):
            value = getattr(self, field_name)
            if value is not None:
                ensure_non_empty_str(value, field_name)
        if self.sequence_no is not None and (
            isinstance(self.sequence_no, bool) or not isinstance(self.sequence_no, int) or self.sequence_no < 1
        ):
            raise ValueError(f"sequence_no must be a positive int when provided, got {self.sequence_no!r}")
        # 规格 §10 接口形状允许适配器传字面量字符串，合法值在此归一为枚举成员
        object.__setattr__(self, "side", ensure_enum_member(self.side, Side, "side"))
        _ensure_shares(self.shares)
        _ensure_positive_price(self.base_price, "base_price")
        _ensure_positive_price(self.execution_price, "execution_price")
        for field_name in ("amount", "commission", "stamp_tax", "transfer_fee", "slippage_cost"):
            ensure_non_negative_finite(getattr(self, field_name), field_name)
        if self.participation is not None:
            ensure_finite(self.participation, "participation")
            if not 0.0 <= self.participation <= 1.0:
                raise ValueError(f"participation must be within [0, 1], got {self.participation!r}")
        object.__setattr__(self, "status", ensure_enum_member(self.status, EventStatus, "status"))
        if self.reason is not None:
            object.__setattr__(self, "reason", ensure_enum_member(self.reason, ReasonCode, "reason"))
        self._ensure_status_consistency()

    def _ensure_status_consistency(self) -> None:
        """状态 × 价格 × 原因的组合校验：不可成交状态禁止伪装成有价成交。"""
        if self.status in _FILL_STATUSES:
            if self.execution_price is None or self.shares <= 0:
                raise ValueError(
                    f"status={self.status.value!r} requires execution_price and shares > 0, "
                    f"got execution_price={self.execution_price!r}, shares={self.shares!r}"
                )
            if self.status != EventStatus.FILLED and self.reason is None:
                raise ValueError(f"status={self.status.value!r} requires a reason")
            return
        if self.execution_price is not None:
            raise ValueError(f"status={self.status.value!r} must not carry execution_price")
        if self.reason is None:
            raise ValueError(f"status={self.status.value!r} requires a reason")
