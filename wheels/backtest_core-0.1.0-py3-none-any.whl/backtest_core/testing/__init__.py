"""testing 合成 fixtures 公共 API（规格 §14.3）：三仓库 adapter 与核心测试共用同一组确定性场景。

发布形态：随 backtest_core 打包，阶段 2 adapter 直接 `from backtest_core.testing import build_scenario`。
"""

from .synthetic import (
    DEFAULT_BASE_AMOUNT,
    DEFAULT_BASE_PRICE,
    DEFAULT_INSTRUMENT_ID,
    DEFAULT_START_DATE,
    DEFAULT_TRADING_DAYS,
    SCENARIOS,
    SHORT_HISTORY_DAYS,
    SyntheticMarketProvider,
    build_downtrend,
    build_last_day,
    build_limit_down_day,
    build_limit_up_day,
    build_market,
    build_missing_price_day,
    build_missing_volume_day,
    build_scenario,
    build_short_history,
    build_suspended_day,
    build_uptrend,
    make_bar,
)

__all__ = [
    "DEFAULT_BASE_AMOUNT",
    "DEFAULT_BASE_PRICE",
    "DEFAULT_INSTRUMENT_ID",
    "DEFAULT_START_DATE",
    "DEFAULT_TRADING_DAYS",
    "SCENARIOS",
    "SHORT_HISTORY_DAYS",
    "SyntheticMarketProvider",
    "build_downtrend",
    "build_last_day",
    "build_limit_down_day",
    "build_limit_up_day",
    "build_market",
    "build_missing_price_day",
    "build_missing_volume_day",
    "build_scenario",
    "build_short_history",
    "build_suspended_day",
    "build_uptrend",
    "make_bar",
]
