"""合成行情 fixtures（规格 §14.3）：随包发布，供三仓库 adapter 与核心测试复用同一组确定性数据。

设计约束：
- 只依赖 contracts 与标准库，保证阶段 2 adapter 可直接 import（核心包对三仓库依赖为 0）；
- 价格路径由公式 + 固定 seed 生成（禁无种子随机），同输入逐字段可复现；
- get_history 自带 ≤ end_date 前视防护，与真实 provider 契约一致；
- 场景显式覆盖停牌/涨跌停/缺价/缺量/短历史/尾日，避免纯 happy path fixture 漏掉真实缺陷。
"""

import math
import random
from collections.abc import Callable, Iterable, Mapping
from dataclasses import replace
from datetime import date, timedelta
from typing import Any, Final, Self

from ..contracts.market import MarketBar
from ..contracts.validation import ensure_calendar_date

__all__ = [
    "DEFAULT_BASE_AMOUNT",
    "DEFAULT_BASE_PRICE",
    "DEFAULT_INSTRUMENT_ID",
    "DEFAULT_START_DATE",
    "DEFAULT_TRADING_DAYS",
    "SCENARIOS",
    "SHORT_HISTORY_DAYS",
    "SyntheticMarketProvider",
    "build_downtrend",
    "build_last_day",
    "build_limit_down_day",
    "build_limit_up_day",
    "build_market",
    "build_missing_price_day",
    "build_missing_volume_day",
    "build_scenario",
    "build_short_history",
    "build_suspended_day",
    "build_uptrend",
    "make_bar",
]

DEFAULT_INSTRUMENT_ID = "000001.SZ"
DEFAULT_START_DATE: Final = date(2026, 1, 5)  # 周一：默认起点与自然周对齐
DEFAULT_TRADING_DAYS = 25  # ≥21：同时满足 ADV20（20 个 amount）与 σ20（20 个收益样本）
DEFAULT_BASE_PRICE = 10.0
DEFAULT_BASE_AMOUNT = 100_000_000.0  # 1 亿元成交额，与 SLIPPAGE_RESEARCH 校准同量纲
DEFAULT_VOLUME = 1_000_000.0
SHORT_HISTORY_DAYS = 15  # <20：触发 compute_liquidity_stats 的短历史降级
_TREND_DRIFT = 0.005  # 上涨/下跌场景的日对数漂移：两位小数下单调性可断言
_INTRADAY_BAND = 0.5  # high/low 相对日内极值的外扩比例（乘 volatility）


class _Unset:
    """哨兵：区分“未提供”与“显式 None”，使缺价/缺量 fixture 可被显式构造。"""

    __slots__ = ()


_UNSET: Final = _Unset()


def _defaulted(value: float | None | _Unset, fallback: float | None) -> float | None:
    if isinstance(value, _Unset):
        return fallback
    return value


def make_bar(
    instrument_id: str,
    trading_date: date,
    close: float | None = DEFAULT_BASE_PRICE,
    *,
    open_: float | None | _Unset = _UNSET,
    high: float | None | _Unset = _UNSET,
    low: float | None | _Unset = _UNSET,
    volume: float | None | _Unset = _UNSET,
    amount: float | None | _Unset = _UNSET,
    is_trading: bool = True,
    limit_up: bool = False,
    limit_down: bool = False,
) -> MarketBar:
    """构造单根 bar：OHLC 默认跟随 close、量额默认正数；显式传 None 可构造缺失字段。"""
    resolved_open = _defaulted(open_, close)
    resolved_high = _defaulted(high, close)
    resolved_low = _defaulted(low, close)
    resolved_volume = _defaulted(volume, DEFAULT_VOLUME)
    # amount 默认由量价推导；close 缺失时不可推导，显式置 None 而非伪造数值
    default_amount = None if resolved_volume is None or close is None else resolved_volume * close
    resolved_amount = _defaulted(amount, default_amount)
    return MarketBar(
        instrument_id=instrument_id,
        trading_date=trading_date,
        open=resolved_open,
        high=resolved_high,
        low=resolved_low,
        close=close,
        volume=resolved_volume,
        amount=resolved_amount,
        is_trading=is_trading,
        limit_up=limit_up,
        limit_down=limit_down,
    )


class SyntheticMarketProvider:
    """内存合成行情 provider：实现 MarketDataProvider 协议，确定性且可重复构建。"""

    def __init__(self, bars: Iterable[MarketBar] = ()) -> None:
        self._bars: dict[tuple[str, date], MarketBar] = {}
        for bar in bars:
            self.add_bar(bar)

    @classmethod
    def from_dict(cls, bars: Mapping[tuple[str, date], MarketBar]) -> Self:
        """从 {(instrument_id, trading_date): MarketBar} 快照构建；键与 bar 字段不一致即报错。"""
        provider = cls()
        for (instrument_id, trading_date), bar in bars.items():
            if (bar.instrument_id, bar.trading_date) != (instrument_id, trading_date):
                raise ValueError(
                    f"key {(instrument_id, trading_date)!r} does not match bar "
                    f"{(bar.instrument_id, bar.trading_date)!r}"
                )
            provider.add_bar(bar)
        return provider

    def add_bar(self, bar: MarketBar) -> None:
        """加入单根 bar；同键重复加入即 fixture 构造错误，静默覆盖会掩盖测试意图。"""
        if not isinstance(bar, MarketBar):
            raise ValueError(f"bar must be a MarketBar, got {bar!r}")  # noqa: TRY004
        key = (bar.instrument_id, bar.trading_date)
        if key in self._bars:
            raise ValueError(f"duplicate bar for {key!r}")
        self._bars[key] = bar

    def get_bar(self, instrument_id: str, trading_date: date) -> MarketBar | None:
        return self._bars.get((instrument_id, trading_date))

    def get_history(self, instrument_id: str, end_date: date, lookback_days: int) -> tuple[MarketBar, ...]:
        """只返回 trading_date ≤ end_date 的最近 lookback_days 条（升序）；防前视核心接口。"""
        ensure_calendar_date(end_date, "end_date")
        if isinstance(lookback_days, bool) or not isinstance(lookback_days, int) or lookback_days < 1:
            raise ValueError(f"lookback_days must be a positive int, got {lookback_days!r}")
        bars = [bar for bar in self.bars_for(instrument_id) if bar.trading_date <= end_date]
        return tuple(bars[-lookback_days:])

    def bars_for(self, instrument_id: str) -> tuple[MarketBar, ...]:
        """按日期升序返回标的全部 bars；场景构造与测试断言共用。"""
        return tuple(
            sorted(
                (bar for (bar_instrument, _), bar in self._bars.items() if bar_instrument == instrument_id),
                key=lambda bar: bar.trading_date,
            )
        )

    def trading_dates(self, instrument_id: str) -> tuple[date, ...]:
        return tuple(bar.trading_date for bar in self.bars_for(instrument_id))

    def instrument_ids(self) -> tuple[str, ...]:
        return tuple(sorted({instrument_id for instrument_id, _ in self._bars}))


def _trading_dates(start_date: date, trading_days: int) -> list[date]:
    """连续生成工作日（跳过周末）：合成序列与真实交易日语义一致且无需外部日历依赖。"""
    ensure_calendar_date(start_date, "start_date")
    if trading_days < 1:
        raise ValueError(f"trading_days must be >= 1, got {trading_days!r}")
    dates: list[date] = []
    current = start_date
    while len(dates) < trading_days:
        if current.weekday() < 5:
            dates.append(current)
        current += timedelta(days=1)
    return dates


def _close_path(*, trading_days: int, base_price: float, drift: float, volatility: float, seed: int) -> list[float]:
    """固定 seed 的对数随机游走：同参数逐字段可复现；价格归一 0.01 元 tick。"""
    if base_price <= 0:
        raise ValueError(f"base_price must be positive, got {base_price!r}")
    if volatility < 0:
        raise ValueError(f"volatility must be non-negative, got {volatility!r}")
    rng = random.Random(seed)
    closes: list[float] = []
    price = base_price
    for _ in range(trading_days):
        price *= math.exp(drift + volatility * rng.uniform(-1.0, 1.0))
        closes.append(round(price, 2))
    return closes


def build_market(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
    drift: float = 0.0,
    volatility: float = 0.02,
    seed: int = 0,
    base_amount: float = DEFAULT_BASE_AMOUNT,
) -> SyntheticMarketProvider:
    """确定性生成量价序列（默认 25 日，覆盖 ADV20/σ20 窗口）。"""
    if base_amount <= 0:
        raise ValueError(f"base_amount must be positive, got {base_amount!r}")
    closes = _close_path(trading_days=trading_days, base_price=base_price, drift=drift, volatility=volatility, seed=seed)
    bars: list[MarketBar] = []
    previous_close = base_price
    for trading_date, close in zip(_trading_dates(start_date, trading_days), closes):
        open_price = round(previous_close, 2)
        spread = _INTRADAY_BAND * volatility
        high = round(max(open_price, close) * (1.0 + spread), 2)
        low = round(min(open_price, close) * (1.0 - spread), 2)
        bars.append(
            make_bar(
                instrument_id,
                trading_date,
                close,
                open_=open_price,
                high=high,
                low=low,
                volume=round(base_amount / close),  # 成交额恒定，量随价反比变化
                amount=base_amount,
            )
        )
        previous_close = close
    return SyntheticMarketProvider(bars)


def _resolve_index(at: int | None, trading_days: int) -> int:
    index = trading_days // 2 if at is None else at
    if not 0 <= index < trading_days:
        raise ValueError(f"at {index!r} out of range for {trading_days} trading days")
    return index


def _flagged_day(
    instrument_id: str,
    *,
    start_date: date,
    trading_days: int,
    base_price: float,
    at: int | None,
    **overrides: Any,
) -> SyntheticMarketProvider:
    """在基础序列上覆盖单日字段：单变量场景（停牌/涨跌停/缺价/缺量）便于断言与定位。"""
    market = build_market(instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price)
    index = _resolve_index(at, trading_days)
    return _override_bar(market, instrument_id, index, **overrides)


def _override_bar(
    provider: SyntheticMarketProvider,
    instrument_id: str,
    index: int,
    **overrides: Any,
) -> SyntheticMarketProvider:
    bars = list(provider.bars_for(instrument_id))
    bars[index] = replace(bars[index], **overrides)
    return SyntheticMarketProvider(bars)


def build_uptrend(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
) -> SyntheticMarketProvider:
    """确定性上涨序列（日漂移 +0.5%、无随机项）：σ 退化到 clip 下界仍可算 LiquidityStats。"""
    return build_market(
        instrument_id,
        start_date=start_date,
        trading_days=trading_days,
        base_price=base_price,
        drift=_TREND_DRIFT,
        volatility=0.0,
        seed=0,
    )


def build_downtrend(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
) -> SyntheticMarketProvider:
    """确定性下跌序列（日漂移 -0.5%、无随机项），与 build_uptrend 互为方向镜像。"""
    return build_market(
        instrument_id,
        start_date=start_date,
        trading_days=trading_days,
        base_price=base_price,
        drift=-_TREND_DRIFT,
        volatility=0.0,
        seed=0,
    )


def build_suspended_day(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
    at: int | None = None,
) -> SyntheticMarketProvider:
    """单日停牌（is_trading=False）；价格与量额保留，使断言聚焦停牌单变量。"""
    return _flagged_day(
        instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price, at=at, is_trading=False
    )


def build_limit_up_day(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
    at: int | None = None,
) -> SyntheticMarketProvider:
    """单日涨停（limit_up=True）；用于买入跳过场景，价格仍按基础路径生成。"""
    return _flagged_day(
        instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price, at=at, limit_up=True
    )


def build_limit_down_day(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
    at: int | None = None,
) -> SyntheticMarketProvider:
    """单日跌停（limit_down=True）；用于卖出锁定场景，价格仍按基础路径生成。"""
    return _flagged_day(
        instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price, at=at, limit_down=True
    )


def build_missing_price_day(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
    at: int | None = None,
) -> SyntheticMarketProvider:
    """单日缺价（open=None，其余 OHLC 保留）：t1_open 执行时价格字段缺失的降级分支。"""
    return _flagged_day(
        instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price, at=at, open=None
    )


def build_missing_volume_day(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
    at: int | None = None,
) -> SyntheticMarketProvider:
    """单日缺量（volume/amount=None）：滑点策略 missing_volume_policy 的降级分支。"""
    return _flagged_day(
        instrument_id,
        start_date=start_date,
        trading_days=trading_days,
        base_price=base_price,
        at=at,
        volume=None,
        amount=None,
    )


def build_short_history(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = SHORT_HISTORY_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
) -> SyntheticMarketProvider:
    """短历史（默认 15 日 < 21）：compute_liquidity_stats 返回 None，触发调用方显式降级。"""
    return build_market(instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price)


def build_last_day(
    instrument_id: str = DEFAULT_INSTRUMENT_ID,
    *,
    start_date: date = DEFAULT_START_DATE,
    trading_days: int = DEFAULT_TRADING_DAYS,
    base_price: float = DEFAULT_BASE_PRICE,
) -> SyntheticMarketProvider:
    """完整序列（默认 25 日）：last_day 即 trading_dates()[-1]，供尾日/无下一交易日用例定位。"""
    return build_market(instrument_id, start_date=start_date, trading_days=trading_days, base_price=base_price)


SCENARIOS: dict[str, Callable[..., SyntheticMarketProvider]] = {
    "uptrend": build_uptrend,
    "downtrend": build_downtrend,
    "suspended_day": build_suspended_day,
    "limit_up_day": build_limit_up_day,
    "limit_down_day": build_limit_down_day,
    "missing_price_day": build_missing_price_day,
    "missing_volume_day": build_missing_volume_day,
    "short_history": build_short_history,
    "last_day": build_last_day,
}


def build_scenario(name: str, **kwargs: Any) -> SyntheticMarketProvider:
    """按名称构建预设场景；未知名称显式拒绝并列出合法集合，fixture typo 不得静默回退。"""
    factory = SCENARIOS.get(name)
    if factory is None:
        valid = ", ".join(sorted(SCENARIOS))
        raise ValueError(f"unknown scenario {name!r}: expected one of ({valid})")
    return factory(**kwargs)
