# testing - 合成 Fixtures

合成行情 fixtures，供测试复用。只依赖 `contracts` + 标准库。

## 关键约束

- 价格路径由公式 + 固定 `seed` 生成（无种子随机禁止），同输入逐字段可复现。
- `get_history` 自带 `≤ end_date` 防护，与 `MarketDataProvider` 契约一致。
- 默认值：`DEFAULT_START_DATE=2026-01-05`（周一），`DEFAULT_TRADING_DAYS=25`（≥21：同时满足 ADV20 与 σ20），`DEFAULT_BASE_PRICE=10.0`，`DEFAULT_BASE_AMOUNT=1e8`。
- `maketrend_scenarios` 显式覆盖：停牌 / 涨跌停 / 缺价 / 缺量 / 短历史 / 尾日 / 下跌 / 上涨。

## 场景护卫

- `SCENARIOS` 常量字典，key 即场景名，供测试直接索引。
- `build_scenario(name)` 返回 `SyntheticMarketProvider` 实例。
- `SHORT_HISTORY_DAYS=15`（<20：触发 `compute_liquidity_stats` 的短历史降级）。
- 依赖方向单向：本包不 import `policies` / `engine` / `evaluation`，保证 adapter 裸 import 无副作用。

## 常用构建

```python
from backtest_core.testing import build_market, SyntheticMarketProvider

market = SyntheticMarketProvider(
    *build_market("A.SZ", trading_days=25).bars_for("A.SZ"),
    *build_market("B.SZ", trading_days=25).bars_for("B.SZ"),
)
```
