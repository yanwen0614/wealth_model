"""账户整段评估（K04）：从逐日快照或 NAV 序列复用 metrics.py 产出 account_metrics 同口径指标。

设计约束：
- 纯函数、只依赖 contracts + 同包 metrics/methodology；不 import engine（避免 evaluation→engine 反向依赖）；
- 口径单一事实源与 DefaultEvaluationEngine 一致：年化 242/rf=0.02/ddof=1/正值 MDD/胜率可配置；
- 输入为 `AccountSnapshot` 序列时 NAV 序列取 `snapshots.nav`；可用 `initial_capital` 补上引擎
  `[capital, ...每日 mark]` 序列的起点，使结果可与 EvaluationResult.account_metrics 直接对照；
- 无样本按既有占位语义记 0.0；不可计算的 closed_position 胜率与缺输入的 turnover 省略键，不伪造 0.0。
"""

from collections.abc import Sequence
from typing import TypeGuard

from ..contracts.account import AccountSnapshot
from ..contracts.result import MetricMethodology
from . import metrics
from .methodology import periods_per_year

__all__ = ["evaluate_account"]


def _resolve_methodology(methodology: MetricMethodology | None) -> MetricMethodology:
    if methodology is None:
        return MetricMethodology()
    if not isinstance(methodology, MetricMethodology):
        raise ValueError(f"methodology must be a MetricMethodology or None, got {methodology!r}")  # noqa: TRY004
    return methodology


def _is_number(value: object) -> TypeGuard[float]:
    """TypeGuard：使 pyright 在排除分支后把元素收窄为数值，避免逐元素 cast。"""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _resolve_nav(source: Sequence[AccountSnapshot] | Sequence[float], initial_capital: float | None) -> tuple[float, ...]:
    """统一解析输入为 NAV 序列：快照取 nav，数值序列原样；两类型混用显式失败。"""
    if isinstance(source, (str, bytes)) or not isinstance(source, Sequence):
        raise ValueError(  # noqa: TRY004
            f"daily_snapshots must be a sequence of AccountSnapshot or numbers, got {source!r}"
        )
    if len(source) == 0:
        if initial_capital is not None:
            raise ValueError("initial_capital requires snapshot input, got an empty sequence")
        return ()
    first = source[0]
    if isinstance(first, AccountSnapshot):
        nav_values: list[float] = []
        for index, item in enumerate(source):
            if not isinstance(item, AccountSnapshot):
                raise ValueError(  # noqa: TRY004
                    f"daily_snapshots items must be AccountSnapshot, got {item!r} at index {index}"
                )
            nav_values.append(item.nav)
        nav = tuple(nav_values)
        if initial_capital is None:
            return nav
        checked = metrics._positive_nav([initial_capital])
        return (checked[0], *nav)
    if _is_number(first):
        if initial_capital is not None:
            raise ValueError("initial_capital is only applicable to snapshot input, got a nav sequence")
        numbers: list[float] = []
        for index, item in enumerate(source):
            if not _is_number(item):
                raise ValueError(
                    f"daily_snapshots items must be numbers, got {item!r} at index {index}"
                )
            numbers.append(float(item))
        return tuple(numbers)
    raise ValueError(
        f"daily_snapshots items must be AccountSnapshot or numbers, got {first!r} at index 0"
    )


def evaluate_account(
    daily_snapshots: Sequence[AccountSnapshot] | Sequence[float],
    methodology: MetricMethodology | None = None,
    *,
    initial_capital: float | None = None,
    closed_returns: Sequence[float] | None = None,
    trade_amounts: Sequence[float] | None = None,
    average_nav: float | None = None,
) -> dict[str, float]:
    """按 methodology 计算账户整段指标；键与 account_metrics 同口径（sharpe/max_drawdown 等）。

    - nav 路径直接消费数值序列；snapshots 路径消费 `snapshots.nav`（可加 `initial_capital` 起点）；
    - win_rate 按 methodology.win_rate_definition 选择：daily_return 用 NAV 日收益；
      closed_position 需要 closed_returns，缺失时省略键（禁止 A 口径数值冒充 B 口径）；
    - turnover 仅在提供 trade_amounts 时计算，分母优先 average_nav，否则取 NAV 均值。
    - **省略键对齐**：本函数没有 warnings 通道；`closed_position` 缺 `closed_returns`、
      缺 `trade_amounts` 时返回映射不含 win_rate/turnover。调用方应与 `EvaluationResult.account_metrics`
      的键集合逐键对齐（缺键即缺输入），禁止用 0.0 默认值补齐冒充同口径结果。
    """
    resolved = _resolve_methodology(methodology)
    nav = _resolve_nav(daily_snapshots, initial_capital)
    periods = periods_per_year(resolved)
    returns = metrics.period_returns(nav)
    evaluated: dict[str, float] = {
        "total_return": metrics.total_return(nav),
        "annualized_return": metrics.annualized_return(nav, periods),
        "volatility": metrics.volatility(returns, periods, resolved.sharpe_ddof),
        "sharpe": metrics.sharpe_ratio(returns, resolved.risk_free_rate_annual, periods, resolved.sharpe_ddof),
        "max_drawdown": metrics.max_drawdown(nav),
    }
    if resolved.win_rate_definition == "closed_position":
        if closed_returns is not None:
            evaluated["win_rate"] = metrics.win_rate_closed_position(closed_returns)
    else:
        evaluated["win_rate"] = metrics.win_rate_daily(returns)
    if trade_amounts is not None:
        if average_nav is not None:
            denominator = average_nav
        elif len(nav) > 0:
            denominator = sum(nav) / len(nav)
        else:
            denominator = 0.0  # 无 NAV 样本时换手无分母；turnover_ratio 对非正分母返回 0.0
        evaluated["turnover"] = metrics.turnover_ratio(trade_amounts, denominator)
    return evaluated
