"""信号层评估纯函数（规格 §11.1/§14.3）：截面 rank IC、ICIR、TopN 与分层收益。

本模块的数学原语（rank_ic/ic_summary/quintile_returns 等）仍为公共可复用能力，**不属废弃**；
被废弃的是 label 口径的层入口 `engine.evaluate_signal_layer`（见其 docstring）。新评估代码
应优先使用 `evaluation.cross_section`（收益由引擎从市场自算）与 `evaluation.account`。

设计约束：
- 只依赖标准库：与 metrics.py 同口径，三仓库可离线复算，避免 numpy/pandas 精度差异；
- IC 语义与 quant ICAnalyzer 一致：先取平均秩再 Pearson（raw≡rank，平局校正）；
- 方向语义显式：descending=信号越大越好（与标签正相关）；ascending 下同一数据 IC 取反号；
- 边界固定：截面不足或秩方差为 0（常数信号/标签）返回 None，由上层计数跳过；
- 平局显式：秩取平均；分层按排序名次等分，平局以 instrument_id 升序稳定定序。
"""

import math
from collections.abc import Mapping, Sequence
from datetime import date
from itertools import pairwise

from .metrics import _ensure_ddof, _finite_tuple

__all__ = ["ic_series", "ic_summary", "quintile_returns", "rank_ic", "topn_return"]

_VALID_DIRECTIONS = ("ascending", "descending")


def _ensure_direction(direction: str) -> str:
    """归一排序方向：StrEnum 与字面量字符串均可，非法值显式失败（禁止静默默认）。"""
    if direction in _VALID_DIRECTIONS:
        return str(direction)
    raise ValueError(f"direction must be one of {_VALID_DIRECTIONS}, got {direction!r}")


def _ensure_positive_int(value: int, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive int, got {value!r}")
    return value


def _finite_mapping(values: Mapping[str, float], field_name: str) -> dict[str, float]:
    """复制并校验映射：非有限值即输入契约破坏，入口失败优于静默产出 NaN。"""
    if not isinstance(values, Mapping):
        raise ValueError(f"{field_name} must be a mapping, got {values!r}")  # noqa: TRY004
    checked: dict[str, float] = {}
    for key, value in values.items():
        if not isinstance(key, str) or not key:
            raise ValueError(f"{field_name} keys must be non-empty str, got {key!r}")
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"{field_name}[{key!r}] must be a finite number, got {value!r}")
        checked[key] = float(value)
    return checked


def _aligned_pairs(
    signal: Mapping[str, float], label: Mapping[str, float]
) -> tuple[tuple[str, float, float], ...]:
    """交集按 code 排序：与映射构造顺序无关，保证浮点求和确定性。"""
    checked_signal = _finite_mapping(signal, "signal")
    checked_label = _finite_mapping(label, "label")
    return tuple(
        (key, checked_signal[key], checked_label[key]) for key in sorted(checked_signal.keys() & checked_label.keys())
    )


def _average_ranks(values: Sequence[float]) -> tuple[float, ...]:
    """平均秩（1 为最小）：平局共享组内平均名次，与 pandas rank(method="average") 同语义。"""
    order = sorted(range(len(values)), key=lambda index: values[index])
    ranks = [0.0] * len(values)
    start = 0
    while start < len(order):
        end = start
        while end + 1 < len(order) and values[order[end + 1]] == values[order[start]]:
            end += 1
        average = (start + end) / 2.0 + 1.0
        for position in range(start, end + 1):
            ranks[order[position]] = average
        start = end + 1
    return tuple(ranks)


def _pearson(xs: Sequence[float], ys: Sequence[float]) -> float | None:
    """中心化两遍法 Pearson；任一序列零方差时相关无定义 → None（大 N 精度教训）。"""
    count = len(xs)
    mean_x = sum(xs) / count
    mean_y = sum(ys) / count
    covariance = 0.0
    variance_x = 0.0
    variance_y = 0.0
    for x_value, y_value in zip(xs, ys):
        x_deviation = x_value - mean_x
        y_deviation = y_value - mean_y
        covariance += x_deviation * y_deviation
        variance_x += x_deviation * x_deviation
        variance_y += y_deviation * y_deviation
    denominator = math.sqrt(variance_x * variance_y)
    if denominator == 0.0:
        return None
    return max(-1.0, min(1.0, covariance / denominator))


def rank_ic(
    signal: Mapping[str, float],
    label: Mapping[str, float],
    *,
    min_cross_section: int = 10,
    direction: str = "descending",
) -> float | None:
    """截面 Spearman IC：先平均秩再 Pearson；交集样本不足或秩退化 → None。

    direction="descending"（默认）：信号越大越好，IC 与标签秩正相关；
    direction="ascending"：信号越小越好，对同一数据 IC 取反号（显式方向语义）。
    """
    resolved_direction = _ensure_direction(direction)
    threshold = _ensure_positive_int(min_cross_section, "min_cross_section")
    pairs = _aligned_pairs(signal, label)
    if len(pairs) < threshold:
        return None
    correlation = _pearson(_average_ranks([value for _, value, _ in pairs]), _average_ranks([value for _, _, value in pairs]))
    if correlation is None:
        return None
    if resolved_direction == "ascending":
        return -correlation
    return correlation


def ic_series(
    dates: Sequence[date],
    signals_by_date: Mapping[date, Mapping[str, float]],
    labels_by_date: Mapping[date, Mapping[str, float]],
    *,
    min_cross_section: int = 10,
    direction: str = "descending",
) -> tuple[dict[date, float], tuple[date, ...]]:
    """逐日 rank IC：返回 (有效 IC 序列, 被跳过日期)；缺信号/缺标签/截面不足/秩退化均跳过。"""
    threshold = _ensure_positive_int(min_cross_section, "min_cross_section")
    resolved_direction = _ensure_direction(direction)
    computed: dict[date, float] = {}
    skipped: list[date] = []
    for trading_date in dates:
        signal = signals_by_date.get(trading_date)
        label = labels_by_date.get(trading_date)
        if signal is None or label is None:
            skipped.append(trading_date)
            continue
        value = rank_ic(signal, label, min_cross_section=threshold, direction=resolved_direction)
        if value is None:
            skipped.append(trading_date)
        else:
            computed[trading_date] = value
    return computed, tuple(skipped)


def ic_summary(ics: Sequence[float], *, ddof: int = 1) -> dict[str, float]:
    """IC 汇总：mean/std(ddof 显式)/ICIR/t 值/计数；空序列全 0，std=0 时 ICIR/t=0（占位不抛）。"""
    resolved_ddof = _ensure_ddof(ddof)
    values = _finite_tuple(ics, "ics")
    count = len(values)
    if count == 0:
        return {"ic_mean": 0.0, "ic_std": 0.0, "icir": 0.0, "ic_tstat": 0.0, "ic_count": 0.0}
    mean = sum(values) / count
    std = 0.0
    # 常量序列直接判零：浮点均值噪声会在 ICIR/t 中放大成伪显著（同 metrics._sample_std 教训）
    if count > resolved_ddof and max(values) != min(values):
        std = math.sqrt(sum((value - mean) ** 2 for value in values) / (count - resolved_ddof))
    return {
        "ic_mean": mean,
        "ic_std": std,
        "icir": mean / std if std > 0.0 else 0.0,
        "ic_tstat": mean / (std / math.sqrt(count)) if std > 0.0 else 0.0,
        "ic_count": float(count),
    }


def _ordered_pairs(
    signal: Mapping[str, float], label: Mapping[str, float], direction: str
) -> list[tuple[str, float, float]]:
    """按评估方向从优到劣排序；平局以 instrument_id 升序稳定定序（确定性优先于任意性）。"""
    pairs = list(_aligned_pairs(signal, label))
    if direction == "descending":
        pairs.sort(key=lambda pair: (-pair[1], pair[0]))
    else:
        pairs.sort(key=lambda pair: (pair[1], pair[0]))
    return pairs


def topn_return(
    signal: Mapping[str, float],
    label: Mapping[str, float],
    *,
    top_n: int,
    direction: str = "descending",
) -> float | None:
    """TopN 等权平均标签收益；交集样本 < top_n → None（上层计数跳过）。"""
    resolved_direction = _ensure_direction(direction)
    resolved_top_n = _ensure_positive_int(top_n, "top_n")
    ordered = _ordered_pairs(signal, label, resolved_direction)
    if len(ordered) < resolved_top_n:
        return None
    return sum(pair[2] for pair in ordered[:resolved_top_n]) / resolved_top_n


def quintile_returns(
    signal: Mapping[str, float],
    label: Mapping[str, float],
    *,
    direction: str = "descending",
    q: int = 5,
) -> tuple[tuple[float, ...], bool] | None:
    """q 层等权收益（层 0=信号最优，按 direction）+ 严格单调标志；样本 < q → None。

    分层按从优到劣的名次等分（floor 边界，层大小差 ≤1）；平局以 instrument_id 升序稳定定序，
    同值可能跨层——这是显式等分语义（pandas qcut 遇重复边界丢层，本实现不采用）。
    单调=各层均值严格递增或严格递减（等价于层序与层均值 Spearman 绝对值=1）。
    """
    resolved_direction = _ensure_direction(direction)
    resolved_q = _ensure_positive_int(q, "q")
    ordered = _ordered_pairs(signal, label, resolved_direction)
    count = len(ordered)
    if count < resolved_q:
        return None
    layer_returns: list[float] = []
    for layer in range(resolved_q):
        start = layer * count // resolved_q
        end = (layer + 1) * count // resolved_q
        labels = [pair[2] for pair in ordered[start:end]]
        layer_returns.append(sum(labels) / len(labels))
    monotonic = all(lower < upper for lower, upper in pairwise(layer_returns)) or all(
        lower > upper for lower, upper in pairwise(layer_returns)
    )
    return tuple(layer_returns), monotonic
