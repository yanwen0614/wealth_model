"""evaluation 公共 API（规格 §10/§13）：账户层指标纯函数 + 口径辅助 + 默认评估引擎。

K04 分层：整段 `evaluate_account`（快照/NAV 复用同一 metrics 口径）与截面
`evaluate_cross_section(_range)`（收益由引擎从市场自算，含剔除计数与固定汇总键）。

依赖方向：evaluation → contracts（单向；仅 provider 包装在调用期延迟 import engine.MarketState，
避免静态反向依赖）；本包不得依赖三仓库代码。
"""

from .account import evaluate_account
from .cross_section import (
    CrossSectionResult,
    CrossSectionSpec,
    CrossSectionSummary,
    evaluate_cross_section,
    evaluate_cross_section_range,
)
from .methodology import DefaultEvaluationEngine, periodic_risk_free_rate, periods_per_year
from .metrics import (
    annualized_return,
    max_drawdown,
    period_returns,
    sharpe_ratio,
    total_return,
    turnover_ratio,
    volatility,
    win_rate_closed_position,
    win_rate_daily,
)
from .signal import ic_series, ic_summary, quintile_returns, rank_ic, topn_return

__all__ = [
    "CrossSectionResult",
    "CrossSectionSpec",
    "CrossSectionSummary",
    "DefaultEvaluationEngine",
    "annualized_return",
    "evaluate_account",
    "evaluate_cross_section",
    "evaluate_cross_section_range",
    "ic_series",
    "ic_summary",
    "max_drawdown",
    "period_returns",
    "periodic_risk_free_rate",
    "periods_per_year",
    "quintile_returns",
    "rank_ic",
    "sharpe_ratio",
    "topn_return",
    "total_return",
    "turnover_ratio",
    "volatility",
    "win_rate_closed_position",
    "win_rate_daily",
]
