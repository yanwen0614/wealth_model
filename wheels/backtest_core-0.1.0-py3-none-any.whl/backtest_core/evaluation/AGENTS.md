# evaluation - 指标层

纯函数指标计算，只依赖标准库 + `contracts`（**无 numpy / pandas**）。

## 关键约束

- 空序列 / 样本不足 → 返回 `0.0`（不抛错）。非有限值或非正 NAV → 抛 `ValueError`（禁止静默 NaN）。
- 口径必须通过 `MetricMethodology` 显式声明：`periods_per_year` / `annualization_basis` / `max_drawdown_sign` / `win_rate_definition` 等。**默认值即 Key Decision**。
- `evaluate_account`：从快照序列计算账户指标，与 `evaluate_cross_section` 共享同一 metrics 口径。
- `evaluate_cross_section` / `evaluate_cross_section_range`：收益由引擎从市场自算（T+1 open 入、第 holding_days 个有效 bar open 出），含剔除按原因计数。
- `DefaultEvaluationEngine`：wrapper 聚合 `evaluate_account` + `period_returns`，供 `account_runner` 使用。

## 不变量

- 输入输出显式：无副作用、不修改入参、不写全局状态。
- 汇总口径：mean/win 池化，topn/quantile 按期宏均。
- `flatten_metrics(prefix=False)` 跨层同名抛错（signal / paper / account 三层隔离）。
