"""账户层指标纯函数（规格 §10/§14.1）：只做确定性计算，口径由 MetricMethodology 声明。

设计约束：
- 只依赖标准库：三仓库可用同一公式离线复算，避免 numpy/pandas 精度差异造成结果不可比；
- 输入输出显式：无副作用、不修改入参、不写全局状态；
- 边界语义固定：空序列/样本不足返回 0.0；非有限值或非正 NAV 抛 ValueError（禁止静默 NaN）。
"""

import math
from collections.abc import Sequence

__all__ = [
    "annualized_return",
    "max_drawdown",
    "period_returns",
    "sharpe_ratio",
    "total_return",
    "turnover_ratio",
    "volatility",
    "win_rate_closed_position",
    "win_rate_daily",
]


def _finite_tuple(values: Sequence[float], field_name: str) -> tuple[float, ...]:
    """统一输入校验：拒绝 str/bytes、bool 与非有限值，返回独立 tuple 快照。"""
    if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
        raise ValueError(f"{field_name} must be a sequence of numbers, got {values!r}")  # noqa: TRY004
    checked: list[float] = []
    for value in values:
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"{field_name} items must be finite numbers, got {value!r}")
        checked.append(float(value))
    return tuple(checked)


def _positive_nav(nav: Sequence[float]) -> tuple[float, ...]:
    """NAV 必须为有限正数：非正净值让收益/回撤失真，入口即失败优于返回误导值。"""
    values = _finite_tuple(nav, "nav")
    for value in values:
        if value <= 0.0:
            raise ValueError(f"nav items must be positive, got {value!r}")
    return values


def _ensure_periods_per_year(periods_per_year: int) -> int:
    if isinstance(periods_per_year, bool) or not isinstance(periods_per_year, int) or periods_per_year < 1:
        raise ValueError(f"periods_per_year must be a positive int, got {periods_per_year!r}")
    return periods_per_year


def _ensure_ddof(ddof: int) -> int:
    if isinstance(ddof, bool) or not isinstance(ddof, int) or ddof not in (0, 1):
        raise ValueError(f"ddof must be 0 or 1, got {ddof!r}")
    return ddof


def _periodic_rate_from_annual(annual_rate: float, periods_per_year: int) -> float:
    """年利率复利折算到期利率 (1+rf)^(1/pp)-1；1+rf<=0 在实数域无解，显式失败。"""
    if isinstance(annual_rate, bool) or not isinstance(annual_rate, (int, float)) or not math.isfinite(annual_rate):
        raise ValueError(f"risk_free_rate_annual must be a finite number, got {annual_rate!r}")
    if 1.0 + annual_rate <= 0.0:
        raise ValueError(f"risk_free_rate_annual must be greater than -1, got {annual_rate!r}")
    return (1.0 + annual_rate) ** (1.0 / periods_per_year) - 1.0


def _mean(values: Sequence[float]) -> float:
    return sum(values) / len(values)


def _sample_std(values: Sequence[float], ddof: int) -> float:
    """中心化两遍法求标准差；常量序列直接判零，避免浮点均值噪声在 Sharpe 中放大成伪波动。"""
    if max(values) == min(values):
        return 0.0
    mean = _mean(values)
    variance = sum((value - mean) ** 2 for value in values) / (len(values) - ddof)
    return math.sqrt(variance)


def period_returns(nav: Sequence[float]) -> tuple[float, ...]:
    """相邻 NAV 简单收益 nav[t]/nav[t-1]-1；空/单点无可比区间，返回空 tuple。"""
    values = _positive_nav(nav)
    return tuple(values[index] / values[index - 1] - 1.0 for index in range(1, len(values)))


def total_return(nav: Sequence[float]) -> float:
    """区间累计收益 nav[-1]/nav[0]-1；空/单点无区间，语义固定为 0.0。"""
    values = _positive_nav(nav)
    if len(values) < 2:
        return 0.0
    return values[-1] / values[0] - 1.0


def annualized_return(nav: Sequence[float], periods_per_year: int) -> float:
    """复利年化 (nav[-1]/nav[0])^(pp/n_periods)-1，n_periods=len(nav)-1。

    按实际收益期数折算而非快照数全除：快照数=收益期数+1，误用会系统性低估年化
    （goal AUDIT M2 教训）。
    """
    periods = _ensure_periods_per_year(periods_per_year)
    values = _positive_nav(nav)
    n_periods = len(values) - 1
    if n_periods < 1:  # 空序列 n_periods=-1、单点 0：都无可比区间
        return 0.0
    growth = values[-1] / values[0]
    return growth ** (periods / n_periods) - 1.0


def max_drawdown(nav: Sequence[float]) -> float:
    """最大回撤（正值口径）：max((历史峰值-当前值)/历史峰值)；空/单点 → 0.0。"""
    values = _positive_nav(nav)
    peak = 0.0
    drawdown = 0.0
    for value in values:
        peak = max(peak, value)
        drawdown = max(drawdown, (peak - value) / peak)
    return drawdown


def volatility(returns: Sequence[float], periods_per_year: int, ddof: int) -> float:
    """年化波动率：样本标准差(ddof)×sqrt(pp)；len(returns)<=ddof 视为样本不足 → 0.0。"""
    periods = _ensure_periods_per_year(periods_per_year)
    resolved_ddof = _ensure_ddof(ddof)
    values = _finite_tuple(returns, "returns")
    if len(values) <= resolved_ddof:
        return 0.0
    return _sample_std(values, resolved_ddof) * math.sqrt(periods)


def sharpe_ratio(
    returns: Sequence[float],
    risk_free_rate_annual: float,
    periods_per_year: int,
    ddof: int,
) -> float:
    """年化 Sharpe：(mean(excess)/std(excess, ddof))×sqrt(pp)，rf 先复利折算到期。

    零波动或样本不足返回 0.0 而非抛异常：无估计量时 0.0 是显式占位，调用方可凭样本数判断。
    """
    periods = _ensure_periods_per_year(periods_per_year)
    resolved_ddof = _ensure_ddof(ddof)
    periodic_rf = _periodic_rate_from_annual(risk_free_rate_annual, periods)
    values = _finite_tuple(returns, "returns")
    if len(values) <= resolved_ddof:
        return 0.0
    excess = tuple(value - periodic_rf for value in values)
    std = _sample_std(excess, resolved_ddof)
    if std == 0.0:
        return 0.0
    return _mean(excess) / std * math.sqrt(periods)


def win_rate_daily(returns: Sequence[float]) -> float:
    """日收益胜率：r>0 计胜（r=0 既非胜也非负）；空 → 0.0。"""
    values = _finite_tuple(returns, "returns")
    if not values:
        return 0.0
    return sum(1 for value in values if value > 0.0) / len(values)


def win_rate_closed_position(closed_returns: Sequence[float]) -> float:
    """已平仓胜率：盈利平仓笔数占比；空 → 0.0（无样本不虚构）。"""
    values = _finite_tuple(closed_returns, "closed_returns")
    if not values:
        return 0.0
    return sum(1 for value in values if value > 0.0) / len(values)


def turnover_ratio(trade_amounts: Sequence[float], average_nav: float) -> float:
    """双边减半换手率：sum(|成交额|)/(2×平均 NAV)。

    买卖各计一次 amount，除以 2 后一次完整往返换手为 1.0；average_nav<=0 无意义 → 0.0。
    """
    amounts = _finite_tuple(trade_amounts, "trade_amounts")
    if isinstance(average_nav, bool) or not isinstance(average_nav, (int, float)) or not math.isfinite(average_nav):
        raise ValueError(f"average_nav must be a finite number, got {average_nav!r}")
    if average_nav <= 0.0:
        return 0.0
    return sum(abs(amount) for amount in amounts) / (2.0 * average_nav)
