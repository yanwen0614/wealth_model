"""截面评估（K04）：信号日截面按标的自身 bar 序列推进，收益由引擎从市场自算。

口径（R6：本轮按标的自身 bar 序列，跨标的统一日历留阶段 3）：
- 入场 = signal_date 之后首个有效交易日（T+1）open；出场 = 入场后第 holding_days 个有效交易日 open；
- 停牌/缺价/窗口不足 → 剔除 + 按原因计数（禁止静默丢弃）；
- 选择评估：top_n 等权收益/胜率；排序评估：rank IC（先秩后 Pearson）与分位收益；
- `market` 接受 MarketView（get_bars 批量）或 MarketDataProvider（内部用 MarketState 包装）。

占位语义：无有效样本时 mean_return/win_rate 记 0.0（配合 evaluated_count 判读）；不可计算的
选择/排序指标（topn_mean_return/topn_win_rate/rank_ic）记 None，由 warnings 与计数显式标记。
"""

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date, timedelta
from itertools import pairwise
from types import MappingProxyType

from ..contracts.enums import PredictionType
from ..contracts.market import MarketBar
from ..contracts.prediction import Prediction
from ..contracts.protocols import MarketDataProvider, MarketView
from ..contracts.validation import ensure_calendar_date, ensure_finite, ensure_non_empty_str
from . import signal as signal_math

__all__ = [
    "CrossSectionResult",
    "CrossSectionSpec",
    "CrossSectionSummary",
    "evaluate_cross_section",
    "evaluate_cross_section_range",
]

# 固定分位点（任务口径）：各点代表“方向排序后前 p 分位”的累计组合收益
QUANTILE_POINTS: tuple[float, ...] = (0.1, 0.25, 0.5, 0.75, 0.9)
_SUPPORTED_ENTRY_MODES = ("t1_open",)
_SUPPORTED_EXIT_MODES = ("open",)
# 截面评估只接受可排序的语义类型（规格 §11.1：目标权重/action 不得伪装成排序信号）
_EVALUABLE_PREDICTION_TYPES = frozenset({PredictionType.PREDICTED_RETURN, PredictionType.RANKING_SCORE})
# 探测窗口（日历日）：吸收周末/节假日与短停牌；窗口内不足 holding_days 个有效 bar 即计 insufficient_window
_PROBE_PADDING_DAYS = 30
_EXCLUSION_REASONS: tuple[str, ...] = ("missing_score", "no_next_bar", "suspended", "missing_price", "insufficient_window")


def _ensure_count(value: object, field_name: str) -> None:
    """计数类字段：非负 int（bool 是 int 子类但语义非法），与 skipped_counts 防护一致。"""
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative int, got {value!r}")


def _ensure_finite_or_none(value: float | None, field_name: str) -> None:
    """可空数值：None 表示不可计算，非 None 必须有限（禁止 NaN/inf 流入结果）。"""
    if value is None:
        return
    ensure_finite(value, field_name)


@dataclass(frozen=True)
class CrossSectionSpec:
    """截面评估口径：默认 T+1 open 入、持有 holding_days 个交易日后 open 出。"""

    holding_days: int = 5
    entry_mode: str = "t1_open"
    exit_mode: str = "open"
    direction: str = "descending"
    top_n: int = 10
    n_quantiles: int = 5
    min_cross_section: int = 10

    def __post_init__(self) -> None:
        signal_math._ensure_positive_int(self.holding_days, "holding_days")
        if self.entry_mode not in _SUPPORTED_ENTRY_MODES:
            raise ValueError(f"entry_mode must be one of {_SUPPORTED_ENTRY_MODES}, got {self.entry_mode!r}")
        if self.exit_mode not in _SUPPORTED_EXIT_MODES:
            raise ValueError(f"exit_mode must be one of {_SUPPORTED_EXIT_MODES}, got {self.exit_mode!r}")
        signal_math._ensure_direction(self.direction)
        signal_math._ensure_positive_int(self.top_n, "top_n")
        signal_math._ensure_positive_int(self.n_quantiles, "n_quantiles")
        if self.n_quantiles < 2:
            raise ValueError(f"n_quantiles must be >= 2 to form layers, got {self.n_quantiles!r}")
        signal_math._ensure_positive_int(self.min_cross_section, "min_cross_section")


@dataclass(frozen=True)
class CrossSectionResult:
    """单期截面评估结果：选择/排序指标 + 逐原因剔除计数 + 口径与告警。

    - `quantile_returns`：固定点 (0.1/0.25/0.5/0.75/0.9) → 方向排序后“前 p 分位”累计组合等权收益；
    - `layer_returns`/`layer_monotonic`：n_quantiles 等数量分层（从优到劣）层均值与严格单调标志；
    - `exclusions`：instrument 级计数，原因为 missing_score/no_next_bar/suspended/missing_price/insufficient_window；
    - 0.0 为无样本占位（配合 evaluated_count 判读）；None 表示不可计算（与 warnings 同步）。
    """

    signal_date: date
    spec: CrossSectionSpec
    universe_count: int
    evaluated_count: int
    exclusions: Mapping[str, int]
    mean_return: float
    win_rate: float
    topn_mean_return: float | None
    topn_win_rate: float | None
    topn_selected: int
    rank_ic: float | None
    quantile_returns: tuple[tuple[float, float], ...]
    layer_returns: tuple[float, ...]
    layer_monotonic: bool | None
    warnings: tuple[str, ...]

    def __post_init__(self) -> None:
        """冻结并校验结果形状：计数非负且自洽、数值有限、quantile 点合法（MEDIUM-1）。

        与 AccountSnapshot 同级防护：外部直接构造坏结果（负计数/NaN/inf/错误形状）在入口失败，
        不允许污染下游汇总与序列化。
        """
        ensure_calendar_date(self.signal_date, "signal_date")
        if not isinstance(self.spec, CrossSectionSpec):
            raise ValueError(f"spec must be a CrossSectionSpec, got {self.spec!r}")  # noqa: TRY004
        _ensure_count(self.universe_count, "universe_count")
        _ensure_count(self.evaluated_count, "evaluated_count")
        _ensure_count(self.topn_selected, "topn_selected")
        if self.evaluated_count > self.universe_count:
            raise ValueError(
                f"evaluated_count must be <= universe_count, got {self.evaluated_count!r} > {self.universe_count!r}"
            )
        if self.topn_selected > self.evaluated_count:
            raise ValueError(
                f"topn_selected must be <= evaluated_count, got {self.topn_selected!r} > {self.evaluated_count!r}"
            )
        ensure_finite(self.mean_return, "mean_return")
        ensure_finite(self.win_rate, "win_rate")
        _ensure_finite_or_none(self.topn_mean_return, "topn_mean_return")
        _ensure_finite_or_none(self.topn_win_rate, "topn_win_rate")
        _ensure_finite_or_none(self.rank_ic, "rank_ic")
        if isinstance(self.quantile_returns, (str, bytes)) or not isinstance(self.quantile_returns, Sequence):
            raise ValueError(  # noqa: TRY004
                f"quantile_returns must be a sequence of (point, return) pairs, got {self.quantile_returns!r}"
            )
        for index, pair in enumerate(self.quantile_returns):
            if isinstance(pair, (str, bytes)) or not isinstance(pair, Sequence) or len(pair) != 2:
                raise ValueError(f"quantile_returns[{index}] must be a (point, return) pair, got {pair!r}")
            point, value = pair
            ensure_finite(point, f"quantile_returns[{index}][0]")
            if not 0.0 < float(point) <= 1.0:
                raise ValueError(f"quantile_returns[{index}][0] must be within (0, 1], got {point!r}")
            ensure_finite(value, f"quantile_returns[{index}][1]")
        if isinstance(self.layer_returns, (str, bytes)) or not isinstance(self.layer_returns, Sequence):
            raise ValueError(f"layer_returns must be a sequence of numbers, got {self.layer_returns!r}")  # noqa: TRY004
        for index, value in enumerate(self.layer_returns):
            ensure_finite(value, f"layer_returns[{index}]")
        if isinstance(self.warnings, (str, bytes)) or not isinstance(self.warnings, Sequence):
            raise ValueError(f"warnings must be a sequence of str, got {self.warnings!r}")  # noqa: TRY004
        for warning in self.warnings:
            ensure_non_empty_str(warning, "warnings item")
        if not isinstance(self.exclusions, Mapping):
            raise ValueError(f"exclusions must be a mapping, got {self.exclusions!r}")  # noqa: TRY004
        frozen: dict[str, int] = {}
        for key, value in self.exclusions.items():
            ensure_non_empty_str(key, "exclusions key")
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"exclusions[{key!r}] must be a non-negative int, got {value!r}")
            frozen[key] = value
        object.__setattr__(self, "exclusions", MappingProxyType(frozen))


@dataclass(frozen=True)
class CrossSectionSummary:
    """区间截面汇总：逐期结果 + 固定汇总键（无样本一律 0.0 占位，键集合恒定）。"""

    spec: CrossSectionSpec
    results: tuple[CrossSectionResult, ...]
    metrics: Mapping[str, float]
    warnings: tuple[str, ...]

    def __post_init__(self) -> None:
        """冻结并校验汇总形状：results 元素类型、metrics 有限、warnings 合法（MEDIUM-1）。"""
        if not isinstance(self.spec, CrossSectionSpec):
            raise ValueError(f"spec must be a CrossSectionSpec, got {self.spec!r}")  # noqa: TRY004
        if isinstance(self.results, (str, bytes)) or not isinstance(self.results, Sequence):
            raise ValueError(f"results must be a sequence of CrossSectionResult, got {self.results!r}")  # noqa: TRY004
        checked_results: list[CrossSectionResult] = []
        for result in self.results:
            if not isinstance(result, CrossSectionResult):
                raise ValueError(f"results items must be CrossSectionResult, got {result!r}")  # noqa: TRY004
            checked_results.append(result)
        object.__setattr__(self, "results", tuple(checked_results))
        if not isinstance(self.metrics, Mapping):
            raise ValueError(f"metrics must be a mapping, got {self.metrics!r}")  # noqa: TRY004
        checked: dict[str, float] = {}
        for key, value in self.metrics.items():
            ensure_non_empty_str(key, "metrics key")
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"metrics[{key!r}] must be a finite number, got {value!r}")
            checked[key] = float(value)
        if isinstance(self.warnings, (str, bytes)) or not isinstance(self.warnings, Sequence):
            raise ValueError(f"warnings must be a sequence of str, got {self.warnings!r}")  # noqa: TRY004
        for warning in self.warnings:
            ensure_non_empty_str(warning, "warnings item")
        object.__setattr__(self, "metrics", MappingProxyType(checked))
        object.__setattr__(self, "warnings", tuple(self.warnings))


def _resolve_spec(spec: CrossSectionSpec | None) -> CrossSectionSpec:
    if spec is None:
        return CrossSectionSpec()
    if not isinstance(spec, CrossSectionSpec):
        raise ValueError(f"spec must be a CrossSectionSpec or None, got {spec!r}")  # noqa: TRY004
    return spec


def _to_market_view(market: MarketView | MarketDataProvider) -> MarketView:
    """MarketView 直接消费；注入 MarketDataProvider 时用 MarketState 包装（批量+缓存同源）。"""
    if isinstance(market, MarketView):
        return market
    if isinstance(market, MarketDataProvider):
        # 延迟导入：MarketState 属 engine 层，模块级 import 会形成 evaluation→engine 静态反向依赖
        from ..engine.market_state import MarketState

        return MarketState(market)
    raise ValueError(
        f"market must implement MarketView or MarketDataProvider, got {market!r}"
    )


def _normalize_instruments(instruments: str | Sequence[str]) -> tuple[str, ...]:
    """str 视为单标的；序列去重并升序排序，使求和/评估顺序与输入构造顺序无关。"""
    if isinstance(instruments, str):
        raw: tuple[object, ...] = (instruments,)
    elif isinstance(instruments, (bytes, bytearray)) or not isinstance(instruments, Sequence):
        raise ValueError(  # noqa: TRY004
            f"instruments must be a str or sequence of str, got {instruments!r}"
        )
    else:
        raw = tuple(instruments)
    checked: list[str] = []
    for item in raw:
        if not isinstance(item, str):
            raise ValueError(f"instruments items must be non-empty str, got {item!r}")  # noqa: TRY004
        ensure_non_empty_str(item, "instruments item")
        checked.append(item)
    return tuple(sorted(set(checked)))


def _scores_from_predictions(predictions: Sequence[Prediction], spec: CrossSectionSpec) -> dict[str, float]:
    """Prediction 序列 → {instrument_id: value}：类型/方向/重复标的显式失败。"""
    if isinstance(predictions, (str, bytes)) or not isinstance(predictions, Sequence):
        raise ValueError(  # noqa: TRY004
            f"scores must be a mapping or a sequence of Prediction, got {predictions!r}"
        )
    values: dict[str, float] = {}
    for prediction in predictions:
        if not isinstance(prediction, Prediction):
            raise ValueError(f"scores items must be Prediction, got {prediction!r}")  # noqa: TRY004
        if prediction.prediction_type not in _EVALUABLE_PREDICTION_TYPES:
            raise ValueError(
                f"scores: prediction_type {prediction.prediction_type!r} is not an evaluable ranking signal"
            )
        if prediction.ranking_direction != spec.direction:
            raise ValueError(
                f"scores: ranking_direction {prediction.ranking_direction!r} conflicts with "
                f"evaluation direction {spec.direction!r}"
            )
        if prediction.instrument_id in values:
            raise ValueError(f"scores: duplicate prediction for {prediction.instrument_id!r}")
        values[prediction.instrument_id] = prediction.value
    return values


def _resolve_scores(
    scores: Mapping[str, float] | Sequence[Prediction] | None, spec: CrossSectionSpec
) -> dict[str, float] | None:
    if scores is None:
        return None
    if isinstance(scores, Mapping):
        return signal_math._finite_mapping(scores, "scores")
    return _scores_from_predictions(scores, spec)


def _resolve_universe(
    instruments: Sequence[str] | None, scores: Mapping[str, float] | None
) -> tuple[tuple[str, ...], int]:
    """返回 (评估域, missing_score 计数)：评估域取有分数标的；无分数请求标的显式计数。"""
    if scores is None:
        if instruments is None:
            raise ValueError("exactly one of instruments or scores must be provided")
        return _normalize_instruments(instruments), 0
    scored = tuple(sorted(scores))
    if instruments is None:
        return scored, 0
    requested = _normalize_instruments(instruments)
    requested_set = set(requested)
    outside = [instrument for instrument in scored if instrument not in requested_set]
    if outside:
        raise ValueError(f"scores contain instruments outside the requested universe: {outside[:5]!r}")
    missing = sum(1 for instrument in requested if instrument not in scores)
    return tuple(instrument for instrument in requested if instrument in scores), missing


def _probe_end(signal_date: date, spec: CrossSectionSpec) -> date:
    """探测窗口终点：按 holding_days 放大并加固定余量，吸收周末/短停牌；超出即窗口不足。"""
    return signal_date + timedelta(days=spec.holding_days * 3 + _PROBE_PADDING_DAYS)


def _forward_bars(
    view: MarketView, instrument_id: str, signal_date: date, spec: CrossSectionSpec
) -> tuple[MarketBar, ...]:
    """signal_date 之后、探测窗口内的 bar 序列（升序）；键缺失/类型错误显式失败。"""
    probe_end = _probe_end(signal_date, spec)
    raw = view.get_bars(instrument_id, signal_date, probe_end).get(instrument_id)
    if raw is None:
        raise ValueError(f"market view returned no key for {instrument_id!r} in get_bars result")
    if isinstance(raw, (str, bytes)) or not isinstance(raw, Sequence):
        raise ValueError(  # noqa: TRY004
            f"market view bars must be a sequence of MarketBar, got {raw!r}"
        )
    selected: list[MarketBar] = []
    for bar in raw:
        if not isinstance(bar, MarketBar):
            raise ValueError(f"market view bars items must be MarketBar, got {bar!r}")  # noqa: TRY004
        if bar.instrument_id != instrument_id:
            raise ValueError(f"market view returned bar for {bar.instrument_id!r} when {instrument_id!r} requested")
        if signal_date < bar.trading_date <= probe_end:
            selected.append(bar)
    selected.sort(key=lambda bar: bar.trading_date)
    return tuple(selected)


def _forward_return(bars: Sequence[MarketBar], holding_days: int) -> tuple[float | None, str | None]:
    """按标的自身 bar 序列推进：T+1 首个有效交易日 open 入、其后第 holding_days 个有效 bar open 出。

    返回 (收益, 剔除原因)：原因 None 表示成功；停牌 bar 跳过，缺价 bar 立即剔除（分原因计数）。
    """
    entry_price: float | None = None
    entry_index = -1
    saw_bar = False
    for index, bar in enumerate(bars):
        saw_bar = True
        if not bar.is_trading:
            continue
        if bar.open is None or bar.open <= 0.0:
            return None, "missing_price"
        entry_price = bar.open
        entry_index = index
        break
    if entry_price is None:
        return None, "suspended" if saw_bar else "no_next_bar"
    valid = 0
    for bar in bars[entry_index + 1 :]:
        if not bar.is_trading:
            continue
        if bar.open is None or bar.open <= 0.0:
            return None, "missing_price"
        valid += 1
        if valid == holding_days:
            exit_price = bar.open
            return exit_price / entry_price - 1.0, None
    return None, "insufficient_window"


def _evaluate_period(
    *,
    signal_date: date,
    market: MarketView | MarketDataProvider,
    instruments: Sequence[str] | None,
    scores: Mapping[str, float] | Sequence[Prediction] | None,
    spec: CrossSectionSpec,
) -> tuple[CrossSectionResult, dict[str, float]]:
    """单期评估核心：返回 (结果, 有效收益映射)，供 range 汇总复用同一份收益样本。"""
    score_map = _resolve_scores(scores, spec)
    universe, missing_score = _resolve_universe(instruments, score_map)
    view = _to_market_view(market)
    returns: dict[str, float] = {}
    exclusions: dict[str, int] = {}
    for instrument_id in universe:
        bars = _forward_bars(view, instrument_id, signal_date, spec)
        value, reason = _forward_return(bars, spec.holding_days)
        if reason is None:
            assert value is not None  # _forward_return 不变量：无原因必有收益
            returns[instrument_id] = value
        else:
            exclusions[reason] = exclusions.get(reason, 0) + 1
    if missing_score:
        exclusions["missing_score"] = missing_score

    count = len(returns)
    mean_return = sum(returns.values()) / count if count else 0.0
    win_rate = sum(1 for value in returns.values() if value > 0.0) / count if count else 0.0
    warnings: list[str] = []
    rank_ic_value: float | None = None
    topn_mean: float | None = None
    topn_win: float | None = None
    topn_selected = 0
    quantiles: list[tuple[float, float]] = []
    layers: tuple[float, ...] = ()
    monotonic: bool | None = None
    if score_map is not None:
        if count == 0:
            warnings.append("cross-section: no evaluated instruments; ranking metrics omitted")
        elif count < spec.min_cross_section:
            warnings.append(
                f"cross-section: {count} evaluated < min_cross_section {spec.min_cross_section}; rank_ic omitted"
            )
        else:
            rank_ic_value = signal_math.rank_ic(
                score_map, returns, min_cross_section=spec.min_cross_section, direction=spec.direction
            )
            if rank_ic_value is None:
                warnings.append("cross-section: degenerate ranking (constant scores/returns); rank_ic omitted")
    if score_map is not None and count:
        ordered = signal_math._ordered_pairs(score_map, returns, spec.direction)
        if len(ordered) >= spec.top_n:
            selected = ordered[: spec.top_n]
            topn_selected = spec.top_n
            topn_mean = sum(pair[2] for pair in selected) / spec.top_n
            topn_win = sum(1 for pair in selected if pair[2] > 0.0) / spec.top_n
        else:
            warnings.append(f"topn: {len(ordered)} evaluated < top_n {spec.top_n}; top_n return omitted")
        # 固定分位点：按方向排序后的前 p 分位累计组合等权收益（每个点至少覆盖 1 只）
        for point in QUANTILE_POINTS:
            size = max(1, math.ceil(point * len(ordered)))
            quantiles.append((point, sum(pair[2] for pair in ordered[:size]) / size))
        layer_result = signal_math.quintile_returns(
            score_map, returns, direction=spec.direction, q=spec.n_quantiles
        )
        if layer_result is None:
            warnings.append(f"layers: {len(ordered)} evaluated < n_quantiles {spec.n_quantiles}; layers omitted")
        else:
            layers, monotonic = layer_result
    result = CrossSectionResult(
        signal_date=signal_date,
        spec=spec,
        universe_count=len(universe),
        evaluated_count=count,
        exclusions=MappingProxyType(dict(sorted(exclusions.items()))),
        mean_return=mean_return,
        win_rate=win_rate,
        topn_mean_return=topn_mean,
        topn_win_rate=topn_win,
        topn_selected=topn_selected,
        rank_ic=rank_ic_value,
        quantile_returns=tuple(quantiles),
        layer_returns=layers,
        layer_monotonic=monotonic,
        warnings=tuple(warnings),
    )
    return result, returns


def evaluate_cross_section(
    *,
    signal_date: date,
    market: MarketView | MarketDataProvider,
    instruments: Sequence[str] | None = None,
    scores: Mapping[str, float] | Sequence[Prediction] | None = None,
    spec: CrossSectionSpec | None = None,
) -> CrossSectionResult:
    """评估单期截面：收益由引擎从 market 自算（T+1 open 入 / 第 holding_days 个有效 bar open 出）。

    `scores` 接受 Mapping[str,float]（任意有限分数）或 Sequence[Prediction]（类型/方向校验）；
    序列内可混用 `predicted_return` / `ranking_score`，数值直接参与排序、不做类型归一，跨类型
    量纲可比性由调用方保证；仅提供 `instruments` 时退化为无排序评估（mean/win，无 IC/分位）；
    剔除按原因计数不静默。
    """
    ensure_calendar_date(signal_date, "signal_date")
    resolved = _resolve_spec(spec)
    result, _ = _evaluate_period(
        signal_date=signal_date, market=market, instruments=instruments, scores=scores, spec=resolved
    )
    return result


def _ensure_signal_dates(signal_dates: Sequence[date]) -> tuple[date, ...]:
    if isinstance(signal_dates, (str, bytes)) or not isinstance(signal_dates, Sequence):
        raise ValueError(f"signal_dates must be a sequence of date, got {signal_dates!r}")  # noqa: TRY004
    ordered = tuple(signal_dates)
    for item in ordered:
        ensure_calendar_date(item, "signal_dates item")
    for previous, current in pairwise(ordered):
        if current <= previous:
            raise ValueError("signal_dates must be strictly ascending")
    return ordered


def evaluate_cross_section_range(
    *,
    signal_dates: Sequence[date],
    market: MarketView | MarketDataProvider,
    selections_by_date: Mapping[date, Sequence[str]] | None = None,
    scores_by_date: Mapping[date, Sequence[Prediction] | Mapping[str, float]] | None = None,
    spec: CrossSectionSpec | None = None,
) -> CrossSectionSummary:
    """逐期截面评估并汇总：结果含逐期 `CrossSectionResult` 与固定键 metrics（无样本 0.0 占位）。

    汇总口径（MEDIUM-2 显式声明）：
    - `mean_return` / `win_rate` 为**池化**口径（micro 平均，全样本）：先合并各期 instrument 级
      样本再求平均，样本数多的期权重更大；
    - `topn_mean_return` / `quantile_*_return` 为**按期宏均**（macro 平均，按可计算期等权）：
      topn 仅在 top_n 可计算时计入，quantile 各点在可计算期计入；
    - `universe_count` / `evaluated_count` 与 `*_count` 类为各期求和（非均值），剔除计数按原因累计；
    - `ic_*` / `layer_*` 汇总口径与 `ic_summary` / 分层评估一致。

    metrics 键固定为：period_count/date_missing_skipped/universe_count/evaluated_count/
    mean_return/win_rate/topn_mean_return/topn_count/topn_skipped/cross_section_skipped/
    degenerate_skipped/layer_monotonic_ratio/layer_count、ic_summary 五键、
    各剔除原因 `*_skipped`、以及 quantile_10/25/50/75/90_return；键集合与输入样本数无关。

    缺失当日期（两映射都没有该日输入）计入 date_missing_skipped；scores_by_date 缺席的日期
    只做无排序评估，不污染 IC/分位计数。
    """
    resolved = _resolve_spec(spec)
    ordered_dates = _ensure_signal_dates(signal_dates)
    if selections_by_date is None and scores_by_date is None:
        raise ValueError("at least one of selections_by_date or scores_by_date must be provided")
    if selections_by_date is not None and not isinstance(selections_by_date, Mapping):
        raise ValueError(
            f"selections_by_date must be a mapping or None, got {selections_by_date!r}"
        )
    if scores_by_date is not None and not isinstance(scores_by_date, Mapping):
        raise ValueError(f"scores_by_date must be a mapping or None, got {scores_by_date!r}")

    results: list[CrossSectionResult] = []
    warnings: list[str] = []
    pooled_returns: list[float] = []
    ic_values: list[float] = []
    topn_values: list[float] = []
    monotonic_flags: list[bool] = []
    exclusion_totals = dict.fromkeys(_EXCLUSION_REASONS, 0)
    quantile_sums = dict.fromkeys(QUANTILE_POINTS, 0.0)
    quantile_counts = dict.fromkeys(QUANTILE_POINTS, 0)
    date_missing = cross_section_skipped = degenerate_skipped = topn_skipped = 0
    for signal_date in ordered_dates:
        scores = scores_by_date.get(signal_date) if scores_by_date is not None else None
        selections = selections_by_date.get(signal_date) if selections_by_date is not None else None
        if scores is None and selections is None:
            date_missing += 1
            continue
        result, returns = _evaluate_period(
            signal_date=signal_date, market=market, instruments=selections, scores=scores, spec=resolved
        )
        results.append(result)
        warnings.extend(result.warnings)
        pooled_returns.extend(returns.values())
        for reason, number in result.exclusions.items():
            exclusion_totals[reason] = exclusion_totals.get(reason, 0) + number
        if result.rank_ic is not None:
            ic_values.append(result.rank_ic)
        elif scores is not None:
            if result.evaluated_count < resolved.min_cross_section:
                cross_section_skipped += 1
            else:
                degenerate_skipped += 1
        if result.topn_mean_return is None:
            topn_skipped += 1
        else:
            topn_values.append(result.topn_mean_return)
        if result.layer_monotonic is not None:
            monotonic_flags.append(result.layer_monotonic)
        for point, value in result.quantile_returns:
            quantile_sums[point] += value
            quantile_counts[point] += 1
    sample_count = len(pooled_returns)
    metrics: dict[str, float] = {
        "period_count": float(len(results)),
        "date_missing_skipped": float(date_missing),
        "universe_count": float(sum(result.universe_count for result in results)),
        "evaluated_count": float(sample_count),
        "mean_return": sum(pooled_returns) / sample_count if sample_count else 0.0,
        "win_rate": sum(1 for value in pooled_returns if value > 0.0) / sample_count if sample_count else 0.0,
        "topn_mean_return": sum(topn_values) / len(topn_values) if topn_values else 0.0,
        "topn_count": float(len(topn_values)),
        "topn_skipped": float(topn_skipped),
        "cross_section_skipped": float(cross_section_skipped),
        "degenerate_skipped": float(degenerate_skipped),
        "layer_monotonic_ratio": (
            sum(1 for flag in monotonic_flags if flag) / len(monotonic_flags) if monotonic_flags else 0.0
        ),
        "layer_count": float(len(monotonic_flags)),
    }
    metrics.update(signal_math.ic_summary(ic_values))
    for reason in _EXCLUSION_REASONS:
        metrics[f"{reason}_skipped"] = float(exclusion_totals[reason])
    for point in QUANTILE_POINTS:
        point_count = quantile_counts[point]
        metrics[f"quantile_{round(point * 100)}_return"] = (
            quantile_sums[point] / point_count if point_count else 0.0
        )
    return CrossSectionSummary(
        spec=resolved, results=tuple(results), metrics=MappingProxyType(metrics), warnings=tuple(warnings)
    )
