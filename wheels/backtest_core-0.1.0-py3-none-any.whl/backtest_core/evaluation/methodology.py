"""账户指标口径辅助与默认评估引擎（规格 §10/§13）：把 MetricMethodology 声明落为可执行口径。

分层原因：contracts 只描述结果形状，不承载公式；engine/io/三仓库统一调用本层，
避免各仓库自行解释 methodology 造成同一结果数值不可比。
"""

from collections.abc import Sequence
from dataclasses import replace
from datetime import date

from ..contracts.enums import EventStatus
from ..contracts.events import TradeEvent
from ..contracts.result import EvaluationResult, MetricMethodology
from . import metrics

__all__ = ["DefaultEvaluationEngine", "periodic_risk_free_rate", "periods_per_year"]

_CALENDAR_DAYS_PER_YEAR = 365
# 只有真实成交计入换手：skipped/locked 无资金交换，即使契约允许其 amount 非零
_FILLED_STATUSES = frozenset({EventStatus.FILLED, EventStatus.FORCED_EXIT})
_WIN_RATE_MISSING_WARNING = "win_rate omitted: win_rate_definition=closed_position requires closed_returns"


def _ensure_methodology(methodology: MetricMethodology) -> MetricMethodology:
    if not isinstance(methodology, MetricMethodology):
        raise ValueError(f"methodology must be a MetricMethodology, got {methodology!r}")  # noqa: TRY004
    return methodology


def periods_per_year(methodology: MetricMethodology) -> int:
    """年化期数：trading_days 用声明的年交易日数（默认 242）；calendar_days 固定 365。"""
    _ensure_methodology(methodology)
    if methodology.annualization_basis == "calendar_days":
        return _CALENDAR_DAYS_PER_YEAR
    return methodology.trading_days_per_year


def periodic_risk_free_rate(methodology: MetricMethodology) -> float:
    """无风险年利率复利折算到期 (1+rf)^(1/pp)-1，与 sharpe_ratio 内部口径一致。"""
    _ensure_methodology(methodology)
    return metrics._periodic_rate_from_annual(methodology.risk_free_rate_annual, periods_per_year(methodology))


def _filled_amounts(trades: Sequence[TradeEvent]) -> tuple[float, ...]:
    """仅 filled/forced_exit 计入换手：其余状态未发生资金交换。"""
    return tuple(trade.amount for trade in trades if trade.status in _FILLED_STATUSES)


def _mean_nav(nav: Sequence[float]) -> float:
    return sum(nav) / len(nav)


class DefaultEvaluationEngine:
    """规格 §10 EvaluationEngine 的结构化默认实现：只重算 account 层，signal/paper 原样保留。"""

    def evaluate(
        self,
        result: EvaluationResult,
        methodology: MetricMethodology,
        *,
        nav: Sequence[float] | None = None,
        trade_end: date | None = None,
        closed_returns: Sequence[float] | None = None,
        average_nav: float | None = None,
    ) -> EvaluationResult:
        """按 methodology 重算 account_metrics；nav 缺失/空序列时仅写入口径声明，不虚构指标。

        覆盖策略：重算键覆盖同名旧键，其余键保留（适配器自定义指标不被吞掉）。
        win_rate 按 methodology.win_rate_definition 选口径：daily_return 取 nav 收益；
        closed_position 用 closed_returns，缺输入（None）时删除可能残留的旧同名值并追加 warning，
        防止 A 口径数值冒充 B 口径；空序列含义为"无平仓样本"，胜率记 0.0。
        turnover 分母优先用 average_nav，未提供时取 nav 均值；无 nav 时 closed_returns 不参与。
        """
        if not isinstance(result, EvaluationResult):
            raise ValueError(f"result must be an EvaluationResult, got {result!r}")  # noqa: TRY004
        _ensure_methodology(methodology)
        warnings = list(result.warnings)  # 显式复制：replace 共享可变列表会让两个结果互相污染
        if nav is None:
            return replace(result, methodology=methodology, warnings=warnings)
        if isinstance(nav, (str, bytes)) or not isinstance(nav, Sequence):
            raise ValueError(f"nav must be a sequence of numbers, got {nav!r}")  # noqa: TRY004
        if len(nav) == 0:
            return replace(result, methodology=methodology, warnings=warnings)

        periods = periods_per_year(methodology)
        returns = metrics.period_returns(nav)
        account = dict(result.account_metrics)
        account["total_return"] = metrics.total_return(nav)
        account["annualized_return"] = metrics.annualized_return(nav, periods)
        account["volatility"] = metrics.volatility(returns, periods, methodology.sharpe_ddof)
        account["sharpe"] = metrics.sharpe_ratio(
            returns, methodology.risk_free_rate_annual, periods, methodology.sharpe_ddof
        )
        account["max_drawdown"] = metrics.max_drawdown(nav)
        average = average_nav if average_nav is not None else _mean_nav(nav)
        trades = result.trades if trade_end is None else tuple(
            trade for trade in result.trades if trade.execution_time.date() <= trade_end
        )
        account["turnover"] = metrics.turnover_ratio(_filled_amounts(trades), average)
        if methodology.win_rate_definition == "closed_position":
            if closed_returns is None:
                account.pop("win_rate", None)
                if _WIN_RATE_MISSING_WARNING not in warnings:
                    warnings.append(_WIN_RATE_MISSING_WARNING)
            else:
                account["win_rate"] = metrics.win_rate_closed_position(closed_returns)
        else:
            account["win_rate"] = metrics.win_rate_daily(returns)
        return replace(result, account_metrics=account, methodology=methodology, warnings=warnings)
