# engine - 编排层

多日回测编排 + 账户状态机。依赖 `contracts` / `policies` / `evaluation`。

## 关键约束

### 主路径（`account_runner.py`）

- **`run_account_backtest_from_orders`** 为当前唯一主路径；`run_account_backtest` 和 `evaluate_signal_layer` 标注 deprecated，不新增消费者。
- `signal_time` 默认调仓日 15:00 Asia/Shanghai — TZ aware，勿用 naive datetime。
- 同批订单固定**先卖后买**（卖得现金供当批买单使用）。
- `OrderIntent` 买单互斥字段检查（`shares` / `cash_amount` 恰选其一），引擎裁决整手折算。
- 现金不足 / 零手 / 不可交易 → 整单 `rejected`（带 `ReasonCode`）。容量不足 → `partial + capacity_exceeded`。
- 真实 T+1 锁定：买入成交即冻结，下一交易日开盘前解冻（`lock_shares` / `unlock_shares`）。尾日锁定仓保留为 `locked` 事件。

### 账户状态机（`account.py`）

- 纯函数：返回新 `AccountState`，原状态不可变。
- 股数必须整数（`fractional=True` 在 paper 层，不在 account 层）。
- 缺 mark 回退 `last_marks`；两者皆缺显式抛错（禁止按 0 或成本静默估值）。
- 卖出费用走现金流水；`realized_pnl = (price - avg_cost) * shares - sell_fee`。

### Paper 层（`paper.py`）

- 等权浮点权重，明确**不等价于账户收益**，`EvaluationResult` 强制写入 warning。
- `trades` 列表为空属预期行为（paper 不产出 `TradeEvent`）。

### Signal 层（`signal.py`）

- 纯离线指标（rank IC / 五分位等），不涉及费用和执行。labels 由调用方按信号日对齐。

## 不变量

- 确定性：名次平局按 `instrument_id` 升序稳定排序；事件顺序先卖后买；清算按代码排序。
- 日期扫描依赖 `pairwise(trading_dates)` — 确保日期已排序、无空洞。
- `MarketState.get_bars` 只返回 `trading_date <= end_date`（防前视）。
