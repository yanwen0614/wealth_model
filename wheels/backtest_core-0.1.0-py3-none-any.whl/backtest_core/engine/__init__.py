"""engine 公共 API：多日编排层（signal 层评估 + paper 层纸面组合 + account 状态机）。

依赖方向：engine → contracts/policies/evaluation（单向）；本包不得 import 三仓库代码。
"""

from .account import (
    BuyResult,
    SellResult,
    apply_buy,
    apply_sell,
    lock_shares,
    mark_to_market,
    max_affordable_shares,
    unlock_shares,
)
from .account_runner import run_account_backtest, run_account_backtest_from_orders
from .market_state import MarketState
from .paper import PAPER_LAYER_WARNING, TRADES_LOCATION, PaperSimulation, PaperTrade, run_paper_backtest, simulate_paper
from .signal import evaluate_signal_layer

__all__ = [
    "PAPER_LAYER_WARNING",
    "TRADES_LOCATION",
    "BuyResult",
    "MarketState",
    "PaperSimulation",
    "PaperTrade",
    "SellResult",
    "apply_buy",
    "apply_sell",
    "evaluate_signal_layer",
    "lock_shares",
    "mark_to_market",
    "max_affordable_shares",
    "run_account_backtest",
    "run_account_backtest_from_orders",
    "run_paper_backtest",
    "simulate_paper",
    "unlock_shares",
]
