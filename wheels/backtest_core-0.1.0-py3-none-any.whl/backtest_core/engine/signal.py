"""signal 层评估编排（规格 §12 evaluate signal）：消费 Prediction 与预计算标签，不重算标签。

职责边界：
- 只做逐日编排与跳过/告警计数，指标公式全部在 evaluation.signal（纯函数，可离线复算）；
- labels_by_date 必须已按信号日对齐（T → label_exit 前向收益），本层不推断标签窗口；
- direction 是评估口径：与 Prediction.ranking_direction 冲突即显式失败，静默取反会掩盖模型方向配置错误。
"""

import math
from collections.abc import Mapping, Sequence
from datetime import date

from ..contracts.enums import PredictionType
from ..contracts.prediction import Prediction
from ..evaluation import signal as signal_math

__all__ = ["evaluate_signal_layer"]

# 可评估为排序信号的预测类型：目标权重/模型 action 不是收益预测（规格 §11.1），拒绝入 IC
_EVALUABLE_PREDICTION_TYPES = frozenset({PredictionType.PREDICTED_RETURN, PredictionType.RANKING_SCORE})
_VALID_DIRECTIONS = ("ascending", "descending")
_QUINTILE_COUNT = 5


def _resolve_direction(direction: str) -> str:
    if direction in _VALID_DIRECTIONS:
        return str(direction)
    raise ValueError(f"direction must be one of {_VALID_DIRECTIONS}, got {direction!r}")


def _resolve_positive_int(value: int, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive int, got {value!r}")
    return value


def _signal_values(predictions: Sequence[Prediction], direction: str, trading_date: date) -> dict[str, float]:
    """Prediction 序列 → {instrument_id: value}：类型/方向冲突/重复标的都在此显式失败。"""
    values: dict[str, float] = {}
    for prediction in predictions:
        if not isinstance(prediction, Prediction):
            raise ValueError(f"predictions items must be Prediction, got {prediction!r}")  # noqa: TRY004
        if prediction.prediction_type not in _EVALUABLE_PREDICTION_TYPES:
            raise ValueError(
                f"{trading_date!r}: prediction_type {prediction.prediction_type!r} is not a ranking signal"
            )
        if prediction.ranking_direction != direction:
            raise ValueError(
                f"{trading_date!r}: ranking_direction {prediction.ranking_direction!r} conflicts with "
                f"evaluation direction {direction!r}"
            )
        if prediction.instrument_id in values:
            raise ValueError(f"{trading_date!r}: duplicate prediction for {prediction.instrument_id!r}")
        values[prediction.instrument_id] = prediction.value
    return values


def _finite_labels(labels: Mapping[str, float]) -> tuple[dict[str, float], int]:
    """过滤非有限标签（适配器缺数据）：返回 (有限标签, 丢弃数)，由调用方计数与告警。"""
    checked: dict[str, float] = {}
    dropped = 0
    for instrument_id, value in labels.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            dropped += 1
            continue
        checked[instrument_id] = float(value)
    return checked, dropped


def _mean_or_zero(values: Sequence[float]) -> float:
    """空样本记 0.0 占位（与 evaluation.metrics 边界口径一致），不虚构收益。"""
    return sum(values) / len(values) if values else 0.0


def evaluate_signal_layer(
    *,
    dates: Sequence[date],
    predictions_by_date: Mapping[date, Sequence[Prediction]],
    labels_by_date: Mapping[date, Mapping[str, float]],
    top_n: int = 10,
    min_cross_section: int = 10,
    direction: str = "descending",
) -> tuple[dict[str, float], tuple[str, ...]]:
    """逐日评估 signal 层：返回 (signal_metrics, warnings)，纯确定性、重复调用一致。

    .. deprecated:: 阶段 2（K04）
        label 口径的离线 signal 层入口仅为 phase-1 兼容保留，不新增消费者；新代码请使用
        :func:`backtest_core.evaluation.evaluate_cross_section`（收益由引擎从市场自算，T+1 open
        入 / 第 holding_days 个有效 bar open 出）与 :func:`backtest_core.evaluation.evaluate_account`
        （账户整段指标）。本函数行为不变，也不发 runtime warning。

    metrics 键（固定命名空间）：ic_mean/ic_std/icir/ic_tstat/ic_count、
    topn_mean_return/topn_count、quintile_spread/quintile_monotonic/
    quintile_monotonic_ratio/quintile_count，以及跳过计数
    date_missing_skipped/label_nan_skipped/cross_section_skipped/degenerate_skipped/
    topn_skipped/quintile_skipped；无有效样本时指标记 0.0 占位（不虚构值）。
    """
    resolved_direction = _resolve_direction(direction)
    resolved_top_n = _resolve_positive_int(top_n, "top_n")
    resolved_min_cross_section = _resolve_positive_int(min_cross_section, "min_cross_section")
    ics: list[float] = []
    topn_values: list[float] = []
    quintile_spreads: list[float] = []
    monotonic_flags: list[bool] = []
    date_missing = 0
    label_nan = 0
    cross_section_skipped = 0
    degenerate_skipped = 0
    topn_skipped = 0
    quintile_skipped = 0

    for trading_date in dates:
        predictions = predictions_by_date.get(trading_date)
        raw_labels = labels_by_date.get(trading_date)
        if predictions is None or raw_labels is None:
            date_missing += 1
            continue
        if not isinstance(raw_labels, Mapping):
            raise ValueError(f"labels_by_date[{trading_date!r}] must be a mapping, got {raw_labels!r}")  # noqa: TRY004
        signal_values = _signal_values(predictions, resolved_direction, trading_date)
        label_values, dropped = _finite_labels(raw_labels)
        label_nan += dropped

        ic = signal_math.rank_ic(
            signal_values, label_values, min_cross_section=resolved_min_cross_section, direction=resolved_direction
        )
        if ic is None:
            if len(signal_values.keys() & label_values.keys()) < resolved_min_cross_section:
                cross_section_skipped += 1
            else:
                degenerate_skipped += 1
        else:
            ics.append(ic)

        topn = signal_math.topn_return(signal_values, label_values, top_n=resolved_top_n, direction=resolved_direction)
        if topn is None:
            topn_skipped += 1
        else:
            topn_values.append(topn)

        quintile = signal_math.quintile_returns(signal_values, label_values, direction=resolved_direction)
        if quintile is None:
            quintile_skipped += 1
        else:
            layers, monotonic = quintile
            quintile_spreads.append(layers[0] - layers[-1])
            monotonic_flags.append(monotonic)

    metrics: dict[str, float] = dict(signal_math.ic_summary(ics))
    metrics["topn_mean_return"] = _mean_or_zero(topn_values)
    metrics["topn_count"] = float(len(topn_values))
    metrics["quintile_spread"] = _mean_or_zero(quintile_spreads)
    metrics["quintile_monotonic"] = 1.0 if monotonic_flags and all(monotonic_flags) else 0.0
    metrics["quintile_monotonic_ratio"] = _mean_or_zero([1.0 if flag else 0.0 for flag in monotonic_flags])
    metrics["quintile_count"] = float(len(quintile_spreads))
    metrics["date_missing_skipped"] = float(date_missing)
    metrics["label_nan_skipped"] = float(label_nan)
    metrics["cross_section_skipped"] = float(cross_section_skipped)
    metrics["degenerate_skipped"] = float(degenerate_skipped)
    metrics["topn_skipped"] = float(topn_skipped)
    metrics["quintile_skipped"] = float(quintile_skipped)

    warnings: list[str] = []
    if date_missing:
        warnings.append(f"signal layer: {date_missing} date(s) skipped: predictions or labels missing")
    if label_nan:
        warnings.append(f"signal layer: {label_nan} label value(s) dropped: non-finite")
    if cross_section_skipped:
        warnings.append(
            f"signal layer: {cross_section_skipped} date(s) skipped: cross-section < {resolved_min_cross_section}"
        )
    if degenerate_skipped:
        warnings.append(
            f"signal layer: {degenerate_skipped} date(s) skipped: degenerate ranking (constant signal or label)"
        )
    if topn_skipped:
        warnings.append(f"signal layer: {topn_skipped} date(s) skipped: topn sample < {resolved_top_n}")
    if quintile_skipped:
        warnings.append(f"signal layer: {quintile_skipped} date(s) skipped: quintile sample < {_QUINTILE_COUNT}")
    return metrics, tuple(warnings)
