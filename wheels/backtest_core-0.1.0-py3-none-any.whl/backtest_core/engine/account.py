"""account 层账户状态机（规格 §11.3）：纯操作 + 不可变快照，整数股与显式拒绝语义。

层语义与边界：
- 所有函数是纯函数：返回新 AccountState 与决策结果，原状态冻结不变；
- account 层股数必须为整数（fractional=True 属 paper 研究模式，本层显式拒绝）；
- 买入按 lot_size 向下取整，取整为 0 → zero_lot；现金不足（含费用）→ insufficient_cash，
  禁止静默部分成交；
- 卖出只动用 positions - locked 的可卖量：请求量 > 总持仓 → oversell，请求量 > 可卖量
  → locked_position；整手向下取整，allow_odd_lot_close 时允许一次性清空可卖零股；
- cost 为移动加权成交价（不含费用，费用只走现金流）：realized_pnl=(price-avg_cost)*shares
  -卖出费用，与 closed_position 胜率口径一致；
- cash/available_cash 差集机制：买入从 available_cash 扣款（冻结现金不可动用），卖出净额
  同时计入两者（A 股卖出资金当日可再买入）；T+1 可卖规则由 T12 用 locked/available 驱动；
- mark_to_market 缺 mark 回退 last_marks，两者皆缺显式抛错（禁止按 0/成本静默估值）。
"""

from collections.abc import Mapping
from dataclasses import dataclass

from ..contracts.account import AccountState
from ..contracts.enums import ReasonCode, Side
from ..contracts.protocols import CostModel
from ..contracts.validation import ensure_finite, ensure_non_empty_str

__all__ = [
    "BuyResult",
    "SellResult",
    "apply_buy",
    "apply_sell",
    "lock_shares",
    "mark_to_market",
    "max_affordable_shares",
    "unlock_shares",
]

_DEFAULT_LOT_SIZE = 100


def _ensure_positive_int(value: int, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive int, got {value!r}")
    return value


def _ensure_non_negative_int(value: int, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{field_name} must be a non-negative int, got {value!r}")
    return value


def _ensure_positive_price(value: float, field_name: str) -> float:
    ensure_finite(value, field_name)
    if value <= 0.0:
        raise ValueError(f"{field_name} must be positive, got {value!r}")
    return float(value)


def _ensure_account_state(state: AccountState) -> None:
    """account 层拒绝 paper 浮点状态：整数股/整手不变量在本层统一兜底。"""
    if not isinstance(state, AccountState):
        raise ValueError(f"state must be an AccountState, got {state!r}")  # noqa: TRY004
    if state.fractional:
        raise ValueError("account layer operations require fractional=False state (paper mode is not accepted)")


def _quantity(mapping: Mapping[str, float], instrument_id: str) -> float:
    return float(mapping.get(instrument_id, 0.0))


def _cost_basis(state: AccountState, instrument_id: str) -> float:
    """持仓必须有成本基准：缺失即状态不一致，静默按 0 会算出虚假盈亏。"""
    basis = state.cost.get(instrument_id)
    if basis is None:
        raise ValueError(f"instrument {instrument_id!r} has a position but no cost basis")
    return float(basis)


def _replace_state(
    state: AccountState,
    *,
    positions: Mapping[str, float] | None = None,
    locked: Mapping[str, float] | None = None,
) -> AccountState:
    """仅替换持仓类映射：现金/成本/估值原样保留，AccountState 构造期统一校验不变量。"""
    return AccountState(
        cash=state.cash,
        available_cash=state.available_cash,
        positions=state.positions if positions is None else positions,
        locked=state.locked if locked is None else locked,
        cost=state.cost,
        last_marks=state.last_marks,
        fractional=state.fractional,
    )


@dataclass(frozen=True)
class BuyResult:
    """买入决策结果：filled=False 时 shares/amount/三费均为 0，reason 必填且 state 原样返回。"""

    state: AccountState
    instrument_id: str
    requested_shares: int
    shares: int
    price: float
    amount: float
    commission: float
    stamp_tax: float
    transfer_fee: float
    filled: bool
    reason: ReasonCode | None

    def __post_init__(self) -> None:
        if self.filled:
            if self.reason is not None or self.shares <= 0:
                raise ValueError("filled buy requires shares > 0 and reason=None")
        elif self.reason is None or self.shares != 0 or self.amount != 0.0 or self.total_fee != 0.0:
            raise ValueError("rejected buy requires a reason and zero shares/amount/fees")

    @property
    def total_fee(self) -> float:
        """三项费用合计：与 TradeEvent 费用字段同构，便于 T12 直接落事件。"""
        return self.commission + self.stamp_tax + self.transfer_fee


@dataclass(frozen=True)
class SellResult:
    """卖出决策结果：realized_pnl 已扣卖出费用；拒绝时成交/费用/盈亏均为 0。"""

    state: AccountState
    instrument_id: str
    requested_shares: int
    shares: int
    price: float
    amount: float
    commission: float
    stamp_tax: float
    transfer_fee: float
    avg_cost: float
    realized_pnl: float
    filled: bool
    reason: ReasonCode | None

    def __post_init__(self) -> None:
        if self.filled:
            if self.reason is not None or self.shares <= 0:
                raise ValueError("filled sell requires shares > 0 and reason=None")
        elif (
            self.reason is None
            or self.shares != 0
            or self.amount != 0.0
            or self.total_fee != 0.0
            or self.realized_pnl != 0.0
        ):
            raise ValueError("rejected sell requires a reason and zero shares/amount/fees/realized_pnl")

    @property
    def total_fee(self) -> float:
        """三项费用合计：与 TradeEvent 费用字段同构，便于 T12 直接落事件。"""
        return self.commission + self.stamp_tax + self.transfer_fee


def _rejected_buy(state: AccountState, instrument_id: str, requested: int, price: float, reason: ReasonCode) -> BuyResult:
    return BuyResult(
        state=state,
        instrument_id=instrument_id,
        requested_shares=requested,
        shares=0,
        price=price,
        amount=0.0,
        commission=0.0,
        stamp_tax=0.0,
        transfer_fee=0.0,
        filled=False,
        reason=reason,
    )


def _rejected_sell(
    state: AccountState,
    instrument_id: str,
    requested: int,
    price: float,
    avg_cost: float,
    reason: ReasonCode,
) -> SellResult:
    return SellResult(
        state=state,
        instrument_id=instrument_id,
        requested_shares=requested,
        shares=0,
        price=price,
        amount=0.0,
        commission=0.0,
        stamp_tax=0.0,
        transfer_fee=0.0,
        avg_cost=avg_cost,
        realized_pnl=0.0,
        filled=False,
        reason=reason,
    )


def apply_buy(
    state: AccountState,
    instrument_id: str,
    shares: int,
    price: float,
    cost_model: CostModel,
    *,
    lot_size: int = _DEFAULT_LOT_SIZE,
) -> BuyResult:
    """买入成交：整手向下 + 费用计入现金校验；拒绝路径不产生任何状态变更。"""
    _ensure_account_state(state)
    ensure_non_empty_str(instrument_id, "instrument_id")
    _ensure_non_negative_int(shares, "shares")
    checked_price = _ensure_positive_price(price, "price")
    resolved_lot = _ensure_positive_int(lot_size, "lot_size")
    rounded = shares // resolved_lot * resolved_lot
    if rounded == 0:
        return _rejected_buy(state, instrument_id, shares, checked_price, ReasonCode.ZERO_LOT)
    amount = rounded * checked_price
    commission, stamp_tax, transfer_fee = cost_model.calculate(Side.BUY, amount)
    total = amount + commission + stamp_tax + transfer_fee
    if total > state.available_cash:
        return _rejected_buy(state, instrument_id, shares, checked_price, ReasonCode.INSUFFICIENT_CASH)
    held = _quantity(state.positions, instrument_id)
    previous_cost = state.cost.get(instrument_id)
    if held > 0 and previous_cost is None:
        raise ValueError(f"instrument {instrument_id!r} has a position but no cost basis")
    new_avg_cost = (held * (previous_cost or 0.0) + amount) / (held + rounded)
    positions = dict(state.positions)
    positions[instrument_id] = held + rounded
    cost = dict(state.cost)
    cost[instrument_id] = new_avg_cost
    new_state = AccountState(
        cash=state.cash - total,
        available_cash=state.available_cash - total,
        positions=positions,
        locked=dict(state.locked),
        cost=cost,
        last_marks=dict(state.last_marks),
        fractional=state.fractional,
    )
    return BuyResult(
        state=new_state,
        instrument_id=instrument_id,
        requested_shares=shares,
        shares=rounded,
        price=checked_price,
        amount=amount,
        commission=commission,
        stamp_tax=stamp_tax,
        transfer_fee=transfer_fee,
        filled=True,
        reason=None,
    )


def max_affordable_shares(
    state: AccountState,
    price: float,
    cost_model: CostModel,
    *,
    lot_size: int = _DEFAULT_LOT_SIZE,
) -> int:
    """可负担的最大整手数（费用含最低佣金）：预算分配 helper，与 apply_buy 拒绝边界一致。

    费用对股数单调不减，故从「不含费用上界」逐手回退即可得到精确解；正常费率下回退步数在
    佣金相对每手金额的量级（通常 0–2 步），不会退化为线性搜索。
    """
    _ensure_account_state(state)
    checked_price = _ensure_positive_price(price, "price")
    resolved_lot = _ensure_positive_int(lot_size, "lot_size")
    budget = state.available_cash
    if budget <= 0.0:
        return 0
    best = int(budget // checked_price) // resolved_lot * resolved_lot
    while best > 0:
        amount = best * checked_price
        commission, stamp_tax, transfer_fee = cost_model.calculate(Side.BUY, amount)
        if amount + commission + stamp_tax + transfer_fee <= budget:
            return best
        best -= resolved_lot
    return 0


def _avg_cost_or_zero(state: AccountState, instrument_id: str) -> float:
    """拒绝路径的信息性成本：成本未知时记 0，不因缺基准改变拒绝语义。"""
    basis = state.cost.get(instrument_id)
    return 0.0 if basis is None else float(basis)


def apply_sell(
    state: AccountState,
    instrument_id: str,
    shares: int,
    price: float,
    cost_model: CostModel,
    *,
    lot_size: int = _DEFAULT_LOT_SIZE,
    allow_odd_lot_close: bool = True,
) -> SellResult:
    """卖出成交：锁定仓不参与可卖量，整手向下但一次性清仓可卖零股例外。"""
    _ensure_account_state(state)
    ensure_non_empty_str(instrument_id, "instrument_id")
    _ensure_non_negative_int(shares, "shares")
    checked_price = _ensure_positive_price(price, "price")
    resolved_lot = _ensure_positive_int(lot_size, "lot_size")
    if not isinstance(allow_odd_lot_close, bool):
        raise ValueError(f"allow_odd_lot_close must be a bool, got {allow_odd_lot_close!r}")  # noqa: TRY004
    held = _quantity(state.positions, instrument_id)
    locked = _quantity(state.locked, instrument_id)
    sellable = held - locked
    # 区分超卖与锁定：超过总持仓=oversell；只超过可卖量=locked_position
    if shares > held:
        return _rejected_sell(
            state, instrument_id, shares, checked_price, _avg_cost_or_zero(state, instrument_id), ReasonCode.OVERSELL
        )
    if shares > sellable:
        return _rejected_sell(
            state, instrument_id, shares, checked_price, _avg_cost_or_zero(state, instrument_id),
            ReasonCode.LOCKED_POSITION,
        )
    filled = shares if (allow_odd_lot_close and shares == sellable) else shares // resolved_lot * resolved_lot
    if filled == 0:
        return _rejected_sell(
            state, instrument_id, shares, checked_price, _avg_cost_or_zero(state, instrument_id), ReasonCode.ZERO_LOT
        )
    avg_cost = _cost_basis(state, instrument_id)
    amount = filled * checked_price
    commission, stamp_tax, transfer_fee = cost_model.calculate(Side.SELL, amount)
    total_fee = commission + stamp_tax + transfer_fee
    net = amount - total_fee
    realized_pnl = (checked_price - avg_cost) * filled - total_fee
    positions = dict(state.positions)
    cost = dict(state.cost)
    locked_map = dict(state.locked)
    remaining = held - filled
    if remaining > 0:
        positions[instrument_id] = remaining
    else:
        positions.pop(instrument_id, None)
        cost.pop(instrument_id, None)
        # 清仓意味着可卖量全部卖出：locked 必为 0，键位一并清理避免幽灵零仓
        locked_map.pop(instrument_id, None)
    new_state = AccountState(
        cash=state.cash + net,
        available_cash=state.available_cash + net,
        positions=positions,
        locked=locked_map,
        cost=cost,
        last_marks=dict(state.last_marks),
        fractional=state.fractional,
    )
    return SellResult(
        state=new_state,
        instrument_id=instrument_id,
        requested_shares=shares,
        shares=filled,
        price=checked_price,
        amount=amount,
        commission=commission,
        stamp_tax=stamp_tax,
        transfer_fee=transfer_fee,
        avg_cost=avg_cost,
        realized_pnl=realized_pnl,
        filled=True,
        reason=None,
    )


def mark_to_market(state: AccountState, marks: Mapping[str, float]) -> float:
    """NAV = cash + Σ 持仓数量 × mark；locked 是 positions 子集，不重复计入。

    缺 mark 回退 last_marks；两者皆缺抛 ValueError（静默按 0 估值会让 NAV 失真）。
    按 instrument_id 排序遍历保证浮点加法顺序确定。
    """
    _ensure_account_state(state)
    if not isinstance(marks, Mapping):
        raise ValueError(f"marks must be a mapping, got {marks!r}")  # noqa: TRY004
    value = state.cash
    for instrument_id in sorted(state.positions):
        quantity = _quantity(state.positions, instrument_id)
        if quantity <= 0:
            continue
        mark = marks.get(instrument_id)
        if mark is None:
            mark = state.last_marks.get(instrument_id)
        if mark is None:
            raise ValueError(
                f"no mark available for {instrument_id!r}: pass marks or ensure state.last_marks contains it"
            )
        value += quantity * _ensure_positive_price(mark, f"marks[{instrument_id!r}]")
    return float(value)


def lock_shares(state: AccountState, instrument_id: str, shares: int) -> AccountState:
    """冻结持仓（T+1 不可卖）：累计冻结量不得超过总持仓；0 股为无操作。"""
    _ensure_account_state(state)
    ensure_non_empty_str(instrument_id, "instrument_id")
    _ensure_non_negative_int(shares, "shares")
    if shares == 0:
        return state
    held = _quantity(state.positions, instrument_id)
    locked = _quantity(state.locked, instrument_id)
    if locked + shares > held:
        raise ValueError(
            f"cannot lock {shares} shares of {instrument_id!r}: locked {locked} + {shares} > held {held}"
        )
    locked_map = dict(state.locked)
    locked_map[instrument_id] = locked + shares
    return _replace_state(state, locked=locked_map)


def unlock_shares(state: AccountState, instrument_id: str, shares: int) -> AccountState:
    """解冻持仓：解锁量不得超过当前冻结量；0 股为无操作。"""
    _ensure_account_state(state)
    ensure_non_empty_str(instrument_id, "instrument_id")
    _ensure_non_negative_int(shares, "shares")
    if shares == 0:
        return state
    locked = _quantity(state.locked, instrument_id)
    if shares > locked:
        raise ValueError(f"cannot unlock {shares} shares of {instrument_id!r}: locked {locked} < requested {shares}")
    locked_map = dict(state.locked)
    remaining = locked - shares
    if remaining > 0:
        locked_map[instrument_id] = remaining
    else:
        locked_map.pop(instrument_id, None)
    return _replace_state(state, locked=locked_map)
