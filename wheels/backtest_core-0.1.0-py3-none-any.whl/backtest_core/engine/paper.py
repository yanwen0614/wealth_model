"""paper 层纸面组合引擎（规格核心理念 2、§11.3）：研究级等权 topN，明确不等价于账户收益。

层语义（与 account 层严格区分）：
- T 日收盘信号，默认 T+1 open 成交（复用 T06 的 resolve_execution_date/execution_price，
  严禁回退信号日价格；尾日无下一交易日显式跳过）；
- 目标权重 = 1/N 浮点等权：无整手、无现金、无涨跌停约束（paper 层刻意放宽可交易性，
  缺价必须显式跳过）；
- 费用按 AShareCostModel 计费并直接从现金扣除，NAV 逐日按收盘价 mark；
- 所有缺价/缺 mark/前视违规逐条显式跳过或降级并记录 warning，禁止静默丢弃；
- EvaluationResult 强制 layer=paper 与"不等价账户收益"warning，防止纸面业绩被误读。
"""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime, time
from itertools import pairwise

from .. import __version__
from ..contracts.config import CostConfig
from ..contracts.enums import ExecutionMode, RankingDirection, Side
from ..contracts.prediction import Prediction
from ..contracts.protocols import MarketDataProvider
from ..contracts.result import SCHEMA_VERSION, EvaluationResult, MetricMethodology
from ..contracts.validation import (
    ensure_calendar_date,
    ensure_enum_member,
    ensure_finite,
    ensure_non_empty_str,
    ensure_non_negative_finite,
)
from ..evaluation import metrics as metric_math
from ..evaluation.methodology import periods_per_year
from ..policies.cost import AShareCostModel
from ..policies.execution import (
    NoNextTradingDayError,
    execution_price,
    resolve_execution_date,
    validate_no_lookahead,
)

__all__ = [
    "PAPER_LAYER_WARNING",
    "TRADES_LOCATION",
    "PaperSimulation",
    "PaperTrade",
    "run_paper_backtest",
    "simulate_paper",
]

PAPER_LAYER_WARNING = (
    "paper layer is not equivalent to account returns: no lot-size, cash or price-limit constraints "
    "are modeled; use the account layer for achievable performance (spec core principle 2). "
    "Fills are recorded in PaperSimulation.trades (float shares); EvaluationResult.trades is account-layer only"
)
PAPER_POLICY_VERSION = "v1"
# provenance[trades_location] 的固定取值：T13 落盘据此判定 paper 成交不在 result.trades
TRADES_LOCATION = "paper_simulation"

_MISSING_PREDICTIONS = "rebalance_dates_without_predictions"
_NO_NEXT_TRADING_DAY = "rebalance_dates_without_next_trading_day"
_MISSING_EXECUTION_PRICE = "orders_without_execution_price"
_MARK_CARRIED_FORWARD = "close_marks_carried_forward"
_LOOKAHEAD_REJECTED = "predictions_skipped_for_lookahead"
_SKIPPED_COUNT_KEYS = (
    _MISSING_PREDICTIONS,
    _NO_NEXT_TRADING_DAY,
    _MISSING_EXECUTION_PRICE,
    _MARK_CARRIED_FORWARD,
    _LOOKAHEAD_REJECTED,
)
# 执行时点的日历时钟：validate_no_lookahead 需要真实时间轴，日期序不可替代时间先后
_EXECUTION_CLOCK = {
    ExecutionMode.T1_OPEN: time(9, 30),
    ExecutionMode.SAME_DAY_CLOSE: time(15, 0),
    ExecutionMode.MID: time(11, 30),
}
_WIN_RATE_CLOSED_POSITION_WARNING = (
    "paper metrics: win_rate omitted: win_rate_definition=closed_position requires closed-position returns"
)


@dataclass(frozen=True)
class PaperTrade:
    """paper 层浮点股数成交：shares 为 float，故不能装入要求整数股数的 TradeEvent（§11.3 研究模式）。"""

    signal_date: date
    execution_date: date
    instrument_id: str
    side: Side
    shares: float
    price: float
    amount: float
    commission: float
    stamp_tax: float
    transfer_fee: float

    def __post_init__(self) -> None:
        ensure_calendar_date(self.signal_date, "signal_date")
        ensure_calendar_date(self.execution_date, "execution_date")
        if self.execution_date < self.signal_date:
            raise ValueError(
                f"execution_date {self.execution_date!r} must not precede signal_date {self.signal_date!r}"
            )
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        object.__setattr__(self, "side", ensure_enum_member(self.side, Side, "side"))
        for field_name in ("shares", "price"):
            value = getattr(self, field_name)
            ensure_finite(value, field_name)
            if value <= 0.0:
                raise ValueError(f"{field_name} must be positive, got {value!r}")
        for field_name in ("amount", "commission", "stamp_tax", "transfer_fee"):
            ensure_non_negative_finite(getattr(self, field_name), field_name)

    @property
    def total_fee(self) -> float:
        """三项费用合计：NAV 扣减口径与 TradeEvent 保持同构。"""
        return self.commission + self.stamp_tax + self.transfer_fee


@dataclass(frozen=True)
class PaperSimulation:
    """paper 层完整轨迹：NAV 序列 + 执行时目标权重 + 浮点成交 + 显式跳过计数。

    target_weights_by_date 键=信号日 signal_date，值=该次调仓按执行时价格确定的目标权重
    （缺执行价标的剔除后仍按 1/N 名义权重计）；成交明细（浮点股数）只存在于 trades，
    EvaluationResult.trades 为账户层专用，不承载 paper 成交。
    """

    nav: tuple[float, ...]
    nav_dates: tuple[date, ...]
    target_weights_by_date: Mapping[date, Mapping[str, float]]
    trades: tuple[PaperTrade, ...]
    warnings: tuple[str, ...]
    skipped_counts: Mapping[str, int]

    def __post_init__(self) -> None:
        if len(self.nav) != len(self.nav_dates):
            raise ValueError(f"nav has {len(self.nav)} values but nav_dates has {len(self.nav_dates)}")
        for trading_date, value in zip(self.nav_dates, self.nav):
            ensure_calendar_date(trading_date, "nav_dates item")
            ensure_finite(value, "nav item")
            if value <= 0.0:
                raise ValueError(f"nav items must be positive, got {value!r}")
        for trade in self.trades:
            if not isinstance(trade, PaperTrade):
                raise ValueError(f"trades items must be PaperTrade, got {trade!r}")  # noqa: TRY004
        for key, count in self.skipped_counts.items():
            ensure_non_empty_str(key, "skipped_counts key")
            if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                raise ValueError(f"skipped_counts[{key!r}] must be a non-negative int, got {count!r}")


@dataclass(frozen=True)
class _PendingRebalance:
    """调度结果：信号日选定 topN，等待 execution_date 用届时价格执行。"""

    signal_date: date
    execution_date: date
    selected: tuple[str, ...]
    signal_time: datetime


class _Portfolio:
    """多日模拟状态：cash 允许为负（无现金约束），shares/last_marks 仅存浮点快照。"""

    __slots__ = ("cash", "last_marks", "shares")

    def __init__(self, cash: float) -> None:
        self.cash = cash
        self.shares: dict[str, float] = {}
        self.last_marks: dict[str, float] = {}


def _ensure_positive_int(value: int, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"{field_name} must be a positive int, got {value!r}")
    return value


def _ensure_positive_finite(value: float, field_name: str) -> float:
    ensure_finite(value, field_name)
    if value <= 0.0:
        raise ValueError(f"{field_name} must be positive, got {value!r}")
    return float(value)


def _ensure_dates(dates: Sequence[date]) -> tuple[date, ...]:
    """严格升序的交易日序列：resolve_execution_date 与 NAV 序列都依赖该次序。"""
    if isinstance(dates, (str, bytes)) or not isinstance(dates, Sequence):
        raise ValueError(f"dates must be a sequence of date, got {dates!r}")  # noqa: TRY004
    ordered = tuple(dates)
    for trading_date in ordered:
        ensure_calendar_date(trading_date, "dates item")
    for previous, current in pairwise(ordered):
        if current <= previous:
            raise ValueError("dates must be strictly ascending")
    return ordered


def _rank_selection(
    predictions: Sequence[Prediction],
    top_n: int,
    trading_date: date,
) -> tuple[tuple[str, ...], datetime]:
    """排序取 topN：重复标的/方向不一致显式失败；同值按 instrument_id 升序稳定打破平局。"""
    direction: RankingDirection | None = None
    checked: list[Prediction] = []
    seen: set[str] = set()
    for prediction in predictions:
        if not isinstance(prediction, Prediction):
            raise ValueError(f"predictions items must be Prediction, got {prediction!r}")  # noqa: TRY004
        if prediction.instrument_id in seen:
            raise ValueError(f"{trading_date!r}: duplicate prediction for {prediction.instrument_id!r}")
        if direction is None:
            direction = prediction.ranking_direction
        elif prediction.ranking_direction is not direction:
            raise ValueError(f"{trading_date!r}: ranking_direction must be consistent within a date")
        seen.add(prediction.instrument_id)
        checked.append(prediction)
    # descending 时取负值升序等价于按值降序，同时保留 instrument_id 升序平局规则
    sign = -1.0 if direction is RankingDirection.DESCENDING else 1.0
    ordered = sorted(checked, key=lambda prediction: (prediction.value * sign, prediction.instrument_id))
    selected = tuple(prediction.instrument_id for prediction in ordered[:top_n])
    return selected, min(prediction.signal_time for prediction in checked)


def _filter_lookahead_predictions(
    predictions: Sequence[Prediction],
    signal_date: date,
    execution_date: date,
    mode: ExecutionMode,
) -> tuple[list[Prediction], int]:
    """逐条前视校验：违规预测显式剔除并计数，禁止用 min(signal_time) 掩盖同日混合时点。

    同日模式额外要求 signal_time 落在 signal_date 当日：T06 validate_no_lookahead 只比较时点先后，
    无法识别跨日误分箱的旧信号。选择跳过+计数而非抛错：单条坏预测不应中断整段模拟，
    且计数与 warning 保证违规可见（禁止静默）。
    """
    valid: list[Prediction] = []
    rejected = 0
    for prediction in predictions:
        if not isinstance(prediction, Prediction):
            raise ValueError(f"predictions items must be Prediction, got {prediction!r}")  # noqa: TRY004
        if mode is not ExecutionMode.T1_OPEN and prediction.signal_time.date() != signal_date:
            rejected += 1
            continue
        try:
            validate_no_lookahead(
                prediction.signal_time,
                _execution_time(execution_date, prediction.signal_time, mode),
                mode,
            )
        except ValueError:
            # Prediction 已保证 tz-aware 且 mode 已归一为枚举：此处 ValueError 即前视违规
            rejected += 1
            continue
        valid.append(prediction)
    return valid, rejected


def _mode_price(market: MarketDataProvider, instrument_id: str, trading_date: date, mode: ExecutionMode) -> float | None:
    """按模式取执行价：bar 缺失或所需价格字段缺失返回 None，禁止跨字段/跨日回退（规格 §11.2）。"""
    bar = market.get_bar(instrument_id, trading_date)
    if bar is None:
        return None
    return execution_price(bar, mode)


def _apply_fill(
    portfolio: _Portfolio,
    trades: list[PaperTrade],
    pending: _PendingRebalance,
    instrument_id: str,
    side: Side,
    shares: float,
    price: float,
    cost_model: AShareCostModel,
) -> None:
    """单笔浮点成交：费用从现金扣除（允许现金转负=无现金约束），并登记事件。"""
    amount = shares * price
    commission, stamp_tax, transfer_fee = cost_model.calculate(side, amount)
    fee = commission + stamp_tax + transfer_fee
    if side is Side.BUY:
        portfolio.cash -= amount + fee
        portfolio.shares[instrument_id] = portfolio.shares.get(instrument_id, 0.0) + shares
    else:
        portfolio.cash += amount - fee
        remaining = portfolio.shares.get(instrument_id, 0.0) - shares
        if remaining <= 0.0:  # 浮点残差不得留下幽灵零仓
            portfolio.shares.pop(instrument_id, None)
        else:
            portfolio.shares[instrument_id] = remaining
    trades.append(
        PaperTrade(
            signal_date=pending.signal_date,
            execution_date=pending.execution_date,
            instrument_id=instrument_id,
            side=side,
            shares=shares,
            price=price,
            amount=amount,
            commission=commission,
            stamp_tax=stamp_tax,
            transfer_fee=transfer_fee,
        )
    )


def _mark_close(
    portfolio: _Portfolio,
    market: MarketDataProvider,
    trading_date: date,
    skipped_counts: dict[str, int],
) -> float:
    """逐日按收盘价 mark：close 缺失沿用最近 mark 并计数，禁止把持仓静默清零。"""
    value = 0.0
    for instrument_id in sorted(portfolio.shares):
        bar = market.get_bar(instrument_id, trading_date)
        close = bar.close if bar is not None else None
        if close is None or close <= 0.0:
            mark = portfolio.last_marks.get(instrument_id)
            if mark is None:
                raise ValueError(f"no mark available for {instrument_id!r} at {trading_date!r}")
            skipped_counts[_MARK_CARRIED_FORWARD] += 1
        else:
            mark = close
        portfolio.last_marks[instrument_id] = mark
        value += portfolio.shares[instrument_id] * mark
    return portfolio.cash + value


def _execute_rebalance(
    portfolio: _Portfolio,
    market: MarketDataProvider,
    pending: _PendingRebalance,
    mode: ExecutionMode,
    cost_model: AShareCostModel,
    trades: list[PaperTrade],
    skipped_counts: dict[str, int],
) -> dict[str, float]:
    """执行一次调仓：先卖后买、等权目标 1/N；返回按资产计的执行时目标权重（缺价标的剔除）。"""
    execution_date = pending.execution_date
    target_set = set(pending.selected)
    # 1) 旧持仓跌出 topN → 清仓；卖不掉的显式计数，禁止回退信号日价格
    for instrument_id in sorted(set(portfolio.shares) - target_set):
        price = _mode_price(market, instrument_id, execution_date, mode)
        if price is None:
            skipped_counts[_MISSING_EXECUTION_PRICE] += 1
            continue
        _apply_fill(
            portfolio, trades, pending, instrument_id, Side.SELL, portfolio.shares[instrument_id], price, cost_model
        )
    # 2) 以执行时价格计组合价值：等权目标 = NAV_at_exec / N，缺价标的不重分配权重
    nav_at_exec = portfolio.cash
    for instrument_id in sorted(portfolio.shares):
        price = _mode_price(market, instrument_id, execution_date, mode)
        if price is None:
            price = portfolio.last_marks[instrument_id]
        nav_at_exec += portfolio.shares[instrument_id] * price
    target_value = nav_at_exec / len(pending.selected)
    weight = 1.0 / len(pending.selected)
    weights: dict[str, float] = {}
    # 3) 按名次顺序调至目标股数（浮点精确赋值、不整手），rank 顺序保证成交序列确定
    for instrument_id in pending.selected:
        price = _mode_price(market, instrument_id, execution_date, mode)
        if price is None:
            skipped_counts[_MISSING_EXECUTION_PRICE] += 1
            continue
        target_shares = target_value / price
        delta = target_shares - portfolio.shares.get(instrument_id, 0.0)
        if delta > 0.0:
            _apply_fill(portfolio, trades, pending, instrument_id, Side.BUY, delta, price, cost_model)
        elif delta < 0.0:
            _apply_fill(portfolio, trades, pending, instrument_id, Side.SELL, -delta, price, cost_model)
        else:
            weights[instrument_id] = weight
            continue
        portfolio.shares[instrument_id] = target_shares
        weights[instrument_id] = weight
    return weights


def _execution_time(execution_date: date, signal_time: datetime, mode: ExecutionMode) -> datetime:
    """执行日 + 模式时钟：validate_no_lookahead 需真实时间先后，日期序不可替代。"""
    return datetime.combine(execution_date, _EXECUTION_CLOCK[mode], tzinfo=signal_time.tzinfo)


def _append_skip_warnings(warnings: list[str], counts: Mapping[str, int]) -> None:
    """跳过/降级必须有可见告警：计数固化为固定顺序文案，便于下游 grep 与审计。"""
    if counts[_MISSING_PREDICTIONS]:
        warnings.append(f"paper layer: {counts[_MISSING_PREDICTIONS]} rebalance date(s) skipped: predictions missing")
    if counts[_LOOKAHEAD_REJECTED]:
        warnings.append(
            f"paper layer: {counts[_LOOKAHEAD_REJECTED]} prediction(s) skipped: signal_time violates lookahead guard"
        )
    if counts[_NO_NEXT_TRADING_DAY]:
        warnings.append(
            f"paper layer: {counts[_NO_NEXT_TRADING_DAY]} rebalance date(s) skipped: no next trading day "
            "(no signal-day price fallback)"
        )
    if counts[_MISSING_EXECUTION_PRICE]:
        warnings.append(
            f"paper layer: {counts[_MISSING_EXECUTION_PRICE]} order(s) skipped: missing execution price"
        )
    if counts[_MARK_CARRIED_FORWARD]:
        warnings.append(
            f"paper layer: {counts[_MARK_CARRIED_FORWARD]} close mark(s) carried forward: close missing"
        )


def simulate_paper(
    *,
    dates: Sequence[date],
    predictions_by_date: Mapping[date, Sequence[Prediction]],
    market: MarketDataProvider,
    top_n: int = 20,
    rebalance_frequency: int = 1,
    initial_capital: float = 1_000_000.0,
    execution_mode: ExecutionMode | str = ExecutionMode.T1_OPEN,
    cost_config: CostConfig | None = None,
) -> PaperSimulation:
    """逐日推进 paper 组合并返回完整轨迹；同输入重复调用逐字段一致（稳定排序、无随机）。"""
    ordered = _ensure_dates(dates)
    resolved_top_n = _ensure_positive_int(top_n, "top_n")
    resolved_frequency = _ensure_positive_int(rebalance_frequency, "rebalance_frequency")
    resolved_capital = _ensure_positive_finite(initial_capital, "initial_capital")
    resolved_mode = ensure_enum_member(execution_mode, ExecutionMode, "execution_mode")
    if cost_config is not None and not isinstance(cost_config, CostConfig):
        raise ValueError(f"cost_config must be a CostConfig or None, got {cost_config!r}")
    if not isinstance(predictions_by_date, Mapping):
        raise ValueError(  # noqa: TRY004
            f"predictions_by_date must be a mapping, got {predictions_by_date!r}"
        )
    cost_model = AShareCostModel(cost_config)

    warnings: list[str] = [PAPER_LAYER_WARNING]
    skipped_counts: dict[str, int] = {key: 0 for key in _SKIPPED_COUNT_KEYS}
    pending: dict[date, list[_PendingRebalance]] = {}

    # 第一阶段：调度——信号日选 topN，把执行日解析为显式交易日；尾日显式跳过
    for index, signal_date in enumerate(ordered):
        if index % resolved_frequency != 0:
            continue
        raw_predictions = predictions_by_date.get(signal_date)
        if raw_predictions is None:
            skipped_counts[_MISSING_PREDICTIONS] += 1
            continue
        if isinstance(raw_predictions, (str, bytes)) or not isinstance(raw_predictions, Sequence):
            raise ValueError(  # noqa: TRY004
                f"predictions_by_date[{signal_date!r}] must be a sequence of Prediction, got {raw_predictions!r}"
            )
        if len(raw_predictions) == 0:
            skipped_counts[_MISSING_PREDICTIONS] += 1
            continue
        try:
            execution_date = resolve_execution_date(signal_date, resolved_mode, ordered)
        except NoNextTradingDayError:
            skipped_counts[_NO_NEXT_TRADING_DAY] += 1
            continue
        valid_predictions, rejected = _filter_lookahead_predictions(
            raw_predictions, signal_date, execution_date, resolved_mode
        )
        skipped_counts[_LOOKAHEAD_REJECTED] += rejected
        if not valid_predictions:
            # 全部预测因前视违规被剔除：本次调仓无可执行信号，已由计数与 warning 显式报告
            continue
        selected, signal_time = _rank_selection(valid_predictions, resolved_top_n, signal_date)
        pending.setdefault(execution_date, []).append(
            _PendingRebalance(signal_date, execution_date, selected, signal_time)
        )
    # 第二阶段：逐日先执行当日到期的调仓，再按收盘 mark；NAV 覆盖完整 dates 轴
    portfolio = _Portfolio(resolved_capital)
    nav: list[float] = []
    target_weights_by_date: dict[date, dict[str, float]] = {}
    trades: list[PaperTrade] = []
    for trading_date in ordered:
        for item in pending.get(trading_date, ()):
            target_weights_by_date[item.signal_date] = _execute_rebalance(
                portfolio, market, item, resolved_mode, cost_model, trades, skipped_counts
            )
        nav.append(_mark_close(portfolio, market, trading_date, skipped_counts))

    _append_skip_warnings(warnings, skipped_counts)
    return PaperSimulation(
        nav=tuple(nav),
        nav_dates=ordered,
        target_weights_by_date=target_weights_by_date,
        trades=tuple(trades),
        warnings=tuple(warnings),
        skipped_counts=skipped_counts,
    )


def _paper_metrics(
    simulation: PaperSimulation,
    methodology: MetricMethodology,
) -> tuple[dict[str, float], list[str]]:
    """按 methodology 计算 paper 指标：复用 evaluation.metrics 纯函数，turnover 用浮点成交额。"""
    nav = simulation.nav
    periods = periods_per_year(methodology)
    returns = metric_math.period_returns(nav)
    average_nav = sum(nav) / len(nav) if nav else 0.0
    metrics: dict[str, float] = {
        "total_return": metric_math.total_return(nav),
        "annualized_return": metric_math.annualized_return(nav, periods),
        "volatility": metric_math.volatility(returns, periods, methodology.sharpe_ddof),
        "sharpe": metric_math.sharpe_ratio(
            returns, methodology.risk_free_rate_annual, periods, methodology.sharpe_ddof
        ),
        "max_drawdown": metric_math.max_drawdown(nav),
        "turnover": metric_math.turnover_ratio([trade.amount for trade in simulation.trades], average_nav),
    }
    warnings: list[str] = []
    if methodology.win_rate_definition == "daily_return":
        metrics["win_rate"] = metric_math.win_rate_daily(returns)
    else:
        # 与 DefaultEvaluationEngine 同策略：缺平仓收益输入时省略，禁止日收益口径冒充
        warnings.append(_WIN_RATE_CLOSED_POSITION_WARNING)
    return metrics, warnings


def run_paper_backtest(
    *,
    dates: Sequence[date],
    predictions_by_date: Mapping[date, Sequence[Prediction]],
    market: MarketDataProvider,
    top_n: int = 20,
    rebalance_frequency: int = 1,
    initial_capital: float = 1_000_000.0,
    execution_mode: ExecutionMode | str = ExecutionMode.T1_OPEN,
    cost_config: CostConfig | None = None,
    methodology: MetricMethodology | None = None,
    run_id: str = "paper-run",
    model_id: str = "paper-model",
) -> EvaluationResult:
    """paper 层入口：模拟 + 指标落 paper 命名空间，provenance 强制 layer=paper + trades_location。

    成交明细（浮点股数）记录于 PaperSimulation.trades；EvaluationResult.trades 为账户层专用，
    provenance["trades_location"]="paper_simulation" 供 T13 落盘前判定空 trades 属预期。
    """
    resolved_methodology = methodology if methodology is not None else MetricMethodology()
    if not isinstance(resolved_methodology, MetricMethodology):
        raise ValueError(  # noqa: TRY004
            f"methodology must be a MetricMethodology or None, got {resolved_methodology!r}"
        )
    resolved_mode = ensure_enum_member(execution_mode, ExecutionMode, "execution_mode")
    simulation = simulate_paper(
        dates=dates,
        predictions_by_date=predictions_by_date,
        market=market,
        top_n=top_n,
        rebalance_frequency=rebalance_frequency,
        initial_capital=initial_capital,
        execution_mode=resolved_mode,
        cost_config=cost_config,
    )
    metrics, metric_warnings = _paper_metrics(simulation, resolved_methodology)
    return EvaluationResult(
        schema_version=SCHEMA_VERSION,
        engine_version=__version__,
        policy_version=PAPER_POLICY_VERSION,
        run_id=run_id,
        model_id=model_id,
        signal_metrics={},
        paper_metrics=metrics,
        account_metrics={},
        methodology=resolved_methodology,
        # paper 浮点股数无法装入要求整数股数的 TradeEvent；成交明细在 PaperSimulation.trades
        trades=(),
        warnings=(*simulation.warnings, *metric_warnings),
        skipped_counts=simulation.skipped_counts,
        provenance={"layer": "paper", "execution_mode": resolved_mode.value, "trades_location": TRADES_LOCATION},
    )
