"""市场状态只读视图（K02）：把 `MarketDataProvider` 包装为批量区间的 `MarketView`。

策略只允许查询、禁止写入；实现侧负责闭区间裁剪与升序，provider 无数据即"键存在 + 空序列"。
"""

from collections.abc import Mapping, Sequence
from datetime import date
from types import MappingProxyType
from typing import Any

from ..contracts.market import MarketBar
from ..contracts.protocols import MarketDataProvider
from ..contracts.validation import ensure_calendar_date, ensure_non_empty_str

__all__ = ["MarketState"]

_SUPPORTED_INTERVAL = "1d"  # 小时/15min 预留：实现前必须显式拒绝，禁止静默按日线返回


class MarketState:
    """实现 `MarketView` 的市场状态：批量区间查询 + 按标的缓存（同区间复用，禁止重复加载）。"""

    def __init__(self, provider: MarketDataProvider) -> None:
        self._provider = provider
        self._bars: dict[str, dict[date, MarketBar]] = {}
        # 已完整加载的闭区间列表：请求区间被任一区间覆盖即直接读缓存，避免逐标的重复加载
        self._covered: dict[str, list[tuple[date, date]]] = {}

    def get_bars(
        self,
        instrument_ids: str | Sequence[str],
        start: date,
        end: date,
        interval: str = "1d",
    ) -> Mapping[str, Sequence[MarketBar]]:
        """批量返回 [start, end] 闭区间行情；无数据标的返回空序列而非缺键。"""
        if interval != _SUPPORTED_INTERVAL:
            raise ValueError(f"interval must be {_SUPPORTED_INTERVAL!r}, got {interval!r}")
        ensure_calendar_date(start, "start")
        ensure_calendar_date(end, "end")
        if end < start:
            raise ValueError(f"end must be >= start, got start={start!r}, end={end!r}")
        requested = self._normalize_instrument_ids(instrument_ids)
        selected: dict[str, tuple[MarketBar, ...]] = {}
        for instrument_id in requested:
            selected[instrument_id] = self._bars_in_range(instrument_id, start, end)
        return MappingProxyType(selected)

    @staticmethod
    def _normalize_instrument_ids(instrument_ids: str | Sequence[str]) -> tuple[str, ...]:
        """str 视为单标的；序列逐项校验并去重（保持首次出现顺序），保证批量结果确定。"""
        if isinstance(instrument_ids, str):
            requested: tuple[Any, ...] = (instrument_ids,)
        elif isinstance(instrument_ids, (bytes, bytearray)) or not isinstance(instrument_ids, Sequence):
            raise ValueError(f"instrument_ids must be a str or sequence of str, got {instrument_ids!r}")  # noqa: TRY004
        else:
            requested = tuple(instrument_ids)
        for instrument_id in requested:
            ensure_non_empty_str(instrument_id, "instrument_ids item")
        return tuple(dict.fromkeys(requested))

    def _bars_in_range(self, instrument_id: str, start: date, end: date) -> tuple[MarketBar, ...]:
        self._ensure_loaded(instrument_id, start, end)
        bars = [bar for trading_date, bar in self._bars[instrument_id].items() if start <= trading_date <= end]
        bars.sort(key=lambda bar: bar.trading_date)
        return tuple(bars)

    def _ensure_loaded(self, instrument_id: str, start: date, end: date) -> None:
        covered = self._covered.setdefault(instrument_id, [])
        if any(range_start <= start and end <= range_end for range_start, range_end in covered):
            return
        fetched = self._fetch(instrument_id, start, end)
        known = self._bars.setdefault(instrument_id, {})
        for bar in fetched:
            previous = known.get(bar.trading_date)
            if previous is not None and previous != bar:
                raise ValueError(
                    f"conflicting bar for {instrument_id!r} at {bar.trading_date!r}: refresh differs from cache"
                )
            known[bar.trading_date] = bar
        _merge_interval(covered, start, end)

    def _fetch(self, instrument_id: str, start: date, end: date) -> tuple[MarketBar, ...]:
        # 区间内 bar 数不超过日历跨度 +1，交给 provider 截取后本地再裁剪；本地裁剪保证
        # 即使 provider 越界返回也不会把 end 之后的数据缓存/暴露给策略（防前视）。
        lookback_days = (end - start).days + 1
        raw = self._provider.get_history(instrument_id, end, lookback_days)
        if isinstance(raw, (str, bytes)) or not isinstance(raw, Sequence):
            raise ValueError(  # noqa: TRY004
                f"provider.get_history must return a sequence of MarketBar, got {raw!r}"
            )
        selected: list[MarketBar] = []
        for bar in raw:
            if not isinstance(bar, MarketBar):
                raise ValueError(f"provider.get_history items must be MarketBar, got {bar!r}")  # noqa: TRY004
            if bar.instrument_id != instrument_id:
                raise ValueError(f"provider returned bar for {bar.instrument_id!r} when {instrument_id!r} requested")
            if start <= bar.trading_date <= end:
                selected.append(bar)
        selected.sort(key=lambda bar: bar.trading_date)
        return tuple(selected)


def _merge_interval(covered: list[tuple[date, date]], start: date, end: date) -> None:
    """把新加载区间并入覆盖列表：重叠/相邻区间合并，避免覆盖列表随查询次数无界增长。"""
    merged: list[tuple[date, date]] = []
    for range_start, range_end in sorted([*covered, (start, end)]):
        if merged and (range_start - merged[-1][1]).days <= 1:
            last_start, last_end = merged[-1]
            merged[-1] = (last_start, max(last_end, range_end))
        else:
            merged.append((range_start, range_end))
    covered[:] = merged
