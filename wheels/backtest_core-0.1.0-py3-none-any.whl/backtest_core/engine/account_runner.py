"""account 层多日回测引擎（规格 §11.3、§12）：现金/整手/费用的可实现账户收益路径。

层语义（T12a/b/c：基础调仓循环 + 滑点降级/容量截断 + 尾日清算）：
- 信号日 = predictions_by_date 排序键；每 portfolio_config.rebalance_frequency 个信号日调仓一次，
  其余交易日只按 close mark；
- 固定先卖后买：卖出 = 持仓中名次跌出 top_n + sell_buffer 的标的（buffer 内保留不卖），
  买入 = 目标中尚未持有的标的（已持有目标不调仓）；
- 买入预算 = NAV_at_exec × (1 - cash_reserve_ratio) / N 按排名顺序分配，取整为 0 → skipped(zero_lot)，
  apply_buy 拒绝 → skipped(insufficient_cash)，禁止静默部分成交；成交价高于 base 时按成交价重算
  预算内股数，滑点成本不得把订单顶出预算；
- 执行时点由 resolve_execution_date 解析（默认 T+1 open）；尾日无下一交易日整批
  skipped(no_next_trading_day)，禁止回退信号日价格；
- 卖出缺价必须 locked(missing_price)（T12 验收，禁止静默持有）；
- 滑点降级全部走 SlippageV1.decide（T12b）：stats 缺失按 missing_volume_policy 走 warn
  （spread-only 成交、事件 participation=None）或 skip（显式 skipped + reason）；
  stats 有效且 p_raw > p_cap 时按 p_cap×adv20 截断成交，余量独立 skipped(capacity_exceeded)，
  与成交同执行时点且不顺延；
- NAV 序列 = [initial_capital, ...每日 close mark]，缺 close 回退 last_marks，两者皆缺剔除并 warning；
- 尾日清算 = 最后交易日、当日调仓之后、mark 之前执行一次：force 对全部可卖持仓复用卖出通路
  （成交事件 status/reason=forced_exit；不可交易仍 locked/skipped，locked 仓落 locked 事件并保留），
  mark/skip 不产生清算交易；force 下清算日调仓禁止新开仓（买入意图 skipped(no_next_trading_day)），
  避免「当日买入 + 当日强制卖出」违反 A 股 T+1 与「同标的同日无 buy+sell」约束；
  result.methodology.final_mark_policy 一律按 to_final_mark_policy 覆盖为实际执行策略（其余口径保留）。

订单驱动（K03）：
- `run_account_backtest_from_orders` 逐调仓日 close mark 后回调 OrderStrategy，订单按先卖后买在
  执行日 open 裁决；买单 shares/cash_amount 二选一（cash_amount 由引擎按成交价+费用折算整手向下），
  容量截断记 partial + capacity_exceeded，现金不足/零手/不可交易整单 rejected；
- 真实 T+1（仅订单路径）：买入成交即 lock_shares，下一交易日开盘前 unlock_shares；尾日锁定仓
  在 force 清算时落 locked(locked_position) 事件并保留持仓；
- 订单路径逐日产出 AccountSnapshot（NAV 口径与 _mark_day 完全一致），每笔策略订单对应一条
  OrderResult；策略只读视图按当日截止（MarketView.end 超过当前交易日显式拒绝，防前视）；
- 预测路径 `run_account_backtest` 仅为 phase-1 兼容保留（deprecated），行为逐字段不变。
"""

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, replace
from datetime import UTC, date, datetime, time, timedelta, tzinfo
from itertools import pairwise
from math import isfinite
from types import MappingProxyType
from typing import Any
from zoneinfo import ZoneInfo

from .. import __version__
from ..contracts.account import AccountSnapshot, AccountState, PositionSnapshot, UnlistedEntitlementSnapshot
from ..contracts.account_actions import (
    CashPayment,
    CorporateActionOperation,
    CreateCashReceivable,
    CreateShareEntitlement,
    ListShareEntitlement,
    RecordPosition,
)
from ..contracts.config import CostConfig, ExecutionConfig, PortfolioConfig
from ..contracts.enums import EventStatus, ExecutionMode, RankingDirection, ReasonCode, Side
from ..contracts.events import TradeEvent
from ..contracts.execution_feedback import ActiveOrderSnapshot, ExecutionPhase, ExecutionUpdate
from ..contracts.market import MarketBar
from ..contracts.order import OrderIntent, OrderResult, OrderStatus
from ..contracts.prediction import Prediction
from ..contracts.protocols import ExecutionObserver, MarketDataProvider, MarketView, OrderStrategy
from ..contracts.result import SCHEMA_VERSION, EvaluationResult, MetricMethodology
from ..contracts.validation import ensure_calendar_date, ensure_enum_member, ensure_finite
from ..evaluation.methodology import DefaultEvaluationEngine
from ..policies.cost import AShareCostModel
from ..policies.execution import NoNextTradingDayError, execution_price, resolve_execution_date
from ..policies.liquidation import resolve_liquidation_plan, to_final_mark_policy
from ..policies.slippage import POLICY_VERSION, SlippageV1, compute_liquidity_stats
from ..policies.tradability import decide_tradability
from .account import (
    apply_account_actions,
    apply_buy,
    apply_sell,
    lock_shares,
    release_pending_cash,
    unlock_shares,
)
from .market_state import MarketState

__all__ = ["run_account_backtest", "run_account_backtest_from_orders"]

# 执行时钟按模式取值：t1_open 用次日 09:30（任务默认）；同日模式须晚于当日信号时点
_EXECUTION_CLOCK: dict[ExecutionMode, time] = {
    ExecutionMode.T1_OPEN: time(9, 30),
    ExecutionMode.SAME_DAY_CLOSE: time(15, 0),
    ExecutionMode.MID: time(11, 30),
}
# 尾日无下一交易日的事件时间：signal_time + 1μs，保证严格晚于信号时间且不依赖固定时钟
# （固定 23:59:59 会与 signal_time_of_day 相撞导致 execution_time <= signal_time 直接构造失败）
_TAIL_EVENT_DELAY = timedelta(microseconds=1)
_TRADES_LOCATION = "result"


@dataclass(frozen=True)
class _Rebalance:
    """一次调仓意图：selected 为买入目标（top_n），keep 为保留集（top_n + sell_buffer）名次。"""

    signal_date: date
    selected: tuple[str, ...]
    keep: tuple[str, ...]
    signal_time: datetime


@dataclass(frozen=True)
class _ScheduledRebalance(_Rebalance):
    """已解析出执行日的调仓：execution_date 必为交易日历内日期。"""

    execution_date: date


@dataclass(frozen=True)
class _OrderTicket:
    """单笔订单的执行票据（K03 收敛）：预测路径与订单路径共用同一执行结构。

    预测路径把调仓拆成买卖票据（买单以 cash_amount 承载预算）；订单路径把策略意图归一为同一
    结构，执行层不再区分来源。shares/cash_amount 语义与 OrderIntent 一致；卖出方向的可卖量
    （持仓 − locked）由调用方在执行时点算出并作为 _execute_sell 的 sellable 参数传入。
    """

    signal_date: date
    signal_time: datetime
    execution_date: date
    instrument_id: str
    side: Side
    shares: int | None
    cash_amount: float | None
    limit_price: float | None = None


@dataclass(frozen=True)
class _ScheduledOrder:
    """订单路径的已排程订单：策略意图 + 信号上下文 + 执行日（执行时归一为 _OrderTicket）。"""

    signal_date: date
    signal_time: datetime
    execution_date: date
    order: OrderIntent


@dataclass(frozen=True)
class _ExecutionOutcome:
    """单笔执行裁决摘要：订单路径据此映射 OrderResult，预测路径忽略。

    fees = 佣金 + 印花税 + 过户费 + 滑点成本；滑点已内嵌成交价，不产生额外现金流水。
    """

    status: OrderStatus
    filled_shares: int
    fill_price: float | None
    fees: float
    reason: ReasonCode | None


def _order_result(order: OrderIntent, outcome: _ExecutionOutcome) -> OrderResult:
    return OrderResult(
        order=order,
        status=outcome.status,
        filled_shares=outcome.filled_shares,
        fill_price=outcome.fill_price,
        fees=outcome.fees,
        reason=outcome.reason,
    )


def _active_order(item: _ScheduledOrder) -> ActiveOrderSnapshot:
    order = item.order
    return ActiveOrderSnapshot(
        order_id=order.order_id or "", episode_id=order.episode_id, instrument_id=order.instrument_id,
        side=order.side, remaining_shares=order.shares, execution_date=item.execution_date,
    )


def _active_pending(pending: Mapping[date, Sequence[_ScheduledOrder]]) -> dict[str, ActiveOrderSnapshot]:
    return {
        item.order.order_id: _active_order(item)
        for day in sorted(pending) for item in pending[day]
        if item.order.order_id is not None
    }


def _notify_observer(
    observer: ExecutionObserver | None, run_id: str, sequence: list[int], **fields: Any,
) -> None:
    if observer is None:
        return
    sequence[0] += 1
    update = ExecutionUpdate(event_id=f"{run_id}:execution:{sequence[0]}", sequence_no=sequence[0], **fields)
    observer.on_update(update)


def _ensure_dates(dates: Sequence[date]) -> tuple[date, ...]:
    """严格升序的交易日序列：resolve_execution_date 与 NAV 序列都依赖该次序。"""
    if isinstance(dates, (str, bytes)) or not isinstance(dates, Sequence):
        raise ValueError(f"dates must be a sequence of date, got {dates!r}")  # noqa: TRY004
    ordered = tuple(dates)
    for trading_date in ordered:
        ensure_calendar_date(trading_date, "dates item")
    for previous, current in pairwise(ordered):
        if current <= previous:
            raise ValueError("dates must be strictly ascending")
    return ordered


def _rank_targets(
    predictions: Sequence[Prediction],
    signal_date: date,
) -> tuple[tuple[str, ...], datetime]:
    """全量名次（降序/升序 + instrument_id 平局）：top_n 与 sell_buffer 共用同一名次切片。

    重复标的/方向不一致显式失败；批级信号时间取 max(signal_time)：调仓决策在最后一条预测可
    用时才成立，前视校验取最坏时点。
    """
    direction: RankingDirection | None = None
    checked: list[Prediction] = []
    seen: set[str] = set()
    for prediction in predictions:
        if not isinstance(prediction, Prediction):
            raise ValueError(f"predictions items must be Prediction, got {prediction!r}")  # noqa: TRY004
        if prediction.instrument_id in seen:
            raise ValueError(f"{signal_date!r}: duplicate prediction for {prediction.instrument_id!r}")
        if direction is None:
            direction = prediction.ranking_direction
        elif prediction.ranking_direction is not direction:
            raise ValueError(f"{signal_date!r}: ranking_direction must be consistent within a date")
        seen.add(prediction.instrument_id)
        checked.append(prediction)
    # descending 时取负值升序等价于按值降序，同时保留 instrument_id 升序平局规则
    sign = -1.0 if direction is RankingDirection.DESCENDING else 1.0
    ordered = sorted(checked, key=lambda prediction: (prediction.value * sign, prediction.instrument_id))
    ranked = tuple(prediction.instrument_id for prediction in ordered)
    return ranked, max(prediction.signal_time for prediction in checked)


def _execution_time(execution_date: date, signal_time: datetime, mode: ExecutionMode) -> datetime:
    """执行日 + 模式时钟：与 signal_time 共同时区，保证时间轴可比。"""
    return datetime.combine(execution_date, _EXECUTION_CLOCK[mode], tzinfo=signal_time.tzinfo)


def _blocked_order(
    bar: MarketBar | None,
    mode: ExecutionMode,
    execution_config: ExecutionConfig,
    side: Side,
) -> tuple[EventStatus, ReasonCode] | None:
    """方向性可交易性判定：None 表示允许进入执行层，否则返回 (status, reason)。

    卖出缺价强制 locked：ExecutionConfig 默认 missing_price_policy=skip 会让持仓被静默跳过，
    与 T12 验收「卖出缺价必产 locked 事件」冲突，故卖出方向在此覆盖。
    """
    if bar is None:
        if side is Side.SELL:
            return EventStatus.LOCKED, ReasonCode.MISSING_PRICE
        status = EventStatus.SKIPPED if execution_config.missing_price_policy == "skip" else EventStatus.LOCKED
        return status, ReasonCode.MISSING_PRICE
    decision = decide_tradability(bar, mode, execution_config)
    if not decision.can_buy and not decision.can_sell:
        for known, reason in (
            (bar.market_state_known, ReasonCode.MARKET_STATE_UNKNOWN),
            (bar.st_state_known, ReasonCode.ST_STATE_UNKNOWN),
            (bar.limit_state_known, ReasonCode.LIMIT_STATE_UNKNOWN),
            (not bar.corporate_action_reference_required or bar.reference_known, ReasonCode.REFERENCE_UNKNOWN),
        ):
            if not known:
                return decision.buy_status if side is Side.BUY else decision.sell_status, reason
    if side is Side.BUY:
        if decision.can_buy:
            return None
        if not bar.is_trading:
            return decision.buy_status, ReasonCode.SUSPENDED
        if bar.limit_up:
            return decision.buy_status, ReasonCode.LIMIT_UP
        return decision.buy_status, ReasonCode.MISSING_PRICE
    if decision.can_sell:
        return None
    if not bar.is_trading:
        return decision.sell_status, ReasonCode.SUSPENDED
    if bar.limit_down:
        return decision.sell_status, ReasonCode.LIMIT_DOWN
    return EventStatus.LOCKED, ReasonCode.MISSING_PRICE


def _event(
    *,
    signal_time: datetime,
    execution_time: datetime,
    instrument_id: str,
    side: Side,
    shares: int,
    base_price: float | None,
    execution_price_value: float | None,
    amount: float,
    commission: float,
    stamp_tax: float,
    transfer_fee: float,
    slippage_cost: float,
    participation: float | None,
    status: EventStatus,
    reason: ReasonCode | None,
) -> TradeEvent:
    return TradeEvent(
        signal_time=signal_time,
        execution_time=execution_time,
        instrument_id=instrument_id,
        side=side,
        shares=shares,
        base_price=base_price,
        execution_price=execution_price_value,
        amount=amount,
        commission=commission,
        stamp_tax=stamp_tax,
        transfer_fee=transfer_fee,
        slippage_cost=slippage_cost,
        participation=participation,
        status=status,
        reason=reason,
    )


@dataclass(frozen=True)
class _FillPlan:
    """滑点与容量决策的执行计划：filled=False 整单跳过；remainder>0 为容量截断余量（须独立落 skipped）。"""

    filled: bool
    fill_price: float
    shares: int
    participation: float | None
    remainder: int
    skip_reason: ReasonCode | None
    warnings: tuple[str, ...]


def _capacity_capped_shares(
    *,
    side: Side,
    requested: int,
    sellable: int,
    cap_amount: float,
    fill_price: float,
    lot_size: int,
) -> int:
    """容量上限（p_cap×adv20 元）内的成交股数：整手向下；整仓卖出沿用 apply_sell 的零股清仓例外。"""
    cap_shares = int(cap_amount // fill_price)
    if side is Side.SELL and requested == sellable and cap_shares >= requested:
        # 全仓清仓单（可能含零股）在容量内按请求量成交，与 apply_sell allow_odd_lot_close 一致
        return requested
    return min(requested, cap_shares // lot_size * lot_size)


def _plan_order(
    *,
    instrument_id: str,
    side: Side,
    shares: int,
    sellable: int,
    budget: float | None,
    base_price: float,
    signal_date: date,
    market: MarketDataProvider,
    cost_config: CostConfig,
    cost_model: AShareCostModel,
    slippage: SlippageV1,
    lot_size: int,
) -> _FillPlan:
    """滑点 decide + 容量截断的执行计划（规格 §11.4）：降级分支显式，容量余量由调用方落 skipped。

    budget 非 None（买入）时按 fill_price 重算预算内整手数：成交价高于 base 时若沿用 base 价估计，
    滑点成本会把订单顶出预算并被 apply_buy 以 insufficient_cash 整体拒绝。
    """
    order_amount = shares * base_price
    # σ 用 ddof=1 的收益样本，需 sigma_window 个收益即 sigma_window+1 个 close：
    # 仅取 adv_window 根 bar 时 σ20 恒缺 1 个样本，会把有效历史误判为短历史
    lookback_days = max(cost_config.adv_window, cost_config.sigma_window + 1)
    stats = compute_liquidity_stats(
        market.get_history(instrument_id, signal_date, lookback_days),
        adv_window=cost_config.adv_window,
        sigma_window=cost_config.sigma_window,
        sigma_clip=cost_config.sigma_clip,
    )
    decision = slippage.decide(
        side,
        order_amount,
        base_price,
        None if stats is None else stats.adv20,
        None if stats is None else stats.sigma20,
    )
    if decision.result is None:
        return _FillPlan(
            filled=False,
            fill_price=base_price,
            shares=0,
            participation=None,
            remainder=0,
            skip_reason=decision.skip_reason,
            warnings=decision.warnings,
        )
    result = decision.result
    planned = shares
    if budget is not None:
        planned = min(planned, _budget_shares(budget, result.fill_price, cost_model, lot_size))
        if planned == 0:
            return _FillPlan(
                filled=False,
                fill_price=result.fill_price,
                shares=0,
                participation=None,
                remainder=0,
                skip_reason=ReasonCode.ZERO_LOT,
                warnings=decision.warnings,
            )
    remainder = 0
    if result.capacity_exceeded:
        if stats is None:  # capacity 标志只可能由有效 stats 的 compute 产生
            raise ValueError("capacity_exceeded requires liquidity stats")
        capped = _capacity_capped_shares(
            side=side,
            requested=planned,
            sellable=sellable,
            cap_amount=cost_config.p_cap * stats.adv20,
            fill_price=result.fill_price,
            lot_size=lot_size,
        )
        if capped <= 0:
            return _FillPlan(
                filled=False,
                fill_price=result.fill_price,
                shares=0,
                participation=None,
                remainder=0,
                skip_reason=ReasonCode.CAPACITY_EXCEEDED,
                warnings=decision.warnings,
            )
        remainder = planned - capped
        planned = capped
    return _FillPlan(
        filled=True,
        fill_price=result.fill_price,
        shares=planned,
        participation=decision.participation,
        remainder=remainder,
        skip_reason=None,
        warnings=decision.warnings,
    )


def _budget_shares(budget: float, price: float, cost_model: AShareCostModel, lot_size: int) -> int:
    """预算内最大整手股数：预估费用按预算上界计（费用对成交额单调，估计值不会低估实际费用）。"""
    if budget <= 0.0:
        return 0
    commission, stamp_tax, transfer_fee = cost_model.calculate(Side.BUY, budget)
    affordable = budget - (commission + stamp_tax + transfer_fee)
    if affordable <= 0.0:
        return 0
    return int(affordable // price) // lot_size * lot_size


def _flat_skip_event(
    *,
    ticket: _OrderTicket,
    execution_time: datetime,
    base_price: float | None,
    reason: ReasonCode,
) -> TradeEvent:
    """无成交跳过事件的统一构造：shares/费用全零、无执行价，reason 必填（禁止静默丢弃）。"""
    return _event(
        signal_time=ticket.signal_time,
        execution_time=execution_time,
        instrument_id=ticket.instrument_id,
        side=ticket.side,
        shares=0,
        base_price=base_price,
        execution_price_value=None,
        amount=0.0,
        commission=0.0,
        stamp_tax=0.0,
        transfer_fee=0.0,
        slippage_cost=0.0,
        participation=None,
        status=EventStatus.SKIPPED,
        reason=reason,
    )


@dataclass(frozen=True)
class _OrderContext:
    """订单执行上下文：冻结的执行环境，避免订单函数之间重复传参。"""

    market: MarketDataProvider
    mode: ExecutionMode
    execution_config: ExecutionConfig
    cost_config: CostConfig
    cost_model: AShareCostModel
    cost_config_resolver: Callable[[date, str], CostConfig] | None
    slippage: SlippageV1
    lot_size: int
    cash_reserve_ratio: float


def _cost_context(context: _OrderContext, execution_date: date, instrument_id: str) -> _OrderContext:
    """Resolve optional execution-date costs per order while preserving static defaults."""
    resolver = context.cost_config_resolver
    if resolver is None:
        return context
    config = resolver(execution_date, instrument_id)
    if not isinstance(config, CostConfig):
        raise ValueError(f"cost_config_resolver must return CostConfig, got {config!r}")  # noqa: TRY004
    return replace(context, cost_config=config, cost_model=AShareCostModel(config),
                   slippage=SlippageV1(config))


def _nav_at_execution(
    state: AccountState,
    market: MarketDataProvider,
    execution_date: date,
    mode: ExecutionMode,
) -> float:
    """执行时 NAV：持仓按执行价估值，缺执行价回退 last_marks；两者皆缺显式失败。"""
    value = state.cash + sum(item.amount for item in state.cash_receivables.values())
    for instrument_id in sorted(state.positions):
        quantity = float(state.positions[instrument_id])
        if quantity <= 0:
            continue
        bar = market.get_bar(instrument_id, execution_date)
        price = execution_price(bar, mode) if bar is not None else None
        if price is None:
            price = state.last_marks.get(instrument_id)
        if price is None:
            raise ValueError(
                f"cannot value {instrument_id!r} at {execution_date!r}: no execution price or last mark"
            )
        value += quantity * price
    for entitlement in state.unlisted_entitlements.values():
        bar = market.get_bar(entitlement.instrument_id, execution_date)
        price = execution_price(bar, mode) if bar is not None else None
        if price is None:
            price = state.last_marks.get(entitlement.instrument_id)
        if price is None:
            raise ValueError(f"cannot value unlisted entitlement {entitlement.event_id!r} at {execution_date!r}")
        value += entitlement.shares * price
    return float(value)


def _mark_day(
    state: AccountState,
    market: MarketDataProvider,
    trading_date: date,
    warnings: list[str],
) -> tuple[AccountState, float, dict[str, float]]:
    """逐日 close mark：close 缺失回退 last_marks；两者皆缺从 NAV 剔除并 warning。

    第三个返回值是各持仓实际采用的 mark（缺价持仓不含键），供订单路径构造快照复用同一口径，
    避免快照与 NAV 两处各自解析导致数值漂移。
    """
    nav_value = state.cash + sum(item.amount for item in state.cash_receivables.values())
    marks = dict(state.last_marks)
    resolved: dict[str, float] = {}
    for instrument_id in sorted(state.positions):
        quantity = float(state.positions[instrument_id])
        if quantity <= 0:
            continue
        bar = market.get_bar(instrument_id, trading_date)
        close = bar.close if bar is not None else None
        if close is None or close <= 0.0:
            mark = state.last_marks.get(instrument_id)
            if mark is None:
                warnings.append(
                    f"account layer: no close or last mark for {instrument_id!r} at {trading_date}; "
                    "position excluded from NAV"
                )
                continue
        else:
            mark = close
            marks[instrument_id] = mark
        resolved[instrument_id] = mark
        nav_value += quantity * mark
    for entitlement in state.unlisted_entitlements.values():
        instrument_id = entitlement.instrument_id
        mark = resolved.get(instrument_id)
        if mark is None:
            bar = market.get_bar(instrument_id, trading_date)
            mark = bar.close if bar is not None else None
            if mark is None or mark <= 0.0:
                mark = state.last_marks.get(instrument_id)
        if mark is None:
            raise ValueError(f"no raw mark available for unlisted entitlement {entitlement.event_id!r}")
        resolved[instrument_id] = mark
        marks[instrument_id] = mark
        nav_value += entitlement.shares * mark
    updated = AccountState(
        cash=state.cash,
        available_cash=state.available_cash,
        positions=state.positions,
        locked=state.locked,
        cost=state.cost,
        last_marks=marks,
        fractional=state.fractional,
        processed_action_operations=state.processed_action_operations,
        record_positions=state.record_positions,
        record_costs=state.record_costs,
        cash_receivables=state.cash_receivables,
        unlisted_entitlements=state.unlisted_entitlements,
        pending_cash=state.pending_cash,
        gross_cash_dividends_paid=state.gross_cash_dividends_paid,
        withheld_cash_dividends_paid=state.withheld_cash_dividends_paid,
    )
    return updated, float(nav_value), resolved


def _execute_sell(
    context: _OrderContext,
    state: AccountState,
    ticket: _OrderTicket,
    sellable: int,
    events: list[TradeEvent],
    warnings: list[str],
    *,
    exit_status: EventStatus = EventStatus.FILLED,
    exit_reason: ReasonCode | None = None,
) -> tuple[AccountState, _ExecutionOutcome]:
    """卖出单：可交易性拒绝产事件，成交经 apply_sell 计费并更新状态。

    sellable（可卖量 = 持仓 − locked）是 T+1 裁决参数：请求量超过可卖量由 apply_sell
    以 locked_position 拒绝并落 locked 事件（禁止静默持有）；容量整仓零股例外按 sellable 判定。
    尾日清算复用本函数：成交事件可用 exit_status/exit_reason 改记 forced_exit。
    """
    assert ticket.shares is not None  # 卖单只认 shares（OrderIntent 保证）
    execution_time = _execution_time(ticket.execution_date, ticket.signal_time, context.mode)
    bar = context.market.get_bar(ticket.instrument_id, ticket.execution_date)
    base_price = execution_price(bar, context.mode) if bar is not None else None
    limit_reason = _limit_order_reason(ticket, bar, None)
    if limit_reason is not None:
        return _reject_limit_order(state, ticket, execution_time, base_price, limit_reason, events)
    blocked = _blocked_order(bar, context.mode, context.execution_config, Side.SELL)
    if blocked is not None:
        status, reason = blocked
        events.append(
            _event(
                signal_time=ticket.signal_time, execution_time=execution_time,
                instrument_id=ticket.instrument_id,
                side=Side.SELL, shares=0, base_price=base_price, execution_price_value=None, amount=0.0,
                commission=0.0, stamp_tax=0.0, transfer_fee=0.0, slippage_cost=0.0, participation=None,
                status=status, reason=reason,
            )
        )
        return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, reason)
    if base_price is None:
        raise ValueError(f"missing execution price for {ticket.instrument_id!r} at {ticket.execution_date!r}")
    plan = _plan_order(
        instrument_id=ticket.instrument_id, side=Side.SELL, shares=ticket.shares, sellable=sellable,
        budget=None, base_price=base_price, signal_date=ticket.signal_date, market=context.market,
        cost_config=context.cost_config, cost_model=context.cost_model, slippage=context.slippage,
        lot_size=context.lot_size,
    )
    warnings.extend(plan.warnings)
    if not plan.filled:
        assert plan.skip_reason is not None  # _FillPlan 不变量：无成交必带原因
        events.append(
            _flat_skip_event(
                ticket=ticket, execution_time=execution_time, base_price=base_price, reason=plan.skip_reason
            )
        )
        return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, plan.skip_reason)
    limit_reason = _limit_order_reason(ticket, bar, plan.fill_price)
    if limit_reason is not None:
        return _reject_limit_order(state, ticket, execution_time, base_price, limit_reason, events)
    result = apply_sell(
        state, ticket.instrument_id, plan.shares, plan.fill_price, context.cost_model, lot_size=context.lot_size
    )
    if not result.filled:
        # T+1 订单语义：锁定仓超卖按 locked 事件报告；其余拒绝维持 skipped
        status = EventStatus.LOCKED if result.reason is ReasonCode.LOCKED_POSITION else EventStatus.SKIPPED
        events.append(
            _event(
                signal_time=ticket.signal_time, execution_time=execution_time,
                instrument_id=ticket.instrument_id,
                side=Side.SELL, shares=0, base_price=base_price, execution_price_value=None, amount=0.0,
                commission=0.0, stamp_tax=0.0, transfer_fee=0.0, slippage_cost=0.0, participation=None,
                status=status, reason=result.reason,
            )
        )
        return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, result.reason)
    slippage_cost = abs(plan.fill_price - base_price) * result.shares
    events.append(
        _event(
            signal_time=ticket.signal_time, execution_time=execution_time, instrument_id=ticket.instrument_id,
            side=Side.SELL, shares=result.shares, base_price=base_price, execution_price_value=plan.fill_price,
            amount=result.amount, commission=result.commission, stamp_tax=result.stamp_tax,
            transfer_fee=result.transfer_fee,
            slippage_cost=slippage_cost, participation=plan.participation,
            status=exit_status, reason=exit_reason,
        )
    )
    capacity_reason: ReasonCode | None = None
    if plan.remainder > 0:
        capacity_reason = ReasonCode.CAPACITY_EXCEEDED
        events.append(
            _flat_skip_event(
                ticket=ticket, execution_time=execution_time, base_price=base_price,
                reason=ReasonCode.CAPACITY_EXCEEDED,
            )
        )
    # partial 判定：容量余量或整手/零股取整使实际成交少于请求（预测路径的请求量已是整手可卖量）
    partial = plan.remainder > 0 or result.shares < ticket.shares
    fees = result.commission + result.stamp_tax + result.transfer_fee + slippage_cost
    return result.state, _ExecutionOutcome(
        OrderStatus.PARTIAL if partial else OrderStatus.FILLED,
        result.shares,
        plan.fill_price,
        fees,
        capacity_reason,
    )


def _execute_order_buy(
    context: _OrderContext,
    state: AccountState,
    ticket: _OrderTicket,
    events: list[TradeEvent],
    warnings: list[str],
) -> tuple[AccountState, _ExecutionOutcome]:
    """买入单：shares 精确股数或 cash_amount 现金预算二选一，均整手向下裁决。

    cash_amount 按成交价+费用折算（复用 _budget_shares 口径）；容量截断允许部分成交并记
    partial(capacity_exceeded)；现金不足/零手/不可交易整单 rejected，禁止静默部分成交。
    费用口径：现金变化 = amount + 三费；滑点成本已内嵌成交价（fill_price），仅作分析字段
    落事件，不二次扣款。
    """
    assert ticket.side is Side.BUY
    execution_time = _execution_time(ticket.execution_date, ticket.signal_time, context.mode)
    bar = context.market.get_bar(ticket.instrument_id, ticket.execution_date)
    base_price = execution_price(bar, context.mode) if bar is not None else None
    limit_reason = _limit_order_reason(ticket, bar, None)
    if limit_reason is not None:
        return _reject_limit_order(state, ticket, execution_time, base_price, limit_reason, events)
    blocked = _blocked_order(bar, context.mode, context.execution_config, Side.BUY)
    if blocked is not None:
        status, reason = blocked
        events.append(
            _event(
                signal_time=ticket.signal_time, execution_time=execution_time,
                instrument_id=ticket.instrument_id,
                side=Side.BUY, shares=0, base_price=base_price, execution_price_value=None, amount=0.0,
                commission=0.0, stamp_tax=0.0, transfer_fee=0.0, slippage_cost=0.0, participation=None,
                status=status, reason=reason,
            )
        )
        return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, reason)
    if base_price is None:
        raise ValueError(f"missing execution price for {ticket.instrument_id!r} at {ticket.execution_date!r}")
    budget: float | None
    if ticket.cash_amount is not None:
        budget = ticket.cash_amount
        shares = _budget_shares(budget, base_price, context.cost_model, context.lot_size)
        if shares == 0:
            events.append(
                _event(
                    signal_time=ticket.signal_time, execution_time=execution_time,
                    instrument_id=ticket.instrument_id,
                    side=Side.BUY, shares=0, base_price=base_price, execution_price_value=None, amount=0.0,
                    commission=0.0, stamp_tax=0.0, transfer_fee=0.0, slippage_cost=0.0, participation=None,
                    status=EventStatus.SKIPPED, reason=ReasonCode.ZERO_LOT,
                )
            )
            return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, ReasonCode.ZERO_LOT)
    else:
        assert ticket.shares is not None  # 买单恰选其一（OrderIntent 保证）
        budget = None
        shares = ticket.shares
    plan = _plan_order(
        instrument_id=ticket.instrument_id, side=Side.BUY, shares=shares, sellable=shares, budget=budget,
        base_price=base_price, signal_date=ticket.signal_date, market=context.market,
        cost_config=context.cost_config, cost_model=context.cost_model, slippage=context.slippage,
        lot_size=context.lot_size,
    )
    warnings.extend(plan.warnings)
    if not plan.filled:
        assert plan.skip_reason is not None  # _FillPlan 不变量：无成交必带原因
        events.append(
            _flat_skip_event(
                ticket=ticket, execution_time=execution_time, base_price=base_price, reason=plan.skip_reason
            )
        )
        return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, plan.skip_reason)
    limit_reason = _limit_order_reason(ticket, bar, plan.fill_price)
    if limit_reason is not None:
        return _reject_limit_order(state, ticket, execution_time, base_price, limit_reason, events)
    result = apply_buy(
        state, ticket.instrument_id, plan.shares, plan.fill_price, context.cost_model, lot_size=context.lot_size
    )
    if not result.filled:
        events.append(
            _event(
                signal_time=ticket.signal_time, execution_time=execution_time,
                instrument_id=ticket.instrument_id,
                side=Side.BUY, shares=0, base_price=base_price, execution_price_value=None, amount=0.0,
                commission=0.0, stamp_tax=0.0, transfer_fee=0.0, slippage_cost=0.0, participation=None,
                status=EventStatus.SKIPPED, reason=result.reason,
            )
        )
        return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, result.reason)
    slippage_cost = abs(plan.fill_price - base_price) * result.shares
    events.append(
        _event(
            signal_time=ticket.signal_time, execution_time=execution_time, instrument_id=ticket.instrument_id,
            side=Side.BUY, shares=result.shares, base_price=base_price, execution_price_value=plan.fill_price,
            amount=result.amount, commission=result.commission, stamp_tax=result.stamp_tax,
            transfer_fee=result.transfer_fee,
            slippage_cost=slippage_cost, participation=plan.participation,
            status=EventStatus.FILLED, reason=None,
        )
    )
    capacity_reason: ReasonCode | None = None
    if plan.remainder > 0:
        capacity_reason = ReasonCode.CAPACITY_EXCEEDED
        events.append(
            _flat_skip_event(
                ticket=ticket, execution_time=execution_time, base_price=base_price,
                reason=ReasonCode.CAPACITY_EXCEEDED,
            )
        )
    # partial：容量余量，或 shares 路径整手取整使成交少于请求（cash 路径请求量由引擎折算）
    partial = plan.remainder > 0 or (ticket.shares is not None and result.shares < ticket.shares)
    fees = result.commission + result.stamp_tax + result.transfer_fee + slippage_cost
    return result.state, _ExecutionOutcome(
        OrderStatus.PARTIAL if partial else OrderStatus.FILLED,
        result.shares,
        plan.fill_price,
        fees,
        capacity_reason,
    )


def _execute_rebalance(
    context: _OrderContext,
    state: AccountState,
    batch: _ScheduledRebalance,
    events: list[TradeEvent],
    warnings: list[str],
    *,
    block_new_positions: bool = False,
) -> AccountState:
    """执行一次调仓：固定先卖后买，卖出边界=名次超出 keep；买入预算按目标标的数均分。

    block_new_positions=True（执行日即尾日清算日且 force）：卖出/保留逻辑不变，买入意图一律
    skipped(no_next_trading_day)——T+1 下当日买入无法当日强制卖出，放行会产出同标的同日 buy+sell。
    """
    execution_time = _execution_time(batch.execution_date, batch.signal_time, context.mode)
    keep = set(batch.keep)
    for instrument_id in sorted(set(state.positions) - keep):
        held = int(state.positions[instrument_id])
        locked = int(state.locked.get(instrument_id, 0.0))
        state, _ = _execute_sell(
            context,
            state,
            _OrderTicket(
                signal_date=batch.signal_date,
                signal_time=batch.signal_time,
                execution_date=batch.execution_date,
                instrument_id=instrument_id,
                side=Side.SELL,
                shares=held - locked,
                cash_amount=None,
            ),
            held - locked,
            events,
            warnings,
        )
    count = len(batch.selected)
    if count == 0:  # 选择结果为空（输入已拒绝空序列）：无事可做，显式返回避免除零
        return state
    if block_new_positions:
        blocked_buys = 0
        for instrument_id in batch.selected:
            if state.positions.get(instrument_id, 0.0) > 0:
                continue
            events.append(_tail_skip_event(batch.signal_time, execution_time, instrument_id, Side.BUY))
            blocked_buys += 1
        if blocked_buys:
            warnings.append(
                f"account layer: rebalance on {batch.signal_date} executes on the liquidation day; "
                f"{blocked_buys} buy intent(s) blocked (no new positions: same-day forced exit / T+1)"
            )
        return state
    nav_at_execution = _nav_at_execution(state, context.market, batch.execution_date, context.mode)
    per_name_budget = nav_at_execution * (1.0 - context.cash_reserve_ratio) / count
    for instrument_id in batch.selected:
        if state.positions.get(instrument_id, 0.0) > 0:
            continue
        state, _ = _execute_order_buy(
            context,
            state,
            _OrderTicket(
                signal_date=batch.signal_date,
                signal_time=batch.signal_time,
                execution_date=batch.execution_date,
                instrument_id=instrument_id,
                side=Side.BUY,
                shares=None,
                cash_amount=per_name_budget,
            ),
            events,
            warnings,
        )
    return state


def _liquidate_positions(
    context: _OrderContext,
    state: AccountState,
    execution_date: date,
    history_end_date: date,
    events: list[TradeEvent],
    warnings: list[str],
    *,
    per_order_context: Callable[[date, str], _OrderContext] | None = None,
    observer: ExecutionObserver | None = None,
    run_id: str = "",
    sequence: list[int] | None = None,
) -> AccountState:
    """尾日清算：force 对全部可卖持仓复用卖出通路；mark/skip 不产生交易（估值逐日照常）。

    清算信号取执行日 00:00：终态清算是已知的行政动作，不依赖行情时点、不引入前视；
    执行时点/价格仍取当日模式时钟/模式价，滑点窗口截止上一交易日（防前视）。
    locked 仓不可卖：卖出意图按 positions - locked 生成，locked 部分落 locked 事件并保留持仓。
    """
    sellable_positions: dict[str, float] = {}
    locked_positions: dict[str, float] = {}
    for instrument_id in sorted(state.positions):
        held = float(state.positions[instrument_id])
        locked_quantity = float(state.locked.get(instrument_id, 0.0))
        if held - locked_quantity > 0.0:
            sellable_positions[instrument_id] = held - locked_quantity
        if locked_quantity > 0.0:
            locked_positions[instrument_id] = locked_quantity
    plan = resolve_liquidation_plan(context.execution_config.final_liquidation, sellable_positions)
    if plan.final_liquidation != "force" or (not plan.sell_intents and not locked_positions):
        return state
    signal_time = datetime.combine(execution_date, time(0, 0), tzinfo=UTC)
    execution_time = _execution_time(execution_date, signal_time, context.mode)
    seq = sequence if sequence is not None else [0]
    active = {
        f"{run_id}:liquidation:{execution_date}:{item.instrument_id}": ActiveOrderSnapshot(
            f"{run_id}:liquidation:{execution_date}:{item.instrument_id}", None, item.instrument_id,
            Side.SELL, int(item.target_shares), execution_date,
        ) for item in plan.sell_intents
    }
    for intent in plan.sell_intents:
        order_id = f"{run_id}:liquidation:{execution_date}:{intent.instrument_id}"
        attempt_id = f"{order_id}:attempt:1"
        before, event_start = state, len(events)
        order_context = (
            per_order_context(execution_date, intent.instrument_id)
            if per_order_context is not None else context
        )
        state, outcome = _execute_sell(
            order_context,
            state,
            _OrderTicket(
                signal_date=history_end_date,
                signal_time=signal_time,
                execution_date=execution_date,
                instrument_id=intent.instrument_id,
                side=Side.SELL,
                shares=int(intent.target_shares),
                cash_amount=None,
            ),
            int(intent.target_shares),
            events,
            warnings,
            exit_status=EventStatus.FORCED_EXIT,
            exit_reason=ReasonCode.FORCED_EXIT,
        )
        fill_events = [event for event in events[event_start:] if event.status is EventStatus.FORCED_EXIT]
        active.pop(order_id, None)
        if observer is not None and fill_events:
            trade = replace(fill_events[0], order_id=order_id, fill_id=f"{attempt_id}:fill:1", sequence_no=seq[0] + 1)
            events[events.index(fill_events[0], event_start)] = trade
            _notify_observer(observer, run_id, seq, phase=ExecutionPhase.FILL, trading_date=execution_date,
                episode_id=None, order_id=order_id, attempt_id=attempt_id, fill_id=trade.fill_id, trade=trade,
                pre_state=before, post_state=state, cash_delta=state.cash - before.cash, active_orders=active)
        _notify_observer(observer, run_id, seq, phase=ExecutionPhase.TERMINAL, trading_date=execution_date,
            episode_id=None, order_id=order_id, attempt_id=attempt_id, fill_id=None, trade=None,
            pre_state=state, post_state=state, cash_delta=0.0, active_orders=active,
            order_status=outcome.status.value, reason=outcome.reason.value if outcome.reason else None)
    for instrument_id in locked_positions:
        event = _event(
            signal_time=signal_time, execution_time=execution_time, instrument_id=instrument_id,
            side=Side.SELL, shares=0, base_price=None, execution_price_value=None, amount=0.0,
            commission=0.0, stamp_tax=0.0, transfer_fee=0.0, slippage_cost=0.0, participation=None,
            status=EventStatus.LOCKED, reason=ReasonCode.LOCKED_POSITION,
        )
        locked_order_id = f"{run_id}:liquidation:{execution_date}:{instrument_id}:locked"
        if observer is not None:
            event = replace(event, order_id=locked_order_id, sequence_no=seq[0] + 1)
        events.append(event)
        _notify_observer(observer, run_id, seq, phase=ExecutionPhase.TERMINAL, trading_date=execution_date,
            episode_id=None, order_id=locked_order_id if observer is not None else None,
            attempt_id=None, fill_id=None, trade=None, pre_state=state, post_state=state,
            cash_delta=0.0, active_orders=active, order_status="locked",
            reason=ReasonCode.LOCKED_POSITION.value)
    return state


def _tail_skip_event(signal_time: datetime, execution_time: datetime, instrument_id: str, side: Side) -> TradeEvent:
    return _event(
        signal_time=signal_time,
        execution_time=execution_time,
        instrument_id=instrument_id,
        side=side,
        shares=0,
        base_price=None,
        execution_price_value=None,
        amount=0.0,
        commission=0.0,
        stamp_tax=0.0,
        transfer_fee=0.0,
        slippage_cost=0.0,
        participation=None,
        status=EventStatus.SKIPPED,
        reason=ReasonCode.NO_NEXT_TRADING_DAY,
    )


def _emit_no_next_day(
    state: AccountState,
    batch: _Rebalance,
    events: list[TradeEvent],
    warnings: list[str],
) -> None:
    """尾日整批显式落事件：按先卖后买列出意图，禁止回退信号日价格成交。"""
    execution_time = batch.signal_time + _TAIL_EVENT_DELAY
    keep = set(batch.keep)
    for instrument_id in sorted(set(state.positions) - keep):
        events.append(_tail_skip_event(batch.signal_time, execution_time, instrument_id, Side.SELL))
    for instrument_id in batch.selected:
        if state.positions.get(instrument_id, 0.0) > 0:
            continue
        events.append(_tail_skip_event(batch.signal_time, execution_time, instrument_id, Side.BUY))
    warnings.append(
        f"account layer: rebalance on {batch.signal_date} skipped: no next trading day "
        "(no signal-day price fallback)"
    )


def _skipped_counts(events: Sequence[TradeEvent]) -> dict[str, int]:
    """按 reason 全量计数（含 forced_exit 真实成交）：dict 按键排序输出，保证序列化与复跑结果稳定。

    契约字段名为 skipped_counts，但口径是「带 reason 的事件计数」：forced_exit 是真实成交
    同样计入，调用方不得把它当作"仅未成交"计数使用。
    """
    counts: dict[str, int] = {}
    for event in events:
        if event.reason is None:
            continue
        counts[event.reason.value] = counts.get(event.reason.value, 0) + 1
    return dict(sorted(counts.items()))


def _unlock_due_locks(state: AccountState) -> AccountState:
    """新交易日开盘前释放 T+1 冻结（仅订单路径）：现存冻结均为至少一个交易日前买入所产生。"""
    for instrument_id in sorted(state.locked):
        shares = int(state.locked[instrument_id])
        if shares > 0:
            state = unlock_shares(state, instrument_id, shares)
    return state


class _AccountStateView:
    """只读 AccountView 实现（K03）：策略回调期间冻结账户状态，禁止写回。

    positions 用 PositionSnapshot 承载（price 与 market_value 同时为 None 表示缺价，
    不计入 NAV）；locked 为 T+1 当日不可卖股数（缺键视为 0）。
    """

    def __init__(
        self,
        *,
        cash: float,
        available_cash: float,
        positions: Mapping[str, PositionSnapshot],
        locked: Mapping[str, int],
        nav: float,
    ) -> None:
        self._cash = cash
        self._available_cash = available_cash
        self._positions = MappingProxyType(dict(positions))
        self._locked = MappingProxyType(dict(locked))
        self._nav = nav

    @property
    def cash(self) -> float:
        return self._cash

    @property
    def available_cash(self) -> float:
        return self._available_cash

    @property
    def positions(self) -> Mapping[str, PositionSnapshot]:
        return self._positions

    @property
    def locked(self) -> Mapping[str, int]:
        return self._locked

    @property
    def nav(self) -> float:
        return self._nav


class _AsOfMarketView:
    """按当日截止的 MarketView（K03）：end 超过当前交易日即显式拒绝，防前视。

    K02 MarketState 只保证「不返回 end 之后的数据」；模拟时钟由本包装持有，
    策略无法借扩展区间把未来 bar 拉进视野。
    """

    def __init__(self, market: MarketView, trading_date: date) -> None:
        self._market = market
        self._trading_date = trading_date

    def get_bars(
        self,
        instrument_ids: str | Sequence[str],
        start: date,
        end: date,
        interval: str = "1d",
    ) -> Mapping[str, Sequence[MarketBar]]:
        if end > self._trading_date:
            raise ValueError(
                f"MarketView end={end!r} exceeds current trading_date={self._trading_date!r}; "
                "lookahead is not allowed"
            )
        return self._market.get_bars(instrument_ids, start, end, interval)


def _build_account_view(state: AccountState, market: MarketDataProvider, trading_date: date) -> _AccountStateView:
    """调仓回调前的只读账户视图：NAV 与权威 close mark 使用相同权益组成。"""
    nav_value = state.cash + sum(item.amount for item in state.cash_receivables.values())
    positions: dict[str, PositionSnapshot] = {}
    for instrument_id in sorted(state.positions):
        quantity = int(state.positions[instrument_id])
        if quantity <= 0:
            continue
        bar = market.get_bar(instrument_id, trading_date)
        close = bar.close if bar is not None else None
        price = close if close is not None and close > 0.0 else state.last_marks.get(instrument_id)
        market_value = quantity * price if price is not None else None
        positions[instrument_id] = PositionSnapshot(
            shares=quantity,
            cost=float(state.cost.get(instrument_id, 0.0)),
            price=price,
            market_value=market_value,
        )
        if market_value is not None:
            nav_value += market_value
    for entitlement in state.unlisted_entitlements.values():
        position = positions.get(entitlement.instrument_id)
        price = position.price if position is not None else None
        if price is None:
            bar = market.get_bar(entitlement.instrument_id, trading_date)
            close = bar.close if bar is not None else None
            price = close if close is not None and close > 0.0 else state.last_marks.get(entitlement.instrument_id)
        if price is None:
            raise ValueError(f"no raw mark available for unlisted entitlement {entitlement.event_id!r}")
        nav_value += entitlement.shares * price
    locked = {key: int(value) for key, value in state.locked.items() if int(value) > 0}
    return _AccountStateView(
        cash=state.cash,
        available_cash=state.available_cash,
        positions=positions,
        locked=locked,
        nav=nav_value,
    )


def _account_snapshot(
    state: AccountState, trading_date: date, nav_value: float, resolved_marks: Mapping[str, float]
) -> AccountSnapshot:
    """用 _mark_day 的解析结果构建快照：NAV 与逐日估值同源，缺价持仓 price/market_value 皆 None。"""
    positions: dict[str, PositionSnapshot] = {}
    for instrument_id in sorted(state.positions):
        quantity = int(state.positions[instrument_id])
        if quantity <= 0:
            continue
        price = resolved_marks.get(instrument_id)
        market_value = quantity * price if price is not None else None
        positions[instrument_id] = PositionSnapshot(
            shares=quantity,
            cost=float(state.cost.get(instrument_id, 0.0)),
            price=price,
            market_value=market_value,
        )
    receivables_value = sum(item.amount for item in state.cash_receivables.values())
    gross_receivables_value = sum(float(item.gross_amount or 0.0) for item in state.cash_receivables.values())
    withholding_payable_value = sum(item.withheld_amount for item in state.cash_receivables.values())
    unlisted = {
        operation_id: UnlistedEntitlementSnapshot(
            event_id=item.event_id, instrument_id=item.instrument_id, shares=item.shares,
            price=resolved_marks[item.instrument_id], market_value=item.shares * resolved_marks[item.instrument_id],
        )
        for operation_id, item in state.unlisted_entitlements.items()
    }
    return AccountSnapshot(
        date=trading_date, cash=state.cash, positions=positions, nav=nav_value,
        receivables_value=receivables_value, unlisted_entitlements=unlisted,
        available_cash=state.available_cash,
        gross_receivables_value=gross_receivables_value,
        withholding_payable_value=withholding_payable_value,
        gross_cash_dividends_paid=state.gross_cash_dividends_paid,
        withheld_cash_dividends_paid=state.withheld_cash_dividends_paid,
    )


def _checked_order_intents(raw_orders: Sequence[OrderIntent], trading_date: date) -> tuple[OrderIntent, ...]:
    """策略返回值的形状校验：非法形状/元素显式失败，禁止静默丢弃订单。"""
    if isinstance(raw_orders, (str, bytes)) or not isinstance(raw_orders, Sequence):
        raise ValueError(  # noqa: TRY004
            f"strategy.orders_for({trading_date!r}) must return a sequence of OrderIntent, got {raw_orders!r}"
        )
    checked = tuple(raw_orders)
    for order in checked:
        if not isinstance(order, OrderIntent):
            raise ValueError(  # noqa: TRY004
                f"strategy.orders_for({trading_date!r}) items must be OrderIntent, got {order!r}"
            )
    return checked


def _checked_account_actions(
    provider: Callable[[date], Sequence[CorporateActionOperation]] | None, trading_date: date
) -> tuple[CorporateActionOperation, ...]:
    if provider is None:
        return ()
    actions = provider(trading_date)
    if isinstance(actions, (str, bytes)) or not isinstance(actions, Sequence):
        raise ValueError(f"account_actions_provider({trading_date!r}) must return a sequence")  # noqa: TRY004
    for action in actions:
        if not isinstance(action, (RecordPosition, CreateCashReceivable, CreateShareEntitlement,
                                   CashPayment, ListShareEntitlement)):
            raise ValueError(f"account_actions_provider returned unsupported action {action!r}")  # noqa: TRY004
        if action.effective_date != trading_date:
            raise ValueError(f"account action {action.operation_id!r} date does not match {trading_date}")
    return tuple(actions)


def _validate_ex_date_action_marks(
    actions: Sequence[CorporateActionOperation],
    state: AccountState,
    market: MarketDataProvider,
    trading_date: date,
) -> None:
    """拒绝旧收盘价与当日新增除权权益并计，避免公司行动日虚增 NAV。"""
    checked: set[str] = set()
    for action in actions:
        if not isinstance(action, (CreateCashReceivable, CreateShareEntitlement)):
            continue
        entitlement_per_share = (
            action.cash_per_share if isinstance(action, CreateCashReceivable) else action.shares_per_share
        )
        if entitlement_per_share <= 0 or state.positions.get(action.instrument_id, 0.0) <= 0:
            continue
        if action.instrument_id in checked:
            continue
        checked.add(action.instrument_id)
        bar = market.get_bar(action.instrument_id, trading_date)
        if (
            bar is None
            or not bar.is_trading
            or bar.close is None
            or not isfinite(bar.close)
            or bar.close <= 0
        ):
            raise ValueError(
                "corporate action ex-date valuation unavailable: "
                f"event_id={action.event_id!r}, instrument_id={action.instrument_id!r}, "
                f"date={trading_date.isoformat()}, reason=missing_or_nontrading_raw_close; "
                "refusing stale mark plus accrued entitlement"
            )


def _execute_order(
    context: _OrderContext,
    state: AccountState,
    item: _ScheduledOrder,
    events: list[TradeEvent],
    warnings: list[str],
) -> tuple[AccountState, _ExecutionOutcome]:
    """执行一笔已排程订单：可卖量在执行时点重算（信号→执行之间的锁定变化必须生效）。"""
    order = item.order
    # 费用/滑点按实际执行日与标的解析（默认回调为 None 时维持静态成本上下文）
    context = _cost_context(context, item.execution_date, order.instrument_id)
    if order.side is Side.SELL:
        assert order.shares is not None  # OrderIntent 保证
        held = int(state.positions.get(order.instrument_id, 0.0))
        locked_quantity = int(state.locked.get(order.instrument_id, 0.0))
        ticket = _OrderTicket(
            signal_date=item.signal_date,
            signal_time=item.signal_time,
            execution_date=item.execution_date,
            instrument_id=order.instrument_id,
            side=Side.SELL,
            shares=order.shares,
            cash_amount=None,
            limit_price=order.limit_price,
        )
        # 可卖量在执行时点重算：信号→执行之间的锁定变化必须生效
        return _execute_sell(context, state, ticket, held - locked_quantity, events, warnings)
    ticket = _OrderTicket(
        signal_date=item.signal_date,
        signal_time=item.signal_time,
        execution_date=item.execution_date,
        instrument_id=order.instrument_id,
        side=Side.BUY,
        shares=order.shares,
        cash_amount=order.cash_amount,
        limit_price=order.limit_price,
    )
    updated, outcome = _execute_order_buy(context, state, ticket, events, warnings)
    if outcome.filled_shares > 0:
        # 真实 T+1：买入成交即冻结，下一交易日开盘前由 _unlock_due_locks 释放
        updated = lock_shares(updated, order.instrument_id, outcome.filled_shares)
    return updated, outcome


def _execute_scheduled_orders(
    context: _OrderContext,
    state: AccountState,
    scheduled: Sequence[_ScheduledOrder],
    events: list[TradeEvent],
    warnings: list[str],
    order_results: list[OrderResult],
    *, observer: ExecutionObserver | None = None, run_id: str = "", sequence: list[int] | None = None,
) -> AccountState:
    """执行一批已排程订单：固定先卖后买（引擎不变量），逐单回报 OrderResult。"""
    sells = [item for item in scheduled if item.order.side is Side.SELL]
    buys = [item for item in scheduled if item.order.side is Side.BUY]
    ordered = (*sells, *buys)
    active = (
        {item.order.order_id: _active_order(item) for item in ordered if item.order.order_id is not None}
        if observer is not None else {}
    )

    seq = sequence if sequence is not None else [0]
    for item in ordered:
        _notify_observer(
            observer, run_id, seq, phase=ExecutionPhase.SUBMITTED, trading_date=item.execution_date,
            episode_id=item.order.episode_id, order_id=item.order.order_id,
            attempt_id=f"{item.order.order_id}:attempt:1", fill_id=None, trade=None,
            pre_state=state, post_state=state, cash_delta=0.0, active_orders=active,
        )
    for item in ordered:
        before = state
        event_start = len(events)
        state, outcome = _execute_order(context, state, item, events, warnings)
        order = item.order
        attempt_id = f"{order.order_id}:attempt:1" if order.order_id is not None else None
        fill_events = [e for e in events[event_start:] if e.status in (EventStatus.FILLED, EventStatus.FORCED_EXIT)]
        if order.order_id is not None:
            active.pop(order.order_id, None)
        if observer is not None and fill_events:
            trade = replace(fill_events[0], episode_id=order.episode_id, order_id=order.order_id,
                            fill_id=f"{attempt_id}:fill:1", sequence_no=seq[0] + 1)
            events[events.index(fill_events[0], event_start)] = trade
            _notify_observer(
                observer, run_id, seq, phase=ExecutionPhase.FILL, trading_date=item.execution_date,
                episode_id=order.episode_id, order_id=order.order_id, attempt_id=attempt_id,
                fill_id=trade.fill_id, trade=trade, pre_state=before, post_state=state,
                cash_delta=state.cash - before.cash, active_orders=active,
            )
        _notify_observer(
            observer, run_id, seq, phase=ExecutionPhase.TERMINAL, trading_date=item.execution_date,
            episode_id=order.episode_id, order_id=order.order_id, attempt_id=attempt_id,
            fill_id=None, trade=None, pre_state=state, post_state=state, cash_delta=0.0,
            active_orders=active, order_status=outcome.status.value,
            reason=outcome.reason.value if outcome.reason is not None else None,
        )
        result = _order_result(item.order, outcome)
        if observer is not None and attempt_id is not None:
            result = replace(result, attempt_id=attempt_id)
        order_results.append(result)
    return state


def _limit_order_reason(ticket: _OrderTicket, bar: MarketBar | None, fill_price: float | None) -> ReasonCode | None:
    if ticket.limit_price is None:
        return None
    if bar is None or bar.absolute_limit_down_price is None or bar.absolute_limit_up_price is None:
        return ReasonCode.LIMIT_BOUNDARY_UNKNOWN
    if fill_price is None:
        return None
    if not bar.absolute_limit_down_price <= fill_price <= bar.absolute_limit_up_price:
        return ReasonCode.ABSOLUTE_LIMIT_EXCEEDED
    if ticket.side is Side.BUY and fill_price > ticket.limit_price:
        return ReasonCode.LIMIT_PRICE_EXCEEDED
    if ticket.side is Side.SELL and fill_price < ticket.limit_price:
        return ReasonCode.LIMIT_PRICE_EXCEEDED
    return None


def _reject_limit_order(
    state: AccountState, ticket: _OrderTicket, execution_time: datetime, base_price: float | None,
    reason: ReasonCode, events: list[TradeEvent],
) -> tuple[AccountState, _ExecutionOutcome]:
    events.append(_flat_skip_event(ticket=ticket, execution_time=execution_time, base_price=base_price, reason=reason))
    return state, _ExecutionOutcome(OrderStatus.REJECTED, 0, None, 0.0, reason)


def _emit_no_next_day_orders(
    intents: Sequence[OrderIntent],
    signal_time: datetime,
    events: list[TradeEvent],
    warnings: list[str],
    order_results: list[OrderResult],
    *, state: AccountState, observer: ExecutionObserver | None, run_id: str, sequence: list[int],
) -> None:
    """尾日订单显式失败：逐单落 skipped(no_next_trading_day) + rejected 回报，禁止静默丢弃。"""
    execution_time = signal_time + _TAIL_EVENT_DELAY
    for order in intents:
        attempt_id = f"{order.order_id}:attempt:1" if order.order_id is not None else None
        event = _tail_skip_event(signal_time, execution_time, order.instrument_id, order.side)
        if observer is not None:
            event = replace(event, episode_id=order.episode_id, order_id=order.order_id, sequence_no=sequence[0] + 1)
        events.append(event)
        _notify_observer(
            observer, run_id, sequence, phase=ExecutionPhase.TERMINAL, trading_date=signal_time.date(),
            episode_id=order.episode_id, order_id=order.order_id, attempt_id=attempt_id,
            fill_id=None, trade=None, pre_state=state, post_state=state, cash_delta=0.0,
            active_orders={}, order_status=OrderStatus.REJECTED.value,
            reason=ReasonCode.NO_NEXT_TRADING_DAY.value,
        )
        result = _order_result(order, _ExecutionOutcome(
            OrderStatus.REJECTED, 0, None, 0.0, ReasonCode.NO_NEXT_TRADING_DAY
        ))
        order_results.append(replace(result, attempt_id=attempt_id) if observer is not None else result)
    warnings.append(
        f"account layer: {len(intents)} order(s) on {signal_time.date()} skipped: no next trading day "
        "(no signal-day price fallback)"
    )


def run_account_backtest(
    *,
    dates: Sequence[date],
    predictions_by_date: Mapping[date, Sequence[Prediction]],
    market: MarketDataProvider,
    execution_config: ExecutionConfig,
    portfolio_config: PortfolioConfig,
    cost_config: CostConfig | None = None,
    methodology: MetricMethodology | None = None,
    run_id: str,
    model_id: str,
    initial_capital: float | None = None,
) -> EvaluationResult:
    """account 层入口：逐日推进账户状态并按 final_liquidation 执行尾日清算，返回 EvaluationResult。

    account_metrics 由评估引擎按 methodology 补齐；methodology.final_mark_policy 取实际执行策略。

    .. deprecated:: 阶段 2（K03）
        预测驱动入口仅为 phase-1 兼容保留，不新增消费者；新代码请使用
        :func:`run_account_backtest_from_orders`（订单请求 → 引擎裁决 + 真实 T+1 锁定 +
        逐单 OrderResult 回报 + 逐日 AccountSnapshot）。本函数行为不变，也不发 runtime warning。
    """
    ordered_dates = _ensure_dates(dates)
    if not isinstance(execution_config, ExecutionConfig):
        raise ValueError(f"execution_config must be an ExecutionConfig, got {execution_config!r}")  # noqa: TRY004
    if not isinstance(portfolio_config, PortfolioConfig):
        raise ValueError(f"portfolio_config must be a PortfolioConfig, got {portfolio_config!r}")  # noqa: TRY004
    if cost_config is not None and not isinstance(cost_config, CostConfig):
        raise ValueError(f"cost_config must be a CostConfig or None, got {cost_config!r}")
    if methodology is not None and not isinstance(methodology, MetricMethodology):
        raise ValueError(f"methodology must be a MetricMethodology or None, got {methodology!r}")
    if not isinstance(predictions_by_date, Mapping):
        raise ValueError(  # noqa: TRY004
            f"predictions_by_date must be a mapping, got {predictions_by_date!r}"
        )
    resolved_cost = cost_config if cost_config is not None else CostConfig()
    resolved_methodology = methodology if methodology is not None else MetricMethodology()
    # 实际执行策略是口径单一事实源：final_mark_policy 一律覆盖，其余用户口径字段保留
    resolved_methodology = replace(
        resolved_methodology, final_mark_policy=to_final_mark_policy(execution_config.final_liquidation)
    )
    mode = ensure_enum_member(execution_config.execution_mode, ExecutionMode, "execution_mode")
    if initial_capital is None:
        capital = float(execution_config.initial_capital)
    else:
        ensure_finite(initial_capital, "initial_capital")
        if initial_capital <= 0.0:
            raise ValueError(f"initial_capital must be positive, got {initial_capital!r}")
        capital = float(initial_capital)
    signal_dates = list(predictions_by_date)
    for signal_date in signal_dates:
        ensure_calendar_date(signal_date, "predictions_by_date key")
    signal_dates.sort()

    context = _OrderContext(
        market=market,
        mode=mode,
        execution_config=execution_config,
        cost_config=resolved_cost,
        cost_model=AShareCostModel(resolved_cost),
        cost_config_resolver=None,
        slippage=SlippageV1(resolved_cost),
        lot_size=portfolio_config.lot_size,
        cash_reserve_ratio=portfolio_config.cash_reserve_ratio,
    )
    warnings: list[str] = []
    events: list[TradeEvent] = []
    scheduled: list[_ScheduledRebalance] = []
    failed: list[_Rebalance] = []
    frequency = portfolio_config.rebalance_frequency
    for index, signal_date in enumerate(signal_dates):
        if index % frequency != 0:
            continue
        raw_predictions = predictions_by_date[signal_date]
        if isinstance(raw_predictions, (str, bytes)) or not isinstance(raw_predictions, Sequence):
            raise ValueError(  # noqa: TRY004
                f"predictions_by_date[{signal_date!r}] must be a sequence of Prediction, got {raw_predictions!r}"
            )
        if len(raw_predictions) == 0:
            warnings.append(f"account layer: no predictions on {signal_date}; rebalance skipped")
            continue
        ranked, signal_time = _rank_targets(raw_predictions, signal_date)
        selected = ranked[: portfolio_config.top_n]
        keep = ranked[: portfolio_config.top_n + portfolio_config.sell_buffer]
        try:
            execution_date = resolve_execution_date(signal_date, mode, ordered_dates)
        except NoNextTradingDayError:
            failed.append(_Rebalance(signal_date, selected, keep, signal_time))
            continue
        scheduled.append(_ScheduledRebalance(signal_date, selected, keep, signal_time, execution_date))

    pending: dict[date, list[_ScheduledRebalance]] = {}
    failed_by_date: dict[date, list[_Rebalance]] = {}
    for batch in scheduled:
        pending.setdefault(batch.execution_date, []).append(batch)
    for batch in failed:
        failed_by_date.setdefault(batch.signal_date, []).append(batch)

    state = AccountState(cash=capital, available_cash=capital, positions={}, locked={}, cost={}, last_marks={})
    nav: list[float] = [capital]
    visited_failed: set[date] = set()
    last_trading_date = ordered_dates[-1] if ordered_dates else None
    for trading_date in ordered_dates:
        for batch in pending.get(trading_date, ()):
            state = _execute_rebalance(
                context,
                state,
                batch,
                events,
                warnings,
                block_new_positions=(
                    trading_date == last_trading_date
                    and context.execution_config.final_liquidation == "force"
                ),
            )
        for batch in failed_by_date.get(trading_date, ()):
            _emit_no_next_day(state, batch, events, warnings)
            visited_failed.add(batch.signal_date)
        if trading_date == last_trading_date:
            history_end = ordered_dates[-2] if len(ordered_dates) >= 2 else trading_date
            state = _liquidate_positions(context, state, trading_date, history_end, events, warnings)
        state, nav_value, _resolved_marks = _mark_day(state, market, trading_date, warnings)
        nav.append(nav_value)
    # 信号日不在交易日历内（如日历为空）：按最终状态显式补落事件，禁止静默丢弃
    for batch in failed:
        if batch.signal_date in visited_failed:
            continue
        _emit_no_next_day(state, batch, events, warnings)
        visited_failed.add(batch.signal_date)

    base_result = EvaluationResult(
        schema_version=SCHEMA_VERSION,
        engine_version=__version__,
        policy_version=POLICY_VERSION,
        run_id=run_id,
        model_id=model_id,
        signal_metrics={},
        paper_metrics={},
        account_metrics={},
        methodology=resolved_methodology,
        trades=tuple(events),
        warnings=tuple(warnings),
        skipped_counts=_skipped_counts(events),
        provenance={"layer": "account", "trades_location": _TRADES_LOCATION},
    )
    return DefaultEvaluationEngine().evaluate(base_result, resolved_methodology, nav=nav)


def run_account_backtest_from_orders(
    *,
    dates: Sequence[date] | None = None,
    execution_calendar: Sequence[date] | None = None,
    strategy: OrderStrategy,
    market: MarketDataProvider,
    execution_config: ExecutionConfig,
    portfolio_config: PortfolioConfig,
    cost_config: CostConfig | None = None,
    cost_config_resolver: Callable[[date, str], CostConfig] | None = None,
    account_actions_provider: Callable[[date], Sequence[CorporateActionOperation]] | None = None,
    signal_dates: Sequence[date] | None = None,
    maintenance_dates: Sequence[date] = (),
    evaluation_end: date | None = None,
    anchor_date: date | None = None,
    methodology: MetricMethodology | None = None,
    run_id: str,
    model_id: str,
    initial_capital: float | None = None,
    signal_time_of_day: time = time(15, 0),
    signal_timezone: tzinfo | None = None,
    observer: ExecutionObserver | None = None,
) -> EvaluationResult:
    """订单驱动账户入口（K03，主路径）：逐调仓日收盘回调策略，订单于执行日 open 裁决。

    语义：
    - 调仓日 = dates 中每 portfolio_config.rebalance_frequency 个交易日（与预测路径一致）；
    - 回调时点 = 调仓日收盘后（signal_time = trading_date + signal_time_of_day，默认 15:00
      Asia/Shanghai）；AccountView/MarketView 只读且按当日截止（end 超过交易日显式拒绝，防前视）；
    - 执行日 = resolve_execution_date（默认 T+1 open）；尾日无下一交易日的订单显式
      skipped + rejected(no_next_trading_day)，禁止回退信号日价格；
    - 同批订单固定先卖后买；买单 shares/cash_amount 二选一；容量截断 partial；
      现金不足/零手/不可交易整单 rejected；买入成交即 T+1 冻结，下一交易日开盘前解冻；
    - 尾日 final_liquidation（force/mark/skip）语义与预测路径完全复用；
    - 每个交易日收盘一条 AccountSnapshot，每笔策略订单一条 OrderResult。
    """
    if dates is None and execution_calendar is None:
        raise ValueError("dates or execution_calendar is required")
    if dates is not None and execution_calendar is not None and tuple(dates) != tuple(execution_calendar):
        raise ValueError("dates and execution_calendar cannot disagree")
    calendar_input = execution_calendar if execution_calendar is not None else dates
    if calendar_input is None:
        raise ValueError("execution_calendar is required")
    ordered_dates = _ensure_dates(calendar_input)
    if not ordered_dates:
        raise ValueError("execution_calendar must not be empty")
    last_execution_date = ordered_dates[-1]
    resolved_signals = ordered_dates if signal_dates is None else _ensure_dates(signal_dates)
    if not set(resolved_signals).issubset(ordered_dates):
        raise ValueError("signal_dates must be a subset of execution dates")
    resolved_maintenance = _ensure_dates(maintenance_dates) if maintenance_dates else ()
    if not set(resolved_maintenance).issubset(ordered_dates):
        raise ValueError("maintenance_dates must be a subset of execution dates")
    metric_end = ordered_dates[-1] if evaluation_end is None and ordered_dates else evaluation_end
    if metric_end is not None and metric_end not in ordered_dates:
        raise ValueError(f"evaluation_end must be in execution dates, got {metric_end!r}")
    if anchor_date is not None:
        ensure_calendar_date(anchor_date, "anchor_date")
        if ordered_dates[0] != anchor_date or not resolved_signals or resolved_signals[0] <= anchor_date:
            raise ValueError("anchor_date must be the first execution date before all signal dates")
    if not isinstance(strategy, OrderStrategy):
        raise ValueError(f"strategy must implement OrderStrategy.orders_for, got {strategy!r}")  # noqa: TRY004
    if observer is not None and not isinstance(observer, ExecutionObserver):
        raise ValueError(f"observer must implement ExecutionObserver.on_update, got {observer!r}")
    if not isinstance(execution_config, ExecutionConfig):
        raise ValueError(f"execution_config must be an ExecutionConfig, got {execution_config!r}")  # noqa: TRY004
    if not isinstance(portfolio_config, PortfolioConfig):
        raise ValueError(f"portfolio_config must be a PortfolioConfig, got {portfolio_config!r}")  # noqa: TRY004
    if cost_config is not None and not isinstance(cost_config, CostConfig):
        raise ValueError(f"cost_config must be a CostConfig or None, got {cost_config!r}")
    if cost_config_resolver is not None and not callable(cost_config_resolver):
        raise ValueError(f"cost_config_resolver must be callable or None, got {cost_config_resolver!r}")
    if account_actions_provider is not None and not callable(account_actions_provider):
        raise ValueError("account_actions_provider must be callable or None")
    if methodology is not None and not isinstance(methodology, MetricMethodology):
        raise ValueError(f"methodology must be a MetricMethodology or None, got {methodology!r}")
    if isinstance(signal_time_of_day, bool) or not isinstance(signal_time_of_day, time):
        raise ValueError(f"signal_time_of_day must be a time, got {signal_time_of_day!r}")  # noqa: TRY004
    resolved_timezone: tzinfo
    if signal_timezone is None:
        resolved_timezone = ZoneInfo("Asia/Shanghai")  # D3：三仓库统一 signal_time 时区
    elif isinstance(signal_timezone, tzinfo):
        resolved_timezone = signal_timezone
    else:
        raise ValueError(f"signal_timezone must be a tzinfo or None, got {signal_timezone!r}")
    resolved_cost = cost_config if cost_config is not None else CostConfig()
    resolved_methodology = methodology if methodology is not None else MetricMethodology()
    # 实际执行策略是口径单一事实源：final_mark_policy 一律覆盖，其余用户口径字段保留
    resolved_methodology = replace(
        resolved_methodology, final_mark_policy=to_final_mark_policy(execution_config.final_liquidation)
    )
    mode = ensure_enum_member(execution_config.execution_mode, ExecutionMode, "execution_mode")
    if mode is not ExecutionMode.T1_OPEN and signal_time_of_day >= _EXECUTION_CLOCK[mode]:
        # 同日模式需要盘中信号：signal_time 必须早于执行时钟，保证 execution_time > signal_time
        raise ValueError(
            f"{mode.value} requires an intraday signal_time_of_day earlier than "
            f"{_EXECUTION_CLOCK[mode].isoformat()}, got {signal_time_of_day.isoformat()!r}"
        )
    if initial_capital is None:
        capital = float(execution_config.initial_capital)
    else:
        ensure_finite(initial_capital, "initial_capital")
        if initial_capital <= 0.0:
            raise ValueError(f"initial_capital must be positive, got {initial_capital!r}")
        capital = float(initial_capital)
    context = _OrderContext(
        market=market,
        mode=mode,
        execution_config=execution_config,
        cost_config=resolved_cost,
        cost_model=AShareCostModel(resolved_cost),
        cost_config_resolver=cost_config_resolver,
        slippage=SlippageV1(resolved_cost),
        lot_size=portfolio_config.lot_size,
        cash_reserve_ratio=portfolio_config.cash_reserve_ratio,
    )
    market_state = MarketState(market)
    warnings: list[str] = []
    events: list[TradeEvent] = []
    order_results: list[OrderResult] = []
    snapshots: list[AccountSnapshot] = []
    pending: dict[date, list[_ScheduledOrder]] = {}
    observer_sequence = [0]
    seen_order_ids: set[str] = set()
    state = AccountState(cash=capital, available_cash=capital, positions={}, locked={}, cost={}, last_marks={})
    nav: list[float] = [capital]
    frequency = portfolio_config.rebalance_frequency
    signal_index = {day: index for index, day in enumerate(resolved_signals)}
    last_trading_date = ordered_dates[-1] if ordered_dates else None
    for index, trading_date in enumerate(ordered_dates):
        day_start_state = state
        day_actions = _checked_account_actions(account_actions_provider, trading_date)
        # T+1：新交易日开盘前释放上一交易日买入冻结（仅订单路径写入 locked）
        state = _unlock_due_locks(state)
        state = release_pending_cash(state)
        _validate_ex_date_action_marks(day_actions, state, market, trading_date)
        state = apply_account_actions(
            state,
            tuple(a for a in day_actions if isinstance(a, (CreateCashReceivable, CreateShareEntitlement))),
            trading_date,
        )
        _notify_observer(
            observer, run_id, observer_sequence, phase=ExecutionPhase.SNAPSHOT,
            trading_date=trading_date, episode_id=None, order_id=None, attempt_id=None,
            fill_id=None, trade=None, pre_state=day_start_state, post_state=state,
            cash_delta=state.cash - day_start_state.cash, active_orders=_active_pending(pending),
        )
        # 先执行此前排程到今日的订单（open 时点），再进入今日收盘信号，时间顺序不可倒置
        state = _execute_scheduled_orders(
            context, state, pending.pop(trading_date, ()), events, warnings, order_results,
            observer=observer, run_id=run_id, sequence=observer_sequence,
        )
        state = apply_account_actions(
            state, tuple(a for a in day_actions if isinstance(a, RecordPosition)), trading_date
        )
        call_strategy = (
            trading_date in signal_index and signal_index[trading_date] % frequency == 0
        ) or trading_date in resolved_maintenance
        if call_strategy:
            signal_time = datetime.combine(trading_date, signal_time_of_day, tzinfo=resolved_timezone)
            account_view = _build_account_view(state, market, trading_date)
            raw_orders = strategy.orders_for(
                trading_date=trading_date,
                signal_time=signal_time,
                account=account_view,
                market=_AsOfMarketView(market_state, trading_date),
            )
            intents = _checked_order_intents(raw_orders, trading_date)
            if observer is not None:
                intents = tuple(
                    replace(order, order_id=order.order_id or f"{run_id}:{trading_date.isoformat()}:{order_index}")
                    for order_index, order in enumerate(intents)
                )
                for order in intents:
                    if order.order_id in seen_order_ids:
                        raise ValueError(f"duplicate order_id {order.order_id!r}")
                    seen_order_ids.add(order.order_id or "")
            if intents:
                try:
                    execution_date = resolve_execution_date(trading_date, mode, ordered_dates)
                except NoNextTradingDayError:
                    _emit_no_next_day_orders(
                        intents, signal_time, events, warnings, order_results, state=state,
                        observer=observer, run_id=run_id, sequence=observer_sequence,
                    )
                else:
                    scheduled = tuple(
                        _ScheduledOrder(trading_date, signal_time, execution_date, order) for order in intents
                    )
                    if execution_date == trading_date:
                        # 同日模式：信号时点必须先于执行时钟（已在前置校验），当批立即执行
                        state = _execute_scheduled_orders(
                            context, state, scheduled, events, warnings, order_results,
                            observer=observer, run_id=run_id, sequence=observer_sequence,
                        )
                    else:
                        pending.setdefault(execution_date, []).extend(scheduled)
        if trading_date == last_trading_date:
            history_end = ordered_dates[-2] if len(ordered_dates) >= 2 else trading_date
            state = _liquidate_positions(
                context, state, trading_date, history_end, events, warnings,
                per_order_context=(
                    lambda execution_date, instrument_id: _cost_context(context, execution_date, instrument_id)
                ) if cost_config_resolver is not None else None,
                observer=observer, run_id=run_id, sequence=observer_sequence,
            )
        pre_close_actions_state = state
        state = apply_account_actions(
            state, tuple(a for a in day_actions if isinstance(a, (CashPayment, ListShareEntitlement))), trading_date
        )
        state, nav_value, resolved_marks = _mark_day(state, market, trading_date, warnings)
        nav.append(nav_value)
        snapshots.append(_account_snapshot(state, trading_date, nav_value, resolved_marks))
        _notify_observer(
            observer, run_id, observer_sequence, phase=ExecutionPhase.SNAPSHOT,
            trading_date=trading_date, episode_id=None, order_id=None, attempt_id=None,
            fill_id=None, trade=None, pre_state=pre_close_actions_state, post_state=state,
            cash_delta=state.cash - pre_close_actions_state.cash, active_orders=_active_pending(pending),
        )
    base_result = EvaluationResult(
        schema_version=SCHEMA_VERSION,
        engine_version=__version__,
        policy_version=POLICY_VERSION,
        run_id=run_id,
        model_id=model_id,
        signal_metrics={},
        paper_metrics={},
        account_metrics={},
        methodology=resolved_methodology,
        trades=tuple(events),
        warnings=tuple(warnings),
        skipped_counts=_skipped_counts(events),
        provenance={"layer": "account", "trades_location": _TRADES_LOCATION},
        account_snapshots=tuple(snapshots),
        order_results=tuple(order_results),
    )
    metric_nav = nav
    if metric_end is not None and (metric_end != last_execution_date or anchor_date is not None):
        metric_nav = [capital, *(
            snapshot.nav for snapshot in snapshots
            if snapshot.date <= metric_end and (anchor_date is None or snapshot.date > anchor_date)
        )]
    return DefaultEvaluationEngine().evaluate(
        base_result, resolved_methodology, nav=metric_nav, trade_end=metric_end,
    )
