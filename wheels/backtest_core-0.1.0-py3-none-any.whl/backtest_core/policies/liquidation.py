"""尾日清算策略（规格 §10 ExecutionPolicy.final_liquidation，访谈 Q2）：三态显式、无隐式回退。"""

from collections.abc import Mapping
from dataclasses import dataclass
from typing import cast

from ..contracts.policy import FinalLiquidation
from ..contracts.result import FinalMarkPolicy
from ..contracts.validation import ensure_finite, ensure_non_empty_str

__all__ = [
    "LiquidationIntent",
    "LiquidationPlan",
    "resolve_liquidation_plan",
    "to_final_mark_policy",
]

_LIQUIDATION_VALUES: tuple[FinalLiquidation, ...] = ("skip", "mark", "force")
_MARK_POLICY_BY_LIQUIDATION: dict[str, FinalMarkPolicy] = {
    "force": "liquidation",
    "mark": "last_close",
    "skip": "exclude",
}


def _ensure_final_liquidation(value: str) -> FinalLiquidation:
    if value not in _LIQUIDATION_VALUES:
        allowed = ", ".join(repr(item) for item in _LIQUIDATION_VALUES)
        raise ValueError(f"final_liquidation must be one of ({allowed}), got {value!r}")
    return cast("FinalLiquidation", value)


def to_final_mark_policy(final_liquidation: str) -> FinalMarkPolicy:
    """清算策略 → 指标口径（规格 §13）：映射是唯一入口，防止两处随版本漂移。"""
    return _MARK_POLICY_BY_LIQUIDATION[_ensure_final_liquidation(final_liquidation)]


@dataclass(frozen=True)
class LiquidationIntent:
    """尾日强制卖出意图：T12 按可交易性执行，产出 forced_exit/locked/skipped 事件。"""

    instrument_id: str
    target_shares: float

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_finite(self.target_shares, "target_shares")
        if self.target_shares <= 0:
            raise ValueError(f"target_shares must be positive, got {self.target_shares!r}")
        object.__setattr__(self, "target_shares", float(self.target_shares))


@dataclass(frozen=True)
class LiquidationPlan:
    """force 生成卖出意图；mark 仅要求按最后收盘价估值；skip 交由指标口径 exclude。"""

    final_liquidation: FinalLiquidation
    final_mark_policy: FinalMarkPolicy
    sell_intents: tuple[LiquidationIntent, ...]
    mark_at_last_close: bool

    def __post_init__(self) -> None:
        resolved = _ensure_final_liquidation(self.final_liquidation)
        if not isinstance(self.mark_at_last_close, bool):
            raise ValueError(f"mark_at_last_close must be a bool, got {self.mark_at_last_close!r}")  # noqa: TRY004
        if self.final_mark_policy != to_final_mark_policy(resolved):
            raise ValueError(
                "final_mark_policy must match to_final_mark_policy(final_liquidation), "
                f"got {self.final_mark_policy!r} for {resolved!r}"
            )
        intents = tuple(self.sell_intents)
        for intent in intents:
            if not isinstance(intent, LiquidationIntent):
                raise ValueError(f"sell_intents items must be LiquidationIntent, got {intent!r}")  # noqa: TRY004
        if resolved != "force" and intents:
            raise ValueError("sell_intents are only valid for final_liquidation='force'")
        if self.mark_at_last_close != (resolved == "mark"):
            raise ValueError("mark_at_last_close must be True iff final_liquidation='mark'")
        object.__setattr__(self, "sell_intents", intents)


def resolve_liquidation_plan(
    final_liquidation: str,
    positions: Mapping[str, float],
) -> LiquidationPlan:
    """纯函数计划：mark/skip 与持仓值无关；force 只为非零多头生成按代码排序的卖出意图。"""
    resolved = _ensure_final_liquidation(final_liquidation)
    if not isinstance(positions, Mapping):
        raise ValueError(f"positions must be a mapping, got {positions!r}")  # noqa: TRY004
    intents: list[LiquidationIntent] = []
    if resolved == "force":
        for instrument_id in positions:
            ensure_non_empty_str(instrument_id, "positions key")
        for instrument_id in sorted(positions):
            shares = positions[instrument_id]
            ensure_finite(shares, f"positions[{instrument_id!r}]")
            if shares < 0:
                raise ValueError(f"positions[{instrument_id!r}] must be non-negative, got {shares!r}")
            if shares == 0:
                continue
            intents.append(LiquidationIntent(instrument_id=instrument_id, target_shares=shares))
    return LiquidationPlan(
        final_liquidation=resolved,
        final_mark_policy=to_final_mark_policy(resolved),
        sell_intents=tuple(intents),
        mark_at_last_close=resolved == "mark",
    )
