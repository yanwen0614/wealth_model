"""σ 缩放滑点 v1（规格 §11.4，依据 SLIPPAGE_RESEARCH §6 裁决）：纯函数、确定性、可版本化。"""

import math
from collections.abc import Sequence
from itertools import pairwise

from ..contracts.config import CostConfig
from ..contracts.enums import ReasonCode, Side
from ..contracts.market import MarketBar
from ..contracts.slippage import LiquidityStats, SlippageDecision, SlippageResult
from ..contracts.validation import ensure_enum_member, ensure_finite, ensure_non_negative_finite

__all__ = ["POLICY_VERSION", "SlippageV1", "compute_liquidity_stats"]

POLICY_VERSION = "v1"
_TICK = 0.01


def compute_liquidity_stats(
    bars: Sequence[MarketBar],
    *,
    adv_window: int = 20,
    sigma_window: int = 20,
    sigma_clip: tuple[float, float] = (0.005, 0.08),
) -> LiquidityStats | None:
    """从 ≤T 的历史 bars 计算 ADV20 与 clip 后的 σ20；样本不足返回 None 由调用方降级。

    只使用传入 bars（调用方保证已按 ≤T 截断）；缺失 amount/close 的交易日剔除而非填充，
    有效样本不足窗口即返回 None，禁止偷偷改用固定费率兜底（规格 §11.4）。
    """
    if adv_window < 1:
        raise ValueError(f"adv_window must be >= 1, got {adv_window!r}")
    if sigma_window < 2:
        # ddof=1 需要至少 2 个收益样本
        raise ValueError(f"sigma_window must be >= 2, got {sigma_window!r}")
    low, high = sigma_clip
    if not 0.0 < low < high:
        raise ValueError(f"sigma_clip must satisfy 0 < low < high, got {sigma_clip!r}")

    dates = [bar.trading_date for bar in bars]
    if dates != sorted(dates):
        raise ValueError("bars must be ordered by ascending trading_date")

    amounts: list[float] = []
    closes: list[float] = []
    for bar in bars:
        if bar.amount is not None:
            amounts.append(bar.amount)
        if bar.close is not None and bar.close > 0:
            closes.append(bar.close)

    if len(amounts) < adv_window:
        return None
    adv20 = math.fsum(amounts[-adv_window:]) / adv_window

    returns = [math.log(current / previous) for previous, current in pairwise(closes)]
    if len(returns) < sigma_window:
        return None
    window = returns[-sigma_window:]
    mean = math.fsum(window) / sigma_window
    variance = math.fsum((value - mean) ** 2 for value in window) / (sigma_window - 1)
    sigma20 = min(max(math.sqrt(variance), low), high)
    return LiquidityStats(adv20=adv20, sigma20=sigma20)


class SlippageV1:
    """σ 缩放平方根冲击 + 半价差底 + 参与率上限 + 方向性 tick 取整（公式见规格 §11.4）。"""

    version: str = POLICY_VERSION

    def __init__(self, config: CostConfig | None = None) -> None:
        self._config = config if config is not None else CostConfig()

    def compute(
        self,
        side: Side | str,
        order_amount: float,
        base_price: float,
        adv20: float,
        sigma20: float,
    ) -> SlippageResult:
        """stats 齐备路径（规格 §10 SlippageModel）；缺量/短历史请走 decide 降级分支。"""
        resolved_side = self._validate_order(side, order_amount, base_price)
        ensure_finite(adv20, "adv20")
        if adv20 <= 0:
            raise ValueError(f"adv20 must be positive, got {adv20!r}")
        ensure_finite(sigma20, "sigma20")
        if sigma20 < 0:
            raise ValueError(f"sigma20 must be non-negative, got {sigma20!r}")

        p_raw = order_amount / adv20
        p_capped = min(p_raw, self._config.p_cap)
        impact_rate = self._impact_rate(p_capped, sigma20)
        spread_rate = self._spread_rate(base_price)
        slip_rate = min(impact_rate + spread_rate, self._config.slip_max)
        return SlippageResult(
            participation_raw=p_raw,
            participation_capped=p_capped,
            impact_rate=impact_rate,
            spread_rate=spread_rate,
            slip_rate=slip_rate,
            fill_price=self._fill_price(base_price, slip_rate, resolved_side),
            capacity_exceeded=p_raw > self._config.p_cap,
        )

    def decide(
        self,
        side: Side | str,
        order_amount: float,
        base_price: float,
        adv20: float | None = None,
        sigma20: float | None = None,
    ) -> SlippageDecision:
        """缺量/短历史降级入口：按 missing_volume_policy 返回 warn（spread-only）或 skip。"""
        resolved_side = self._validate_order(side, order_amount, base_price)
        if adv20 is not None:
            ensure_finite(adv20, "adv20")
        if sigma20 is not None:
            ensure_finite(sigma20, "sigma20")
        if adv20 is not None and adv20 > 0 and sigma20 is not None:
            result = self.compute(resolved_side, order_amount, base_price, adv20, sigma20)
            return SlippageDecision(
                result=result,
                participation=result.participation_capped,
                skip_reason=None,
                warnings=(),
            )
        if adv20 is None or adv20 <= 0:
            reason = ReasonCode.MISSING_VOLUME
        else:
            reason = ReasonCode.SHORT_HISTORY
        if self._config.missing_volume_policy == "skip":
            return SlippageDecision(result=None, participation=None, skip_reason=reason, warnings=())
        # warn：无 ADV 则参与率/冲击不可定义，仅计半价差继续成交；事件层 participation=None
        spread_rate = self._spread_rate(base_price)
        slip_rate = min(spread_rate, self._config.slip_max)
        result = SlippageResult(
            participation_raw=0.0,
            participation_capped=0.0,
            impact_rate=0.0,
            spread_rate=spread_rate,
            slip_rate=slip_rate,
            fill_price=self._fill_price(base_price, slip_rate, resolved_side),
            capacity_exceeded=False,
        )
        warning = f"{reason.value}: history window incomplete; spread-only fill per missing_volume_policy='warn'"
        return SlippageDecision(result=result, participation=None, skip_reason=None, warnings=(warning,))

    def _validate_order(self, side: Side | str, order_amount: float, base_price: float) -> Side:
        resolved_side = ensure_enum_member(side, Side, "side")
        ensure_non_negative_finite(order_amount, "order_amount")
        ensure_finite(base_price, "base_price")
        if base_price <= 0:
            raise ValueError(f"base_price must be positive, got {base_price!r}")
        return resolved_side

    def _impact_rate(self, participation: float, sigma20: float) -> float:
        # 再次 clip：调用方可能绕过 compute_liquidity_stats 直接传原始日波动率
        low, high = self._config.sigma_clip
        clipped = min(max(sigma20, low), high)
        return self._config.impact_coefficient * clipped * math.sqrt(participation)

    def _spread_rate(self, base_price: float) -> float:
        return max(0.5 * _TICK / base_price, self._config.spread_floor)

    def _fill_price(self, base_price: float, slip_rate: float, side: Side) -> float:
        """买上卖下取整到 tick；先归一到最近刻度，避免 10.02/0.01=1001.999… 多跳一档。"""
        direction = 1.0 + slip_rate if side is Side.BUY else 1.0 - slip_rate
        scaled = round(base_price * direction / _TICK, 9)
        ticks = math.ceil(scaled) if side is Side.BUY else math.floor(scaled)
        return ticks * _TICK
