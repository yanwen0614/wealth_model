"""A 股成本策略（规格 §11.4，Key Decision 2）：佣金万 2 最低 5 元、卖出印花税万 5、过户费默认 0。"""

from ..contracts.config import CostConfig
from ..contracts.enums import Side
from ..contracts.validation import ensure_enum_member, ensure_non_negative_finite

__all__ = ["AShareCostModel"]


class AShareCostModel:
    """纯函数成本模型：同一输入恒定输出，费率来自 CostConfig（缺省即 T04 冻结默认值）。"""

    def __init__(self, config: CostConfig | None = None) -> None:
        self._config = config if config is not None else CostConfig()

    def calculate(self, side: Side | str, amount: float) -> tuple[float, float, float]:
        """返回 (commission, stamp_tax, transfer_fee)；stamp_tax 仅卖出计提。

        佣金按边取费率：拆分字段 commission_rate_buy/sell 为空时回退 commission_rate。
        """
        resolved_side = ensure_enum_member(side, Side, "side")
        ensure_non_negative_finite(amount, "amount")
        rate = self._config.commission_rate
        if resolved_side is Side.BUY and self._config.commission_rate_buy is not None:
            rate = self._config.commission_rate_buy
        elif resolved_side is Side.SELL and self._config.commission_rate_sell is not None:
            rate = self._config.commission_rate_sell
        commission = max(amount * rate, self._config.min_commission)
        stamp_tax = amount * self._config.stamp_tax_rate if resolved_side is Side.SELL else 0.0
        transfer_fee = amount * self._config.transfer_fee_rate
        return float(commission), float(stamp_tax), float(transfer_fee)
