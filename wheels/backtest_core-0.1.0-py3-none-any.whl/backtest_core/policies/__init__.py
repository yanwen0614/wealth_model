"""策略层公共 API（规格 §9）：成本/滑点/执行时点/可交易性/清算纯策略，版本号随 POLICY_VERSION 进入结果溯源。"""

from .cost import AShareCostModel
from .execution import (
    NoNextTradingDayError,
    execution_price,
    resolve_execution_date,
    validate_no_lookahead,
)
from .liquidation import LiquidationIntent, LiquidationPlan, resolve_liquidation_plan, to_final_mark_policy
from .slippage import POLICY_VERSION, SlippageV1, compute_liquidity_stats
from .tradability import TradabilityDecision, decide_tradability

__all__ = [
    "POLICY_VERSION",
    "AShareCostModel",
    "LiquidationIntent",
    "LiquidationPlan",
    "NoNextTradingDayError",
    "SlippageV1",
    "TradabilityDecision",
    "compute_liquidity_stats",
    "decide_tradability",
    "execution_price",
    "resolve_execution_date",
    "resolve_liquidation_plan",
    "to_final_mark_policy",
    "validate_no_lookahead",
]
