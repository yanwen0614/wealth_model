# policies - 策略层

纯函数策略层，依赖方向 `→ contracts` 单向。版本号 `POLICY_VERSION` 进入结果溯源。

## 关键约束

- **无前视**：`resolve_execution_date` 返回严格晚于信号日的交易日；尾日无下一交易日抛 `NoNextTradingDayError`（不得回退信号日价格）。
- `execution_price` 需传入 `execution_mode` 选择价格字段。
- `compute_liquidity_stats` 的统计窗口截至信号日 T（不含 T 本身），短历史降级。
- `AShareCostModel`：佣金万 2 最低 5 元，卖出万 5 印花税，过户费默认 0。修改公式必须 bump `POLICY_VERSION`。
- `SlippageV1`：σ 缩放 v1（`p_cap=0.10`, `slip_max=5%`）。两个版本号独立。
- `decide_tradability` 可交易性优先级：停牌 > 涨跌停 > 缺价（禁止重新排序，与 README 默认口径一致）。

## 不变量

- 同输入同参数两次调用返回逐字段一致结果。
- 所有输入校验通过 `contracts.validation`，非法输入抛 `ValueError`（禁止静默兜底）。
