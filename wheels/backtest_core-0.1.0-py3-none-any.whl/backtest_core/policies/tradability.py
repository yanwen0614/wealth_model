"""可交易性判定（规格 §11.2）：数据标志 + 配置策略 → 方向性 can_buy/can_sell 与原因码。

阻止优先级：停牌 > 涨跌停 > 缺价（首个命中决定 status，全部命中进入 reasons）；
缺量/无效量只入 reasons 不拦截，由滑点层按 missing_volume_policy 降级（规格 §11.4）。
"""

from dataclasses import dataclass

from ..contracts.config import ExecutionConfig, TradabilityBehavior
from ..contracts.enums import EventStatus, ExecutionMode, ReasonCode
from ..contracts.market import MarketBar, tradability_reasons
from ..contracts.validation import ensure_enum_member

__all__ = ["TradabilityDecision", "decide_tradability"]


@dataclass(frozen=True)
class TradabilityDecision:
    """单 bar 方向性决策：status=filled 表示允许进入执行层，不等于最终成交。"""

    can_buy: bool
    can_sell: bool
    buy_status: EventStatus
    sell_status: EventStatus
    reasons: frozenset[ReasonCode]

    def __post_init__(self) -> None:
        for field_name in ("can_buy", "can_sell"):
            value = getattr(self, field_name)
            if not isinstance(value, bool):
                raise ValueError(f"{field_name} must be a bool, got {value!r}")  # noqa: TRY004
        object.__setattr__(self, "buy_status", ensure_enum_member(self.buy_status, EventStatus, "buy_status"))
        object.__setattr__(self, "sell_status", ensure_enum_member(self.sell_status, EventStatus, "sell_status"))
        object.__setattr__(self, "reasons", frozenset(self.reasons))
        for reason in self.reasons:
            if not isinstance(reason, ReasonCode):
                raise ValueError(f"reasons items must be ReasonCode, got {reason!r}")  # noqa: TRY004
        self._check_direction(self.can_buy, self.buy_status, "buy")
        self._check_direction(self.can_sell, self.sell_status, "sell")

    @staticmethod
    def _check_direction(can_trade: bool, status: EventStatus, direction: str) -> None:
        if can_trade and status is not EventStatus.FILLED:
            raise ValueError(f"can_{direction}=True requires {direction}_status=filled, got {status.value!r}")
        if not can_trade and status not in (EventStatus.SKIPPED, EventStatus.LOCKED):
            raise ValueError(
                f"can_{direction}=False requires {direction}_status in (skipped, locked), got {status.value!r}"
            )


def _mode_price_missing(bar: MarketBar, mode: ExecutionMode) -> bool:
    if mode is ExecutionMode.T1_OPEN:
        return bar.open is None
    if mode is ExecutionMode.SAME_DAY_CLOSE:
        return bar.close is None
    return bar.high is None or bar.low is None


def _blocked_status(policy: TradabilityBehavior) -> EventStatus:
    return EventStatus.SKIPPED if policy == "skip" else EventStatus.LOCKED


def decide_tradability(
    bar: MarketBar,
    mode: ExecutionMode | str,
    execution_config: ExecutionConfig,
) -> TradabilityDecision:
    """单 bar 方向性判定；调用方先用 resolve_execution_date 解析执行日再调用本函数。"""
    if not isinstance(bar, MarketBar):
        raise ValueError(f"bar must be a MarketBar, got {bar!r}")  # noqa: TRY004
    if not isinstance(execution_config, ExecutionConfig):
        raise ValueError(f"execution_config must be an ExecutionConfig, got {execution_config!r}")  # noqa: TRY004
    resolved_mode = ensure_enum_member(mode, ExecutionMode, "mode")
    price_missing = _mode_price_missing(bar, resolved_mode)
    # 缺价按模式所需字段判定：非所需 OHLC 缺失不得阻止本模式执行
    reasons = {reason for reason in tradability_reasons(bar) if reason is not ReasonCode.MISSING_PRICE}
    if price_missing:
        reasons.add(ReasonCode.MISSING_PRICE)

    execution_state_unknown = (
        not bar.market_state_known
        or not bar.st_state_known
        or not bar.limit_state_known
        or (bar.corporate_action_reference_required and not bar.reference_known)
    )
    if execution_state_unknown:
        status = _blocked_status(execution_config.missing_price_policy)
        return TradabilityDecision(False, False, status, status, frozenset(reasons))

    if not bar.is_trading:
        status = _blocked_status(execution_config.suspension_policy)
        return TradabilityDecision(False, False, status, status, frozenset(reasons))

    buy_status = EventStatus.FILLED
    sell_status = EventStatus.FILLED
    if bar.limit_up:
        buy_status = _blocked_status(execution_config.limit_up_policy)
    if bar.limit_down:
        sell_status = _blocked_status(execution_config.limit_down_policy)
    if price_missing:
        # 已有方向性阻止时保留更具体的市场状态原因，缺价只补充另一方向
        if buy_status is EventStatus.FILLED:
            buy_status = _blocked_status(execution_config.missing_price_policy)
        if sell_status is EventStatus.FILLED:
            sell_status = _blocked_status(execution_config.missing_price_policy)
    return TradabilityDecision(
        can_buy=buy_status is EventStatus.FILLED,
        can_sell=sell_status is EventStatus.FILLED,
        buy_status=buy_status,
        sell_status=sell_status,
        reasons=frozenset(reasons),
    )
