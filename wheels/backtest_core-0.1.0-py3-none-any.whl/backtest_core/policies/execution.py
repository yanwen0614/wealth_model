"""执行时点解析（规格 §10，访谈 Q2）：signal_time ≠ execution_time，默认 T+1 open 防前视。

尾日无下一交易日必须由 final_liquidation 显式处理；本模块禁止任何隐式回退（如改用 signal_date 的 open）。
"""

from bisect import bisect_left, bisect_right
from collections.abc import Sequence
from datetime import date, datetime
from itertools import pairwise

from ..contracts.enums import ExecutionMode
from ..contracts.market import MarketBar
from ..contracts.validation import ensure_calendar_date, ensure_enum_member, ensure_tz_aware

__all__ = [
    "NoNextTradingDayError",
    "execution_price",
    "resolve_execution_date",
    "validate_no_lookahead",
]


class NoNextTradingDayError(ValueError):
    """signal 落在交易日历末尾：尾日语义由 final_liquidation 决定，不得隐式回退到信号日。"""


def _validated_calendar(trading_dates: Sequence[date]) -> list[date]:
    if isinstance(trading_dates, (str, bytes)) or not isinstance(trading_dates, Sequence):
        raise ValueError(f"trading_dates must be a sequence of date, got {trading_dates!r}")  # noqa: TRY004
    dates = list(trading_dates)
    if not dates:
        raise ValueError("trading_dates must not be empty")
    for value in dates:
        ensure_calendar_date(value, "trading_dates item")
    for previous, current in pairwise(dates):
        if current <= previous:
            raise ValueError("trading_dates must be strictly ascending")
    return dates


def resolve_execution_date(
    signal_date: date,
    mode: ExecutionMode | str,
    trading_dates: Sequence[date],
) -> date:
    """信号日 → 执行日；t1_open 恰逢 T+1 停牌仍返回该交易日，由 decide_tradability 显式处理。"""
    ensure_calendar_date(signal_date, "signal_date")
    resolved_mode = ensure_enum_member(mode, ExecutionMode, "mode")
    dates = _validated_calendar(trading_dates)
    if resolved_mode is ExecutionMode.T1_OPEN:
        index = bisect_right(dates, signal_date)
        if index == len(dates):
            raise NoNextTradingDayError(
                f"no trading day strictly after signal_date {signal_date!r}; "
                "explicit final_liquidation policy required (no implicit fallback)"
            )
        return dates[index]
    index = bisect_left(dates, signal_date)
    if index == len(dates) or dates[index] != signal_date:
        raise ValueError(f"signal_date {signal_date!r} must be a trading day for mode {resolved_mode.value!r}")
    return signal_date


def execution_price(bar: MarketBar, mode: ExecutionMode | str) -> float | None:
    """按模式取价：无所需字段返回 None，禁止跨字段回退（规格 §11.2）。"""
    if not isinstance(bar, MarketBar):
        raise ValueError(f"bar must be a MarketBar, got {bar!r}")  # noqa: TRY004
    resolved_mode = ensure_enum_member(mode, ExecutionMode, "mode")
    if resolved_mode is ExecutionMode.T1_OPEN:
        return bar.open
    if resolved_mode is ExecutionMode.SAME_DAY_CLOSE:
        return bar.close
    if bar.high is None or bar.low is None:
        return None
    return (bar.high + bar.low) / 2


def validate_no_lookahead(
    signal_time: datetime,
    execution_time: datetime,
    mode: ExecutionMode | str,
) -> None:
    """前视防线：t1_open 必须严格晚于信号时间；同日模式须调用方显式选择且不得早于信号。"""
    ensure_tz_aware(signal_time, "signal_time")
    ensure_tz_aware(execution_time, "execution_time")
    resolved_mode = ensure_enum_member(mode, ExecutionMode, "mode")
    if resolved_mode is ExecutionMode.T1_OPEN:
        if execution_time <= signal_time:
            raise ValueError(f"t1_open requires execution_time > signal_time, got {execution_time!r} <= {signal_time!r}")
        return
    if execution_time < signal_time:
        raise ValueError(
            f"{resolved_mode.value} requires execution_time >= signal_time, got {execution_time!r} < {signal_time!r}"
        )
