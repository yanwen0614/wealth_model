"""公司行动的逐阶段操作契约；每个操作 ID 表示唯一账本阶段。"""

from dataclasses import dataclass
from datetime import date

from .validation import ensure_calendar_date, ensure_finite, ensure_non_empty_str


def _operation(operation_id: str, event_id: str, effective_date: date) -> None:
    ensure_non_empty_str(operation_id, "operation_id")
    ensure_non_empty_str(event_id, "event_id")
    ensure_calendar_date(effective_date, "effective_date")


@dataclass(frozen=True)
class RecordPosition:
    operation_id: str
    event_id: str
    instrument_id: str
    effective_date: date

    def __post_init__(self) -> None:
        _operation(self.operation_id, self.event_id, self.effective_date)
        ensure_non_empty_str(self.instrument_id, "instrument_id")


@dataclass(frozen=True)
class CreateCashReceivable:
    operation_id: str
    event_id: str
    instrument_id: str
    record_operation_id: str
    cash_per_share: float
    effective_date: date
    pay_date: date

    def __post_init__(self) -> None:
        _operation(self.operation_id, self.event_id, self.effective_date)
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_non_empty_str(self.record_operation_id, "record_operation_id")
        ensure_finite(self.cash_per_share, "cash_per_share")
        ensure_calendar_date(self.pay_date, "pay_date")
        if self.cash_per_share < 0 or self.pay_date < self.effective_date:
            raise ValueError("cash_per_share must be non-negative and pay_date >= effective_date")


@dataclass(frozen=True)
class CashPayment:
    operation_id: str
    event_id: str
    effective_date: date

    def __post_init__(self) -> None:
        _operation(self.operation_id, self.event_id, self.effective_date)


@dataclass(frozen=True)
class CreateShareEntitlement:
    operation_id: str
    event_id: str
    instrument_id: str
    record_operation_id: str
    shares_per_share: float
    effective_date: date
    listing_date: date

    def __post_init__(self) -> None:
        _operation(self.operation_id, self.event_id, self.effective_date)
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_non_empty_str(self.record_operation_id, "record_operation_id")
        ensure_finite(self.shares_per_share, "shares_per_share")
        ensure_calendar_date(self.listing_date, "listing_date")
        if self.shares_per_share < 0 or self.listing_date < self.effective_date:
            raise ValueError("shares_per_share must be non-negative and listing_date >= effective_date")


@dataclass(frozen=True)
class ListShareEntitlement:
    operation_id: str
    event_id: str
    effective_date: date

    def __post_init__(self) -> None:
        _operation(self.operation_id, self.event_id, self.effective_date)


CorporateActionOperation = (
    RecordPosition | CreateCashReceivable | CashPayment | CreateShareEntitlement | ListShareEntitlement
)


@dataclass(frozen=True)
class CashReceivable:
    event_id: str
    instrument_id: str
    amount: float
    pay_date: date

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.event_id, "event_id")
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_finite(self.amount, "amount")
        ensure_calendar_date(self.pay_date, "pay_date")
        if self.amount < 0:
            raise ValueError(f"amount must be non-negative, got {self.amount!r}")


@dataclass(frozen=True)
class ShareEntitlement:
    event_id: str
    instrument_id: str
    shares: float
    listing_date: date
    cost_basis_total: float = 0.0

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.event_id, "event_id")
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_finite(self.shares, "shares")
        ensure_finite(self.cost_basis_total, "cost_basis_total")
        ensure_calendar_date(self.listing_date, "listing_date")
        if self.shares < 0 or self.cost_basis_total < 0:
            raise ValueError("shares and cost_basis_total must be non-negative")
