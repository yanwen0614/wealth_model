"""账户状态契约（规格 §11.3/K02）：不可变快照，外部映射突变被隔离在构造期之外。"""

import math
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import date
from types import MappingProxyType

from .account_actions import CashReceivable, ShareEntitlement
from .validation import ensure_calendar_date, ensure_finite, ensure_non_empty_str, ensure_non_negative_finite

__all__ = ["AccountSnapshot", "AccountState", "PositionSnapshot"]


@dataclass(frozen=True)
class UnlistedEntitlementSnapshot:
    event_id: str
    instrument_id: str
    shares: float
    price: float
    market_value: float

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.event_id, "event_id")
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_non_negative_finite(self.shares, "shares")
        ensure_finite(self.price, "price")
        ensure_non_negative_finite(self.market_value, "market_value")
        if self.price <= 0 or not math.isclose(self.market_value, self.shares * self.price, rel_tol=1e-9, abs_tol=1e-6):
            raise ValueError("unlisted entitlement market_value must equal shares * positive price")


def _freeze_mapping(
    values: Mapping[str, float],
    field_name: str,
    check: Callable[[str, float], None],
) -> Mapping[str, float]:
    """复制为只读映射：外部修改原 dict 或经属性写回都不影响契约快照。"""
    if not isinstance(values, Mapping):
        raise ValueError(f"{field_name} must be a mapping, got {values!r}")  # noqa: TRY004
    frozen: dict[str, float] = {}
    for key, value in values.items():
        ensure_non_empty_str(key, f"{field_name} key")
        check(key, value)
        frozen[key] = float(value)
    return MappingProxyType(frozen)


def _freeze_action_mapping(values: Mapping[str, object], field_name: str, expected_type: type) -> Mapping[str, object]:
    if not isinstance(values, Mapping):
        raise ValueError(f"{field_name} must be a mapping, got {values!r}")  # noqa: TRY004
    frozen: dict[str, object] = {}
    for key, value in values.items():
        ensure_non_empty_str(key, f"{field_name} key")
        if not isinstance(value, expected_type):
            raise ValueError(f"{field_name}[{key!r}] must be {expected_type.__name__}, got {value!r}")  # noqa: TRY004
        frozen[key] = value
    return MappingProxyType(frozen)


def _quantity_check(field_name: str, fractional: bool) -> Callable[[str, float], None]:
    """数量校验闭包：fractional=False 时数量必须是整股（100.0 视为整股）。"""

    def check(key: str, value: float) -> None:
        location = f"{field_name}[{key!r}]"
        ensure_non_negative_finite(value, location)
        if not fractional and not float(value).is_integer():
            raise ValueError(f"{location} must be an integer quantity when fractional=False, got {value!r}")

    return check


def _cost_check(field_name: str) -> Callable[[str, float], None]:
    """成本校验闭包：移动加权成本不允许为负。"""

    def check(key: str, value: float) -> None:
        ensure_non_negative_finite(value, f"{field_name}[{key!r}]")

    return check


def _mark_check(field_name: str) -> Callable[[str, float], None]:
    """估值校验闭包：最新估值必须是正价格，缺估值应省略键而非填 0。"""

    def check(key: str, value: float) -> None:
        location = f"{field_name}[{key!r}]"
        ensure_finite(value, location)
        if value <= 0:
            raise ValueError(f"{location} must be positive, got {value!r}")

    return check


@dataclass(frozen=True)
class AccountState:
    """账户状态快照：现金/持仓/锁定/成本/最新估值；paper 模式经 fractional=True 显式开启。"""

    cash: float
    available_cash: float
    positions: Mapping[str, float]
    locked: Mapping[str, float]
    cost: Mapping[str, float]
    last_marks: Mapping[str, float]
    fractional: bool = False
    processed_action_operations: tuple[str, ...] = ()
    record_positions: Mapping[str, float] = field(default_factory=dict)
    record_costs: Mapping[str, float] = field(default_factory=dict)
    cash_receivables: Mapping[str, CashReceivable] = field(default_factory=dict)
    unlisted_entitlements: Mapping[str, ShareEntitlement] = field(default_factory=dict)
    pending_cash: Mapping[str, float] = field(default_factory=dict)
    gross_cash_dividends_paid: float = 0.0
    withheld_cash_dividends_paid: float = 0.0

    def __post_init__(self) -> None:
        ensure_non_negative_finite(self.cash, "cash")
        ensure_non_negative_finite(self.available_cash, "available_cash")
        ensure_non_negative_finite(self.gross_cash_dividends_paid, "gross_cash_dividends_paid")
        ensure_non_negative_finite(self.withheld_cash_dividends_paid, "withheld_cash_dividends_paid")
        if self.withheld_cash_dividends_paid > self.gross_cash_dividends_paid:
            raise ValueError("withheld_cash_dividends_paid must not exceed gross_cash_dividends_paid")
        if self.available_cash > self.cash:
            raise ValueError(
                f"available_cash must be <= cash, got available_cash={self.available_cash!r} > cash={self.cash!r}"
            )
        if not isinstance(self.fractional, bool):
            raise ValueError(f"fractional must be a bool, got {self.fractional!r}")  # noqa: TRY004
        # 规格 §11.3：整手/整股约束由操作层负责，契约层只保证 fractional=False 时的数量一致性
        object.__setattr__(
            self,
            "positions",
            _freeze_mapping(self.positions, "positions", _quantity_check("positions", self.fractional)),
        )
        object.__setattr__(
            self,
            "locked",
            _freeze_mapping(self.locked, "locked", _quantity_check("locked", self.fractional)),
        )
        # 冻结必须是持仓子集：键必须存在且数量不超过持仓，否则可卖量为负属状态不一致
        for instrument_id, locked_quantity in self.locked.items():
            held = self.positions.get(instrument_id)
            if held is None:
                raise ValueError(f"locked[{instrument_id!r}]={locked_quantity!r} has no matching position")
            if locked_quantity > held:
                raise ValueError(
                    f"locked[{instrument_id!r}]={locked_quantity!r} exceeds positions[{instrument_id!r}]={held!r}"
                )
        object.__setattr__(self, "cost", _freeze_mapping(self.cost, "cost", _cost_check("cost")))
        object.__setattr__(
            self,
            "last_marks",
            _freeze_mapping(self.last_marks, "last_marks", _mark_check("last_marks")),
        )
        operations = tuple(self.processed_action_operations)
        if len(set(operations)) != len(operations):
            raise ValueError("processed_action_operations must not contain duplicates")
        for operation_id in operations:
            ensure_non_empty_str(operation_id, "processed_action_operations item")
        object.__setattr__(self, "processed_action_operations", operations)
        object.__setattr__(self, "record_positions", _freeze_mapping(
            self.record_positions, "record_positions", _quantity_check("record_positions", self.fractional)
        ))
        object.__setattr__(self, "record_costs", _freeze_mapping(
            self.record_costs, "record_costs", _cost_check("record_costs")
        ))
        object.__setattr__(self, "cash_receivables", _freeze_action_mapping(
            self.cash_receivables, "cash_receivables", CashReceivable
        ))
        object.__setattr__(self, "unlisted_entitlements", _freeze_action_mapping(
            self.unlisted_entitlements, "unlisted_entitlements", ShareEntitlement
        ))
        object.__setattr__(self, "pending_cash", _freeze_mapping(
            self.pending_cash, "pending_cash", _quantity_check("pending_cash", True)
        ))


@dataclass(frozen=True)
class PositionSnapshot:
    """单标的持仓快照（K02）：股数/成本/市价/市值，供策略经 AccountView 只读消费。

    price 与 market_value 必须同时有值或同时为 None：缺价（当日 close 与 last_marks 皆缺）
    时两者为 None，禁止以 0 冒充。market_value 与 shares × price 保持一致（浮点容差内）。
    """

    shares: int
    cost: float
    price: float | None
    market_value: float | None

    def __post_init__(self) -> None:
        """股数/成本/市价/市值逐项校验；缺价用 None，禁止 0 或半对字段冒充。"""
        if isinstance(self.shares, bool) or not isinstance(self.shares, int) or self.shares < 0:
            raise ValueError(f"shares must be a non-negative int, got {self.shares!r}")
        ensure_non_negative_finite(self.cost, "cost")
        if self.price is None or self.market_value is None:
            if self.price is not None or self.market_value is not None:
                raise ValueError(
                    "price and market_value must both be set or both be None, "
                    f"got price={self.price!r}, market_value={self.market_value!r}"
                )
            return
        ensure_finite(self.price, "price")
        if self.price <= 0:
            raise ValueError(f"price must be positive, got {self.price!r}")
        ensure_non_negative_finite(self.market_value, "market_value")
        expected = self.shares * self.price
        if not math.isclose(self.market_value, expected, rel_tol=1e-9, abs_tol=1e-9):
            raise ValueError(
                f"market_value must equal shares * price, got market_value={self.market_value!r} vs {expected!r}"
            )


@dataclass(frozen=True)
class AccountSnapshot:
    """账户每日收盘快照（K02）：现金/持仓/NAV 的只读记录，订单入口逐日产出。

    NAV = cash + 净应收 + 持仓/未上市权益市值。gross receivable 与 withholding payable 仅作分账，
    不再叠加到净应收；已到账 gross/withheld 累计额是审计字段，也不另加进 NAV。
    每个持仓的 price 取当日 close，close 缺失回退最近一次有效 mark（last_marks）；
    两者皆缺则该持仓 price/market_value 为 None 且不计入 NAV（引擎侧同时产出 warning）。
    """

    date: date
    cash: float
    positions: Mapping[str, PositionSnapshot]
    nav: float
    receivables_value: float = 0.0
    unlisted_entitlements: Mapping[str, UnlistedEntitlementSnapshot] = field(default_factory=dict)
    available_cash: float | None = None
    gross_receivables_value: float | None = None
    withholding_payable_value: float = 0.0
    gross_cash_dividends_paid: float = 0.0
    withheld_cash_dividends_paid: float = 0.0

    def __post_init__(self) -> None:
        ensure_calendar_date(self.date, "date")
        ensure_non_negative_finite(self.cash, "cash")
        available = self.cash if self.available_cash is None else self.available_cash
        ensure_non_negative_finite(available, "available_cash")
        if available > self.cash:
            raise ValueError("available_cash must not exceed cash")
        object.__setattr__(self, "available_cash", float(available))
        ensure_non_negative_finite(self.receivables_value, "receivables_value")
        ensure_non_negative_finite(self.withholding_payable_value, "withholding_payable_value")
        gross_receivables = (self.receivables_value + self.withholding_payable_value
                             if self.gross_receivables_value is None else self.gross_receivables_value)
        ensure_non_negative_finite(gross_receivables, "gross_receivables_value")
        if not math.isclose(gross_receivables, self.receivables_value + self.withholding_payable_value,
                            rel_tol=1e-9, abs_tol=1e-6):
            raise ValueError("gross receivables must equal net receivables plus withholding payable")
        object.__setattr__(self, "gross_receivables_value", float(gross_receivables))
        ensure_non_negative_finite(self.gross_cash_dividends_paid, "gross_cash_dividends_paid")
        ensure_non_negative_finite(self.withheld_cash_dividends_paid, "withheld_cash_dividends_paid")
        if self.withheld_cash_dividends_paid > self.gross_cash_dividends_paid:
            raise ValueError("withheld cash dividends paid must not exceed gross dividends paid")
        object.__setattr__(self, "positions", _freeze_positions(self.positions))
        object.__setattr__(self, "unlisted_entitlements", _freeze_action_mapping(
            self.unlisted_entitlements, "unlisted_entitlements", UnlistedEntitlementSnapshot
        ))
        ensure_non_negative_finite(self.nav, "nav")
        # NAV 一致性按 close mark 口径校验：缺价持仓 market_value=None 已按语义排除在求和外；
        # 按 instrument_id 排序求和与引擎 mark 路径的浮点加法顺序一致（容差吸收结合序噪声）。
        computed = self.cash + self.receivables_value
        computed += sum(item.market_value for item in self.unlisted_entitlements.values())
        for instrument_id in sorted(self.positions):
            market_value = self.positions[instrument_id].market_value
            if market_value is not None:
                computed += market_value
        if not math.isclose(self.nav, computed, rel_tol=1e-9, abs_tol=1e-6):
            raise ValueError(
                f"nav must equal cash + sum(position market values), got nav={self.nav!r} vs computed={computed!r}"
            )

    @property
    def blocked_cash(self) -> float:
        return self.cash - float(self.available_cash or 0.0)


def _freeze_positions(values: Mapping[str, PositionSnapshot]) -> Mapping[str, PositionSnapshot]:
    """复制为只读映射：外部 dict 突变不影响快照；值不是 PositionSnapshot 时显式拒绝。"""
    if not isinstance(values, Mapping):
        raise ValueError(f"positions must be a mapping, got {values!r}")  # noqa: TRY004
    frozen: dict[str, PositionSnapshot] = {}
    for key, value in values.items():
        ensure_non_empty_str(key, "positions key")
        if not isinstance(value, PositionSnapshot):
            raise ValueError(f"positions[{key!r}] must be a PositionSnapshot, got {value!r}")  # noqa: TRY004
        frozen[key] = value
    return MappingProxyType(frozen)
