# contracts - 契约层

最底层，**零内部依赖**（不 import 其他子包）。改动这里会影响所有上层。

## 关键约束

- 所有模型 `frozen=True` `extra=forbid`：构造后不可变，多余字段报错。
- 枚举全部 `StrEnum`（值小写下划线），可 JSON 序列化。
- `validation.py` 的校验函数在 `__post_init__` 调用：拒绝空串、naive datetime、非有限浮点。
- 添加新字段 = 破坏性变更：必须 bump `schema_version` 并同步 `result.py` 的 `SCHEMA_VERSION`。
- `protocols.py` 定义 `MarketDataProvider` / `OrderStrategy` 等 Protocol（接口契约，实现方在包外）。

## 配置（`config.py`）

- 八组 pydantic `BaseModel`，`load_config()` 从 YAML 加载。
- `hash_config()` 参与 `RunManifest.config_hash` 溯源。改默认值 = 口径变更，必须 bump `engine_version` / `policy_version`。

## 不变量

- `TradeEvent` 构造强制 `execution_time > signal_time`。
- `Prediction` 不携带 `execution_time` — 后者由引擎在成交时确定。
- `OrderIntent` 买单 `shares` / `cash_amount` 恰选其一（互斥）。卖单只认 `shares`。
