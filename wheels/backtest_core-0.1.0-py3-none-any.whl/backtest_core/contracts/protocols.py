"""规格 §10/§15 公共 Protocol：行情/策略/运行器 + 成本/滑点接口 + 订单与只读视图。

契约层保持单向依赖：本节只引用 T03/T04 将提供的具体模型，运行期不 import。
"""

from collections.abc import Mapping, Sequence
from datetime import date, datetime
from typing import TYPE_CHECKING, Protocol, runtime_checkable

from .enums import Side
from .market import MarketBar
from .order import OrderIntent
from .prediction import Prediction
from .slippage import SlippageResult

if TYPE_CHECKING:
    # T04 提供 contracts/policy.py，T03 提供 contracts/result.py（本任务不创建）
    from .policy import ExecutionPolicy  # pyright: ignore[reportMissingImports]
    from .result import EvaluationResult  # pyright: ignore[reportMissingImports]

__all__ = [
    "AccountView",
    "BacktestRunner",
    "CostModel",
    "MarketDataProvider",
    "MarketView",
    "OrderStrategy",
    "PositionView",
    "SlippageModel",
    "StrategyAdapter",
]


@runtime_checkable
class MarketDataProvider(Protocol):
    """行情提供者：单日 bar + 防前视历史窗口。"""

    def get_bar(self, instrument_id: str, trading_date: date) -> MarketBar | None:
        """返回指定标的和交易日的标准行情；缺失时返回 None。"""
        ...

    def get_history(self, instrument_id: str, end_date: date, lookback_days: int) -> Sequence[MarketBar]:
        """返回 end_date 及之前 lookback_days 个交易日的 bar 序列。

        只允许包含 trading_date ≤ end_date 的数据且按日期升序（防前视）；
        lookback_days 含 end_date 当日，供 ADV20/σ20 等流动性统计使用。
        """
        ...


@runtime_checkable
class StrategyAdapter(Protocol):
    """策略适配器：将项目模型输出转换为带语义的标准预测序列。"""

    def predict(self, signal_time: datetime) -> Sequence[Prediction]:
        """signal_time 必须与预测所用信息的截止时间一致（防前视）。"""
        ...


@runtime_checkable
class BacktestRunner(Protocol):
    """按指定层级运行回测并返回带来源信息的标准结果。"""

    def run(
        self,
        strategy: StrategyAdapter,
        market: MarketDataProvider,
        policy: "ExecutionPolicy",
    ) -> "EvaluationResult":
        ...


@runtime_checkable
class CostModel(Protocol):
    """A 股成本模型（规格 §11.4）：返回 commission/stamp_tax/transfer_fee 三项拆分。"""

    def calculate(self, side: Side | str, amount: float) -> tuple[float, float, float]:
        """按成交额计算费用；stamp_tax 仅卖出计提，拆分字段供 TradeEvent 直接落盘。"""
        ...


@runtime_checkable
class SlippageModel(Protocol):
    """σ 缩放滑点模型（规格 §10/§11.4）：ADV20/σ20 齐备时的完整输出。"""

    def compute(
        self,
        side: Side | str,
        order_amount: float,
        base_price: float,
        adv20: float,
        sigma20: float,
    ) -> SlippageResult:
        """返回参与率（raw/capped）、冲击率、半价差率、滑点率、成交价与超限标志。"""
        ...


@runtime_checkable
class PositionView(Protocol):
    """单标的持仓只读视图：股数/成本/最新价/市值；缺价用 None，禁止以 0 冒充。"""

    @property
    def shares(self) -> int:
        ...

    @property
    def cost(self) -> float:
        ...

    @property
    def price(self) -> float | None:
        ...

    @property
    def market_value(self) -> float | None:
        ...


@runtime_checkable
class AccountView(Protocol):
    """账户只读视图（规格 §15）：策略只能读取，禁止维护影子账户或回写。

    形状与 AccountState / AccountSnapshot 协调：cash/available_cash 与
    AccountState 同义（available_cash 为可动用现金）；positions 以 instrument_id
    为键；locked 为 T+1 当日不可卖股数（缺键视为 0）；nav 为账户净值。
    """

    @property
    def cash(self) -> float:
        ...

    @property
    def available_cash(self) -> float:
        ...

    @property
    def positions(self) -> Mapping[str, PositionView]:
        ...

    @property
    def locked(self) -> Mapping[str, int]:
        ...

    @property
    def nav(self) -> float:
        ...


@runtime_checkable
class MarketView(Protocol):
    """市场只读批量视图（规格 §15）：策略只允许查询，禁止写入或逐标的重复加载。

    实现约束（K02 MarketState 遵循）：
    - 返回 [start, end] 闭区间内的 bar，按 trading_date 升序，绝不返回 end 之后的数据；
    - 返回映射的键集合等于请求的标的集合（str 视为单标的）；无数据标的使用
      "键存在且值为空序列"表示，禁止缺键；
    - interval 当前仅支持 "1d"（小时/15min 预留），非法值由实现显式拒绝（ValueError）。
    """

    def get_bars(
        self,
        instrument_ids: str | Sequence[str],
        start: date,
        end: date,
        interval: str = "1d",
    ) -> Mapping[str, Sequence[MarketBar]]:
        """批量返回区间行情；缺失标的的键必须存在（见类 docstring 语义约定）。"""
        ...


@runtime_checkable
class OrderStrategy(Protocol):
    """订单策略（规格 §15）：引擎在调仓日回调，策略只提交意图、不参与撮合。

    引擎不变量与策略纪律：
    - 先卖后买由引擎保证，策略返回顺序不影响执行顺序；
    - 策略禁止维护影子账户：现金/持仓/锁定必须经 AccountView 读取，成交结果以
      OrderResult 回报为准；
    - signal_time 为 tz-aware（默认 15:00 Asia/Shanghai），与执行时点严格分离。
    """

    def orders_for(
        self,
        *,
        trading_date: date,
        signal_time: datetime,
        account: AccountView,
        market: MarketView,
    ) -> Sequence[OrderIntent]:
        """返回调仓日的订单意图（可为空）；可否成交由引擎裁决并逐单回报 OrderResult。"""
        ...
