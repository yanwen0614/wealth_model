"""八组配置 schema（规格 §13）：frozen + extra=forbid，执行/成本/评估口径缺失在运行前即拒绝。"""

import hashlib
import json
from datetime import date
from pathlib import Path
from typing import Any, Literal, Self

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .. import __version__ as _ENGINE_VERSION
from .enums import PredictionType, RankingDirection
from .policy import ExecutionPolicy
from .result import (
    SCHEMA_VERSION,
    AnnualizationBasis,
    FinalMarkPolicy,
    MaxDrawdownSign,
    MetricMethodology,
    WinRateDefinition,
)

__all__ = [
    "BacktestConfig",
    "CostConfig",
    "DataConfig",
    "EvaluationConfig",
    "ExecutionConfig",
    "OutputConfig",
    "PortfolioConfig",
    "RunConfig",
    "SignalConfig",
    "load_config",
]

Layer = Literal["signal", "paper", "account"]
AdjustmentMode = Literal["raw", "backward_adjusted", "forward_adjusted"]
WeightRule = Literal["equal_weight", "score_weight", "target_weight"]
SignalMissingPolicy = Literal["warn", "skip", "error"]
MissingVolumePolicy = Literal["warn", "skip"]
TradabilityBehavior = Literal["skip", "lock"]


class _ConfigModel(BaseModel):
    """共享基类：运行时配置必须不可变、拒绝未知字段，并支持规范化哈希。

    配置层有意采用 pydantic 宽松强制（bool→int、午夜 datetime→date）：严格类型语义
    由域契约层（frozen dataclass + __post_init__）承担，两层分工不重叠。
    """

    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)

    def config_hash(self) -> str:
        """字段序无关的 sha256：manifest 与运行记录依赖该值判定配置等价。"""
        # 当前 schema 无非确定字段（如 created_at）；新增时必须在此显式排除
        canonical = json.dumps(
            self.model_dump(mode="json"),
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class RunConfig(_ConfigModel):
    """run 组：运行标识 + 层级 + 随机种子；run_id/model_id 非空即身份可追溯。"""

    run_id: str = Field(min_length=1)
    model_id: str = Field(min_length=1)
    layer: Layer
    seed: int = 42

    @field_validator("run_id", "model_id")
    @classmethod
    def _reject_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must be a non-empty string")
        return value


class DataConfig(_ConfigModel):
    """data 组：数据血缘（provider/fingerprint/calendar）与复权口径；复权默认 raw 须显式切换。"""

    provider: str = Field(min_length=1)
    start_date: date
    end_date: date
    adjustment: AdjustmentMode = "raw"
    # 阶段 1 允许缺省：T13 写 manifest 前对非空 fingerprint 做 provenance 校验
    data_fingerprint: str | None = Field(default=None, min_length=1)
    # 规格 §13「交易日历」承载位：阶段 1 无消费者，交易日序列由 MarketDataProvider bar 承载；
    # 提供时必须非空，T13/T14 消费方需要时做显式校验
    trading_calendar: str | None = None

    @field_validator("provider")
    @classmethod
    def _reject_blank(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("must be a non-empty string")
        return value

    @field_validator("trading_calendar")
    @classmethod
    def _reject_blank_calendar(cls, value: str | None) -> str | None:
        if value is not None and not value.strip():
            raise ValueError("must be a non-empty string when provided")
        return value

    @model_validator(mode="after")
    def _check_date_range(self) -> Self:
        if self.start_date > self.end_date:
            raise ValueError(f"start_date {self.start_date} must not exceed end_date {self.end_date}")
        return self


class SignalConfig(_ConfigModel):
    """signal 组：预测语义 + 标签窗口 + 缺失策略；语义字段必填以免误用错误模型输出。"""

    prediction_type: PredictionType
    ranking_direction: RankingDirection = RankingDirection.DESCENDING
    label_horizon: int = Field(gt=0)
    missing_policy: SignalMissingPolicy = "warn"


class PortfolioConfig(_ConfigModel):
    """portfolio 组：调仓/选股/卖出缓冲/现金与整手约束。"""

    rebalance_frequency: int = Field(default=1, ge=1)
    top_n: int = Field(default=20, ge=1)
    weight_rule: WeightRule = "equal_weight"
    # 排名跌出 top_n 后仍多容忍 sell_buffer 个位次才卖出；0 表示立即卖出
    sell_buffer: int = Field(default=0, ge=0)
    cash_reserve_ratio: float = Field(default=0.0, ge=0.0, le=1.0)
    lot_size: int = Field(default=100, ge=1)


class ExecutionConfig(ExecutionPolicy):
    """execution 组：规格 §10 策略 + 停牌/涨跌停/缺价行为开关；可整体作为 ExecutionPolicy 传入运行器。

    有意不提供 config_hash()（继承 ExecutionPolicy 而非 _ConfigModel，仅 BacktestConfig
    提供顶层哈希）——哈希契约以 BacktestConfig 为单一入口，本 API 不对称属既知设计。
    """

    suspension_policy: TradabilityBehavior = "skip"
    limit_up_policy: TradabilityBehavior = "skip"
    limit_down_policy: TradabilityBehavior = "lock"
    missing_price_policy: TradabilityBehavior = "skip"


class CostConfig(_ConfigModel):
    """cost 组：A 股费率（Key Decision 2）+ σ 缩放滑点参数（Key Decision 3/4，依据 SLIPPAGE_RESEARCH §6）。

    买卖拆分佣金：commission_rate_buy/sell 为空时回退 commission_rate（旧行为零变化）。
    """

    commission_rate: float = Field(default=0.0002, ge=0.0, le=1.0)
    # 买卖拆分佣金（可选）：仅设置一边时另一边仍回退 commission_rate
    commission_rate_buy: float | None = Field(default=None, ge=0.0, le=1.0)
    commission_rate_sell: float | None = Field(default=None, ge=0.0, le=1.0)
    min_commission: float = Field(default=5.0, ge=0.0)
    stamp_tax_rate: float = Field(default=0.0005, ge=0.0, le=1.0)  # 仅卖出计提
    transfer_fee_rate: float = Field(default=0.0, ge=0.0, le=1.0)
    # Y：impact = Y * sigma20 * sqrt(p)；范围冻结为调研裁决 0.5–1.5（SLIPPAGE_RESEARCH §6）
    impact_coefficient: float = Field(default=1.0, ge=0.5, le=1.5)
    adv_window: int = Field(default=20, ge=1)
    sigma_window: int = Field(default=20, ge=2)  # ddof=1 至少 2 个收益样本，与 compute_liquidity_stats 对齐
    sigma_clip: tuple[float, float] = (0.005, 0.08)
    p_cap: float = Field(default=0.10, gt=0.0, le=1.0)
    spread_floor: float = Field(default=0.0002, ge=0.0, le=1.0)
    slip_max: float = Field(default=0.05, gt=0.0, le=1.0)
    missing_volume_policy: MissingVolumePolicy = "warn"

    @model_validator(mode="after")
    def _check_sigma_clip(self) -> Self:
        low, high = self.sigma_clip
        if low <= 0.0 or high <= 0.0:
            raise ValueError(f"sigma_clip bounds must be positive, got {self.sigma_clip!r}")
        if low >= high:
            raise ValueError(f"sigma_clip lower bound must be < upper bound, got {self.sigma_clip!r}")
        return self


class EvaluationConfig(_ConfigModel):
    """evaluation 组：指标口径（Key Decision 10）；to_methodology 保证结果契约与配置同源。"""

    annualization_basis: AnnualizationBasis = "trading_days"
    trading_days_per_year: int = Field(default=242, ge=1)
    risk_free_rate_annual: float = 0.02
    sharpe_ddof: int = Field(default=1, ge=0, le=1)
    max_drawdown_sign: MaxDrawdownSign = "positive"
    win_rate_definition: WinRateDefinition = "daily_return"
    final_mark_policy: FinalMarkPolicy = "liquidation"

    def to_methodology(self) -> MetricMethodology:
        """配置是口径单一事实源：转换而非另存默认值，防止两处随版本漂移。"""
        return MetricMethodology(
            annualization_basis=self.annualization_basis,
            trading_days_per_year=self.trading_days_per_year,
            risk_free_rate_annual=self.risk_free_rate_annual,
            sharpe_ddof=self.sharpe_ddof,
            max_drawdown_sign=self.max_drawdown_sign,
            win_rate_definition=self.win_rate_definition,
            final_mark_policy=self.final_mark_policy,
        )


class OutputConfig(_ConfigModel):
    """output 组：结果存储版本与分块参数；版本三元组写入 manifest 以支持结果溯源。"""

    schema_version: str = Field(default=SCHEMA_VERSION, min_length=1)
    engine_version: str = Field(default=_ENGINE_VERSION, min_length=1)
    policy_version: str = Field(default="v1", min_length=1)
    output_dir: Path = Path("runs")
    parquet_chunk_size: int = Field(default=100_000, ge=1)


class BacktestConfig(_ConfigModel):
    """顶层配置：execution/cost/evaluation 三组无默认值，缺失在运行前报错并定位到组名。"""

    run: RunConfig
    data: DataConfig
    signal: SignalConfig
    portfolio: PortfolioConfig = Field(default_factory=PortfolioConfig)
    execution: ExecutionConfig
    cost: CostConfig
    evaluation: EvaluationConfig
    output: OutputConfig = Field(default_factory=OutputConfig)


def load_config(path: str | Path) -> BacktestConfig:
    """按扩展名解析 YAML/JSON 并做全量 schema 校验；不支持的扩展名显式拒绝而非猜测格式。"""
    config_path = Path(path)
    suffix = config_path.suffix.lower()
    if suffix not in (".yaml", ".yml", ".json"):
        # 后缀校验前置于读取：不存在的非法后缀路径也报格式错误而非 FileNotFoundError
        raise ValueError(f"unsupported config format {suffix!r}: expected .yaml/.yml/.json")
    text = config_path.read_text(encoding="utf-8")
    if suffix == ".json":
        payload: Any = json.loads(text)
    else:
        payload = yaml.safe_load(text)
    return BacktestConfig.model_validate(payload)
