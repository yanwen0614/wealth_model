"""契约内部校验助手（非公共 API）：frozen dataclass 的 __post_init__ 复用同一套规则。"""

import math
from datetime import date, datetime
from enum import Enum

__all__: list[str] = []


def ensure_non_empty_str(value: str, field_name: str) -> None:
    """拒绝 None/空串/纯空白：标识类字段缺失即契约违规，不得静默通过。"""
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be a non-empty string, got {value!r}")


def ensure_tz_aware(value: datetime, field_name: str) -> None:
    """拒绝 naive datetime（规格 §3.3 MUST）：无时区的时间点不可跨仓库比较。"""
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"{field_name} must be a timezone-aware datetime, got {value!r}")


def ensure_calendar_date(value: date, field_name: str) -> None:
    """交易日必须是纯 date：datetime 虽是 date 子类但会带出时间语义，须显式排除（规格 §3.3）。"""
    # 契约校验统一抛 ValueError 供 adapter 单点捕获，故抑制 TRY004 的 TypeError 建议
    if not isinstance(value, date) or isinstance(value, datetime):
        raise ValueError(f"{field_name} must be a calendar date, got {value!r}")  # noqa: TRY004


def ensure_finite(value: float, field_name: str) -> None:
    """拒绝 NaN/inf 与 bool：非有限值会污染后续指标；bool 是 int 子类但不是合法数值输入。"""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{field_name} must be a finite number, got {value!r}")


def ensure_non_negative_finite(value: float, field_name: str) -> None:
    """量额类字段：必须有限且非负。"""
    ensure_finite(value, field_name)
    if value < 0:
        raise ValueError(f"{field_name} must be non-negative, got {value!r}")


def ensure_enum_member[E: Enum](value: object, enum_type: type[E], field_name: str) -> E:
    """接受枚举成员或小写字符串字面量（规格 §10 接口形状），非法值统一抛 ValueError。"""
    if isinstance(value, enum_type):
        return value
    if isinstance(value, str):
        by_value = {member.value: member for member in enum_type}
        if value in by_value:
            return by_value[value]
    allowed = ", ".join(member.value for member in enum_type)
    raise ValueError(f"{field_name} must be one of ({allowed}), got {value!r}")
