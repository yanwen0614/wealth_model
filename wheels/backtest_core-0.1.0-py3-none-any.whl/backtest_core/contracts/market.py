"""行情与可交易性契约（规格 §10/§11.2）：构造即校验，原因码由纯函数派生。"""

from dataclasses import dataclass
from datetime import date

from .enums import ReasonCode
from .validation import (
    ensure_calendar_date,
    ensure_finite,
    ensure_non_empty_str,
    ensure_non_negative_finite,
)

__all__ = ["MarketBar", "tradability_reasons"]


@dataclass(frozen=True)
class MarketBar:
    """单标的单交易日标准行情；None 表示字段缺失，非法值在构造期拒绝。"""

    instrument_id: str
    trading_date: date
    open: float | None
    high: float | None
    low: float | None
    close: float | None
    volume: float | None
    amount: float | None
    is_trading: bool
    limit_up: bool
    limit_down: bool

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_calendar_date(self.trading_date, "trading_date")
        for field_name, price in (
            ("open", self.open),
            ("high", self.high),
            ("low", self.low),
            ("close", self.close),
        ):
            if price is not None:
                ensure_finite(price, field_name)
        if self.volume is not None:
            ensure_non_negative_finite(self.volume, "volume")
        if self.amount is not None:
            ensure_non_negative_finite(self.amount, "amount")
        if self.high is not None and self.low is not None and self.high < self.low:
            raise ValueError(f"high must be >= low, got high={self.high!r} < low={self.low!r}")


def tradability_reasons(bar: MarketBar) -> frozenset[ReasonCode]:
    """派生与方向/执行模式无关的基础原因码；方向性过滤由 policies/tradability 决定。"""
    reasons: set[ReasonCode] = set()
    if not bar.is_trading:
        reasons.add(ReasonCode.SUSPENDED)
    # 任一 OHLC 缺失即视为缺价：t1_open/same_day_close/mid 各有依赖的价格字段
    if bar.open is None or bar.high is None or bar.low is None or bar.close is None:
        reasons.add(ReasonCode.MISSING_PRICE)
    if bar.limit_up:
        reasons.add(ReasonCode.LIMIT_UP)
    if bar.limit_down:
        reasons.add(ReasonCode.LIMIT_DOWN)
    if bar.volume is None:
        reasons.add(ReasonCode.MISSING_VOLUME)
    elif bar.volume <= 0:
        reasons.add(ReasonCode.INVALID_VOLUME)
    return frozenset(reasons)
