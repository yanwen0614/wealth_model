"""执行策略契约（规格 §10）：默认 t1_open 防前视 + 尾日清算语义，配置与运行器共用同一形状。"""

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .enums import ExecutionMode

__all__ = ["ExecutionPolicy", "FinalLiquidation"]

FinalLiquidation = Literal["skip", "mark", "force"]


class ExecutionPolicy(BaseModel):
    """规格 §10 ExecutionPolicy：默认值由 Key Decision 1 冻结，偏移即三仓库口径漂移。"""

    model_config = ConfigDict(frozen=True, extra="forbid", allow_inf_nan=False)

    execution_mode: ExecutionMode = ExecutionMode.T1_OPEN
    rebalance_frequency: int = Field(default=1, ge=1)
    holding_horizon: int | None = Field(default=None, ge=1)
    lot_size: int = Field(default=100, ge=1)
    initial_capital: float = Field(default=1_000_000.0, gt=0)
    final_liquidation: FinalLiquidation = "force"
