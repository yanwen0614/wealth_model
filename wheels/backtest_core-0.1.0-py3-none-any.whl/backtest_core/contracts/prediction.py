"""预测与标签契约（规格 §10/§11.1）：语义由类型判别，构造即严格校验。"""

from dataclasses import dataclass
from datetime import datetime

from .enums import PredictionType, RankingDirection
from .validation import (
    ensure_enum_member,
    ensure_finite,
    ensure_non_empty_str,
    ensure_tz_aware,
)

__all__ = ["LabelReturn", "Prediction"]


@dataclass(frozen=True)
class Prediction:
    """模型在 signal_time 可获得的输出；语义由 prediction_type 判别（规格 §3.3 禁混用字段）。"""

    instrument_id: str
    signal_time: datetime
    value: float
    prediction_type: PredictionType
    ranking_direction: RankingDirection
    model_id: str
    run_id: str
    predicted_horizon: int | None

    def __post_init__(self) -> None:
        ensure_non_empty_str(self.instrument_id, "instrument_id")
        ensure_tz_aware(self.signal_time, "signal_time")
        ensure_finite(self.value, "value")
        # 规格 §10 接口形状允许适配器直接传字面量字符串，合法值在此归一为枚举成员
        object.__setattr__(
            self,
            "prediction_type",
            ensure_enum_member(self.prediction_type, PredictionType, "prediction_type"),
        )
        object.__setattr__(
            self,
            "ranking_direction",
            ensure_enum_member(self.ranking_direction, RankingDirection, "ranking_direction"),
        )
        ensure_non_empty_str(self.model_id, "model_id")
        ensure_non_empty_str(self.run_id, "run_id")
        if self.predicted_horizon is not None and (
            isinstance(self.predicted_horizon, bool)
            or not isinstance(self.predicted_horizon, int)
            or self.predicted_horizon < 1
        ):
            raise ValueError(f"predicted_horizon must be a positive int or None, got {self.predicted_horizon!r}")


@dataclass(frozen=True)
class LabelReturn:
    """标签收益：与 Prediction.value 分属不同字段（规格 §3.3），必须携带窗口与公式。"""

    label_return: float
    label_entry_time: datetime
    label_exit_time: datetime
    formula: str

    def __post_init__(self) -> None:
        ensure_finite(self.label_return, "label_return")
        ensure_tz_aware(self.label_entry_time, "label_entry_time")
        ensure_tz_aware(self.label_exit_time, "label_exit_time")
        ensure_non_empty_str(self.formula, "formula")
        if self.label_entry_time >= self.label_exit_time:
            raise ValueError(
                "label_entry_time must be strictly before label_exit_time, "
                f"got {self.label_entry_time!r} >= {self.label_exit_time!r}"
            )
