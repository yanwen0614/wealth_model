"""canonical contracts 公共 API：严格输入/输出模型 + 规格 §10 Protocol。

依赖方向：policies/engine/evaluation/io → contracts（单向）；本包不依赖其他子包。
"""

from .account import AccountSnapshot, AccountState, PositionSnapshot, UnlistedEntitlementSnapshot
from .account_actions import (
    CashPayment,
    CreateCashReceivable,
    CreateShareEntitlement,
    ListShareEntitlement,
    RecordPosition,
)
from .config import (
    BacktestConfig,
    CostConfig,
    DataConfig,
    EvaluationConfig,
    ExecutionConfig,
    OutputConfig,
    PortfolioConfig,
    RunConfig,
    SignalConfig,
    load_config,
)
from .enums import (
    EventStatus,
    ExecutionMode,
    PredictionType,
    RankingDirection,
    ReasonCode,
    Side,
)
from .events import TradeEvent
from .market import MarketBar, tradability_reasons
from .order import OrderIntent, OrderResult, OrderStatus
from .policy import ExecutionPolicy
from .prediction import LabelReturn, Prediction
from .protocols import (
    AccountView,
    BacktestRunner,
    CostModel,
    MarketDataProvider,
    MarketView,
    OrderStrategy,
    PositionView,
    SlippageModel,
    StrategyAdapter,
)
from .result import SCHEMA_VERSION, EvaluationResult, MetricMethodology
from .slippage import LiquidityStats, SlippageDecision, SlippageResult

__all__ = [
    "SCHEMA_VERSION",
    "AccountSnapshot",
    "AccountState",
    "AccountView",
    "BacktestConfig",
    "BacktestRunner",
    "CashPayment",
    "CostConfig",
    "CostModel",
    "CreateCashReceivable",
    "CreateShareEntitlement",
    "DataConfig",
    "EvaluationConfig",
    "EvaluationResult",
    "EventStatus",
    "ExecutionConfig",
    "ExecutionMode",
    "ExecutionPolicy",
    "LabelReturn",
    "LiquidityStats",
    "ListShareEntitlement",
    "MarketBar",
    "MarketDataProvider",
    "MarketView",
    "MetricMethodology",
    "OrderIntent",
    "OrderResult",
    "OrderStatus",
    "OrderStrategy",
    "OutputConfig",
    "PortfolioConfig",
    "PositionSnapshot",
    "PositionView",
    "Prediction",
    "PredictionType",
    "RankingDirection",
    "ReasonCode",
    "RecordPosition",
    "RunConfig",
    "Side",
    "SignalConfig",
    "SlippageDecision",
    "SlippageModel",
    "SlippageResult",
    "StrategyAdapter",
    "TradeEvent",
    "UnlistedEntitlementSnapshot",
    "load_config",
    "tradability_reasons",
]
