"""契约枚举定义：全部为 str 枚举，值即小写下划线字符串，可安全 JSON 序列化。"""

from enum import StrEnum

__all__ = [
    "EventStatus",
    "ExecutionMode",
    "PredictionType",
    "RankingDirection",
    "ReasonCode",
    "Side",
]


class PredictionType(StrEnum):
    """预测语义类型（规格 §11.1）：语义由本字段判别，禁止拆成独立字段。"""

    PREDICTED_RETURN = "predicted_return"
    RANKING_SCORE = "ranking_score"
    TARGET_WEIGHT = "target_weight"
    ACTION_VALUE = "action_value"


class RankingDirection(StrEnum):
    """排序方向：descending 表示值越大排名越靠前。"""

    ASCENDING = "ascending"
    DESCENDING = "descending"


class ExecutionMode(StrEnum):
    """执行时点（规格 §10）：默认 t1_open，其他模式须显式配置。"""

    T1_OPEN = "t1_open"
    SAME_DAY_CLOSE = "same_day_close"
    MID = "mid"


class EventStatus(StrEnum):
    """成交事件四态（规格 §3.2）：成交/跳过/锁定/强制退出。"""

    FILLED = "filled"
    SKIPPED = "skipped"
    LOCKED = "locked"
    FORCED_EXIT = "forced_exit"


class Side(StrEnum):
    """买卖方向。"""

    BUY = "buy"
    SELL = "sell"


class ReasonCode(StrEnum):
    """结构化原因码：跳过/锁定/强制退出必须显式报告原因，禁止静默丢弃。"""

    MISSING_PRICE = "missing_price"
    SUSPENDED = "suspended"
    LIMIT_UP = "limit_up"
    LIMIT_DOWN = "limit_down"
    INVALID_VOLUME = "invalid_volume"
    ZERO_LOT = "zero_lot"
    INSUFFICIENT_CASH = "insufficient_cash"
    OVERSELL = "oversell"
    LOCKED_POSITION = "locked_position"
    CAPACITY_EXCEEDED = "capacity_exceeded"
    SHORT_HISTORY = "short_history"
    MISSING_VOLUME = "missing_volume"
    NAN_VALUE = "nan_value"
    FORCED_EXIT = "forced_exit"
    NO_NEXT_TRADING_DAY = "no_next_trading_day"
