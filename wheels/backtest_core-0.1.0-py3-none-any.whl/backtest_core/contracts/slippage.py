"""滑点与缺量决策契约（规格 §10/§11.4）：参与率/冲击率拆解 + 缺量分支显式化。"""

from dataclasses import dataclass

from .enums import ReasonCode
from .validation import ensure_enum_member, ensure_finite, ensure_non_empty_str, ensure_non_negative_finite

__all__ = ["LiquidityStats", "SlippageDecision", "SlippageResult"]


@dataclass(frozen=True)
class SlippageResult:
    """规格 §10 滑点输出：参与率 raw/capped 分列，冲击与半价差拆开便于接实测 spread。

    缺量 warn 路径无 ADV 可算：participation_raw/capped 置 0.0 仅保持 §10 的 float 形状，
    权威参与率为 SlippageDecision.participation=None（事件层），见 policies/slippage.py。
    """

    participation_raw: float
    participation_capped: float
    impact_rate: float
    spread_rate: float
    slip_rate: float
    fill_price: float
    capacity_exceeded: bool

    def __post_init__(self) -> None:
        ensure_non_negative_finite(self.participation_raw, "participation_raw")
        ensure_non_negative_finite(self.participation_capped, "participation_capped")
        if self.participation_capped > 1.0:
            raise ValueError(f"participation_capped must be <= 1, got {self.participation_capped!r}")
        ensure_non_negative_finite(self.impact_rate, "impact_rate")
        ensure_non_negative_finite(self.spread_rate, "spread_rate")
        ensure_non_negative_finite(self.slip_rate, "slip_rate")
        ensure_finite(self.fill_price, "fill_price")
        if self.fill_price <= 0:
            raise ValueError(f"fill_price must be positive, got {self.fill_price!r}")
        if not isinstance(self.capacity_exceeded, bool):
            raise ValueError(f"capacity_exceeded must be a bool, got {self.capacity_exceeded!r}")  # noqa: TRY004


@dataclass(frozen=True)
class LiquidityStats:
    """ADV20/σ20 值对象：样本不足的 None 语义由 compute_liquidity_stats 返回 None 承担。"""

    adv20: float
    sigma20: float

    def __post_init__(self) -> None:
        ensure_non_negative_finite(self.adv20, "adv20")
        ensure_non_negative_finite(self.sigma20, "sigma20")


@dataclass(frozen=True)
class SlippageDecision:
    """滑点策略的完整决策：fill 与 skip 互斥，warn 降级由 warnings 显式携带。

    result 为 None 即 skip（必须带 skip_reason）；result 非 None 即继续成交。
    participation 是事件层写入 TradeEvent 的参与率：缺量 warn 路径必须为 None（规格 §11.4），
    不得用 SlippageResult.participation_raw/capped 的 0.0 占位替代。
    """

    result: SlippageResult | None
    participation: float | None
    skip_reason: ReasonCode | None
    warnings: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.result is None and self.skip_reason is None:
            raise ValueError("a decision without fill must carry skip_reason")
        if self.result is not None and self.skip_reason is not None:
            raise ValueError("a decision with fill must not carry skip_reason")
        if self.result is not None and not isinstance(self.result, SlippageResult):
            raise ValueError(f"result must be a SlippageResult or None, got {self.result!r}")
        if self.participation is not None:
            ensure_finite(self.participation, "participation")
            if not 0.0 <= self.participation <= 1.0:
                raise ValueError(f"participation must be within [0, 1], got {self.participation!r}")
        if self.skip_reason is not None:
            object.__setattr__(self, "skip_reason", ensure_enum_member(self.skip_reason, ReasonCode, "skip_reason"))
        if isinstance(self.warnings, (str, bytes)):
            raise ValueError(f"warnings must be a sequence of str, got {self.warnings!r}")  # noqa: TRY004
        checked = tuple(self.warnings)
        for warning in checked:
            ensure_non_empty_str(warning, "warnings item")
        object.__setattr__(self, "warnings", checked)
