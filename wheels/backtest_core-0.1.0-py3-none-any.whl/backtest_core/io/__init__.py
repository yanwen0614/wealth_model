"""io 子包公共 API：RunManifest 与 ResultStore（依赖方向：io → contracts，规格 §9）。"""

from .manifest import RunManifest
from .store import DEFAULT_CHUNK_SIZE, MANIFEST_FILENAME, METRICS_FILENAME, TRADES_FILENAME, ResultStore

__all__ = [
    "DEFAULT_CHUNK_SIZE",
    "MANIFEST_FILENAME",
    "METRICS_FILENAME",
    "TRADES_FILENAME",
    "ResultStore",
    "RunManifest",
]
