"""结果存储（规格 §3.4 内存约束 / Key Decision 13）：分块 Parquet 写入 + 整目录原子换入。"""

import json
import math
import os
import shutil
import tempfile
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

import pyarrow as pa
import pyarrow.parquet as pq

from ..contracts.events import TradeEvent
from ..contracts.result import EvaluationResult
from .manifest import RunManifest

__all__ = [
    "DEFAULT_CHUNK_SIZE",
    "MANIFEST_FILENAME",
    "METRICS_FILENAME",
    "TRADES_FILENAME",
    "ResultStore",
]

MANIFEST_FILENAME = "manifest.json"
METRICS_FILENAME = "metrics.json"
TRADES_FILENAME = "trades.parquet"
DEFAULT_CHUNK_SIZE = 100_000

# 列序/类型即文件契约：阶段 2/3 读取方与 golden 测试依赖该 schema 稳定（T13 风险因子）。
# 时间戳统一归一 UTC（同一时刻跨时区比较相等），datetime 微秒精度用 us 保真；
# 亚微秒精度输入（如 pd.Timestamp 纳秒）按 schema 截断为 µs，不保留纳秒。
TRADE_ARROW_SCHEMA = pa.schema(
    [
        pa.field("signal_time", pa.timestamp("us", tz="UTC")),
        pa.field("execution_time", pa.timestamp("us", tz="UTC")),
        pa.field("instrument_id", pa.string()),
        pa.field("side", pa.string()),
        pa.field("shares", pa.int64()),
        pa.field("base_price", pa.float64()),
        pa.field("execution_price", pa.float64()),
        pa.field("amount", pa.float64()),
        pa.field("commission", pa.float64()),
        pa.field("stamp_tax", pa.float64()),
        pa.field("transfer_fee", pa.float64()),
        pa.field("slippage_cost", pa.float64()),
        pa.field("participation", pa.float64()),
        pa.field("status", pa.string()),
        pa.field("reason", pa.string()),
    ]
)

_EMPTY_PAPER_TRADES_WARNING = (
    "trades_location=paper_simulation and trades row count is 0: paper fills live in "
    "PaperSimulation.trades, not EvaluationResult.trades; 0 rows must not be read as 'no trades'"
)


def _trade_row(trade: TradeEvent) -> dict[str, Any]:
    """事件 → Parquet 行：枚举写 value、可选值保 None，键与 TRADE_ARROW_SCHEMA 一一对应。"""
    return {
        "signal_time": trade.signal_time,
        "execution_time": trade.execution_time,
        "instrument_id": trade.instrument_id,
        "side": trade.side.value,
        "shares": trade.shares,
        "base_price": trade.base_price,
        "execution_price": trade.execution_price,
        "amount": trade.amount,
        "commission": trade.commission,
        "stamp_tax": trade.stamp_tax,
        "transfer_fee": trade.transfer_fee,
        "slippage_cost": trade.slippage_cost,
        "participation": trade.participation,
        "status": trade.status.value,
        "reason": None if trade.reason is None else trade.reason.value,
    }


def _sanitize_json(value: Any, path: str) -> tuple[Any, list[str]]:
    """JSON 非有限值降级：NaN/inf 写 null 并逐项给警告；json.dumps(allow_nan=False) 做最后兜底。"""
    if isinstance(value, float) and not math.isfinite(value):
        label = "nan" if math.isnan(value) else ("inf" if value > 0 else "-inf")
        return None, [f"non-finite value at {path} ({label}) written as null"]
    if isinstance(value, Mapping):
        cleaned: dict[str, Any] = {}
        warnings: list[str] = []
        for key, item in value.items():
            cleaned_item, item_warnings = _sanitize_json(item, f"{path}.{key}")
            cleaned[str(key)] = cleaned_item
            warnings.extend(item_warnings)
        return cleaned, warnings
    if isinstance(value, (list, tuple)):
        cleaned_list: list[Any] = []
        list_warnings: list[str] = []
        for index, item in enumerate(value):
            cleaned_item, item_warnings = _sanitize_json(item, f"{path}[{index}]")
            cleaned_list.append(cleaned_item)
            list_warnings.extend(item_warnings)
        return cleaned_list, list_warnings
    return value, []


def _entry_path(path: str | Path, filename: str) -> Path:
    """读入口：目录（含尚不存在的路径）解析为目录内文件，显式文件路径原样使用。"""
    candidate = Path(path)
    if candidate.name == filename or candidate.is_file():
        return candidate
    return candidate / filename


def _replace_dir(tmp_dir: Path, target: Path) -> None:
    """整目录换入：临时目录写全后才替换目标，读者不会看到三件套的新旧混合组合。"""
    if target.exists():
        shutil.rmtree(target)
    os.replace(tmp_dir, target)


class ResultStore:
    """一次运行的结果目录读写器：<out>/{manifest.json, metrics.json, trades.parquet}。

    metrics.json 采用分层结构（signal/paper/account 各自成键）而非 flatten_metrics(prefix=True)：
    读取方直接按键回填 EvaluationResult，无需反解前缀。
    """

    def __init__(self, output_dir: str | Path, *, chunk_size: int = DEFAULT_CHUNK_SIZE) -> None:
        if isinstance(chunk_size, bool) or not isinstance(chunk_size, int) or chunk_size < 1:
            raise ValueError(f"chunk_size must be a positive int, got {chunk_size!r}")
        self.output_dir = Path(output_dir)
        self.chunk_size = chunk_size
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def write(
        self,
        result: EvaluationResult,
        manifest: RunManifest,
        *,
        trades: Iterable[TradeEvent] | None = None,
    ) -> Path:
        """写入三件套并返回结果目录：trades 可传一次性迭代器分块落盘，默认取 result.trades。"""
        if not isinstance(result, EvaluationResult):
            raise ValueError(f"result must be an EvaluationResult, got {result!r}")  # noqa: TRY004
        if not isinstance(manifest, RunManifest):
            raise ValueError(f"manifest must be a RunManifest, got {manifest!r}")  # noqa: TRY004
        source: Iterable[TradeEvent] = result.trades if trades is None else trades
        # 先写同级临时目录，成功后才整体换入：中途失败时旧版本（或空目录）保持不变
        tmp_dir = Path(tempfile.mkdtemp(prefix=f".{self.output_dir.name}.tmp-", dir=self.output_dir.parent))
        try:
            self._write_manifest(tmp_dir / MANIFEST_FILENAME, manifest)
            row_count = self._write_trades(tmp_dir / TRADES_FILENAME, source)
            extra_warnings: list[str] = []
            if manifest.trades_location == "paper_simulation" and row_count == 0:
                extra_warnings.append(_EMPTY_PAPER_TRADES_WARNING)
            self._write_metrics(tmp_dir / METRICS_FILENAME, result, extra_warnings)
            _replace_dir(tmp_dir, self.output_dir)
        except BaseException:
            # 临时目录是唯一写入现场：任何异常都清理，目标目录要么是旧完整版本要么不存在
            shutil.rmtree(tmp_dir, ignore_errors=True)
            raise
        return self.output_dir

    def read(self, path: str | Path) -> EvaluationResult:
        """聚合三件套重建结果：版本/口径取 manifest，指标与 provenance 取 metrics.json。"""
        manifest = self.read_manifest(path)
        metrics = self.read_metrics(path)
        return EvaluationResult(
            schema_version=manifest.schema_version,
            engine_version=manifest.engine_version,
            policy_version=manifest.policy_version,
            run_id=manifest.run_id,
            model_id=manifest.model_id,
            signal_metrics=metrics["signal_metrics"],
            paper_metrics=metrics["paper_metrics"],
            account_metrics=metrics["account_metrics"],
            methodology=manifest.methodology,
            trades=tuple(self.read_trades(path)),
            warnings=tuple(metrics["warnings"]),
            skipped_counts=metrics["skipped_counts"],
            provenance=metrics["provenance"],
        )

    def read_manifest(self, path: str | Path) -> RunManifest:
        payload = json.loads(_entry_path(path, MANIFEST_FILENAME).read_text(encoding="utf-8"))
        return RunManifest.from_dict(payload)

    def read_metrics(self, path: str | Path) -> dict[str, Any]:
        payload = json.loads(_entry_path(path, METRICS_FILENAME).read_text(encoding="utf-8"))
        if not isinstance(payload, Mapping):
            raise ValueError(f"metrics.json must contain a JSON object, got {payload!r}")  # noqa: TRY004
        return dict(payload)

    def read_trades(self, path: str | Path) -> list[TradeEvent]:
        table = pq.read_table(_entry_path(path, TRADES_FILENAME))
        return [_trade_from_row(row) for row in table.to_pylist()]

    @staticmethod
    def _write_manifest(path: Path, manifest: RunManifest) -> None:
        text = json.dumps(manifest.to_dict(), ensure_ascii=False, indent=2, allow_nan=False)
        path.write_text(text + "\n", encoding="utf-8")

    def _write_trades(self, path: Path, trades: Iterable[TradeEvent]) -> int:
        """分块写 Parquet：每 chunk_size 条落一个 row group，峰值内存与总事件数解耦（规格 §3.4）。"""
        if isinstance(trades, (str, bytes)) or not isinstance(trades, Iterable):
            raise ValueError(f"trades must be an iterable of TradeEvent, got {trades!r}")  # noqa: TRY004
        row_count = 0
        with pq.ParquetWriter(path, TRADE_ARROW_SCHEMA, compression="snappy") as writer:
            chunk: list[TradeEvent] = []
            for trade in trades:
                if not isinstance(trade, TradeEvent):
                    raise ValueError(f"trades items must be TradeEvent, got {trade!r}")  # noqa: TRY004
                chunk.append(trade)
                if len(chunk) >= self.chunk_size:
                    writer.write_table(pa.Table.from_pylist([_trade_row(item) for item in chunk], TRADE_ARROW_SCHEMA))
                    row_count += len(chunk)
                    chunk.clear()
            if chunk or row_count == 0:
                # 0 事件也写一张空表：文件必须带 schema，读者无需对「缺文件」与「无交易」二次判别
                writer.write_table(pa.Table.from_pylist([_trade_row(item) for item in chunk], TRADE_ARROW_SCHEMA))
                row_count += len(chunk)
        return row_count

    @staticmethod
    def _write_metrics(path: Path, result: EvaluationResult, extra_warnings: list[str]) -> None:
        payload: dict[str, Any] = {
            "signal_metrics": dict(result.signal_metrics),
            "paper_metrics": dict(result.paper_metrics),
            "account_metrics": dict(result.account_metrics),
            "skipped_counts": dict(result.skipped_counts),
            "warnings": [*result.warnings, *extra_warnings],
            "provenance": dict(result.provenance),
        }
        sanitized, sanitize_warnings = _sanitize_json(payload, "$")
        sanitized["warnings"] = [*sanitized["warnings"], *sanitize_warnings]
        text = json.dumps(sanitized, ensure_ascii=False, indent=2, allow_nan=False)
        path.write_text(text + "\n", encoding="utf-8")


def _trade_from_row(row: Mapping[str, Any]) -> TradeEvent:
    """Parquet 行 → 事件：枚举列恢复为枚举成员，可选列保持 None（读侧不做静默替换）。"""
    return TradeEvent(
        signal_time=row["signal_time"],
        execution_time=row["execution_time"],
        instrument_id=row["instrument_id"],
        side=row["side"],
        shares=row["shares"],
        base_price=row["base_price"],
        execution_price=row["execution_price"],
        amount=row["amount"],
        commission=row["commission"],
        stamp_tax=row["stamp_tax"],
        transfer_fee=row["transfer_fee"],
        slippage_cost=row["slippage_cost"],
        participation=row["participation"],
        status=row["status"],
        reason=row["reason"],
    )
