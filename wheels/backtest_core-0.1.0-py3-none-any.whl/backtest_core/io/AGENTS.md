# io - 存储层

结果文件写入 + `RunManifest` 元数据。pyarrow 只出现在此层（合约层无 parquet 依赖）。

## 关键约束

- `ResultStore.write` 分块写入 Parquet + 整目录原子换入（先写 temp dir，再 `os.replace`）。
- 文件布局：`<out>/{manifest.json, metrics.json, trades.parquet}`。
- `trades.parquet` 固定 15 列 schema（含不可成交事件的 null + reason 行）。
- `provenance["trades_location"]` 区分 account（`result`）与 paper（`paper_simulation`）。
- `RunManifest` 包含版本三元组 + `config_hash` + `data_fingerprint` + `methodology`。`methodology` 不同不得直接聚合。
- 默认 chunk 大小 `DEFAULT_CHUNK_SIZE`：超过阈值时分块写入，控制内存峰值。

## 不变量

- 原子换入保证：写入中途崩溃不会留下半成品目录。
- `metrics.json` 与 `trades.parquet` 必须一致（同一 batch 写入，要么都成功要么都不留）。
