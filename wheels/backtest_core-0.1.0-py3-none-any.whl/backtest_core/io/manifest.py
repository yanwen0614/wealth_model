"""运行清单（规格 §13 output 组 / §14.4 可追溯性）：版本三元组、数据血缘与口径随结果落盘。"""

from collections.abc import Mapping
from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Literal

from ..contracts.result import MetricMethodology
from ..contracts.validation import ensure_non_empty_str, ensure_tz_aware

__all__ = ["RunManifest"]

TradesLocation = Literal["result", "paper_simulation"]
ManifestLayer = Literal["signal", "paper", "account"]

_IDENTITY_FIELDS = ("schema_version", "engine_version", "policy_version", "run_id", "model_id", "config_hash")
_MISSING = object()


def _ensure_literal_member(value: str, allowed: tuple[str, ...], field_name: str) -> None:
    if value not in allowed:
        allowed_text = ", ".join(repr(item) for item in allowed)
        raise ValueError(f"{field_name} must be one of ({allowed_text}), got {value!r}")


def _require_field(payload: Mapping[str, Any], key: str) -> Any:
    value = payload.get(key, _MISSING)
    if value is _MISSING:
        raise ValueError(f"manifest payload is missing required field {key!r}")
    return value


@dataclass(frozen=True)
class RunManifest:
    """结果目录旁的可追溯清单：store 只消费不生成时间/指纹，同输入两次写入保持确定性（§3.4）。"""

    schema_version: str
    engine_version: str
    policy_version: str
    run_id: str
    model_id: str
    config_hash: str
    data_fingerprint: str
    methodology: MetricMethodology
    created_at: datetime
    trades_location: TradesLocation = "result"
    layer: ManifestLayer = "account"

    def __post_init__(self) -> None:
        for field_name in _IDENTITY_FIELDS:
            ensure_non_empty_str(getattr(self, field_name), field_name)
        # DataConfig.data_fingerprint 阶段 1 允许缺省（T04 推迟决策）；manifest 是最终消费点，
        # 血缘缺失即拒绝，否则结果无法与数据快照对应（规格 §14.4 迁移前检查项）。
        if not isinstance(self.data_fingerprint, str) or not self.data_fingerprint.strip():
            raise ValueError(
                "data_fingerprint must be a non-empty string: refusing to write a manifest without "
                f"data provenance, got {self.data_fingerprint!r}"
            )
        if not isinstance(self.methodology, MetricMethodology):
            raise ValueError(f"methodology must be a MetricMethodology, got {self.methodology!r}")  # noqa: TRY004
        ensure_tz_aware(self.created_at, "created_at")
        _ensure_literal_member(self.trades_location, ("result", "paper_simulation"), "trades_location")
        _ensure_literal_member(self.layer, ("signal", "paper", "account"), "layer")

    def to_dict(self) -> dict[str, Any]:
        """JSON 安全表示：methodology 展平为 dict、created_at 用带偏移 ISO8601（规格 §3.3）。"""
        return {
            "schema_version": self.schema_version,
            "engine_version": self.engine_version,
            "policy_version": self.policy_version,
            "run_id": self.run_id,
            "model_id": self.model_id,
            "config_hash": self.config_hash,
            "data_fingerprint": self.data_fingerprint,
            "methodology": asdict(self.methodology),
            "created_at": self.created_at.isoformat(),
            "trades_location": self.trades_location,
            "layer": self.layer,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "RunManifest":
        if not isinstance(payload, Mapping):
            raise ValueError(f"manifest payload must be a mapping, got {payload!r}")  # noqa: TRY004
        methodology_payload = _require_field(payload, "methodology")
        if not isinstance(methodology_payload, Mapping):
            raise ValueError(  # noqa: TRY004
                f"manifest methodology must be a mapping, got {methodology_payload!r}"
            )
        try:
            methodology = MetricMethodology(**methodology_payload)
        except TypeError as exc:  # 字段集不匹配（缺失/多余）在读取侧同样必须显式失败
            raise ValueError(f"manifest methodology is invalid: {exc}") from exc
        created_raw = _require_field(payload, "created_at")
        if not isinstance(created_raw, str):
            raise ValueError(f"manifest created_at must be an ISO8601 string, got {created_raw!r}")  # noqa: TRY004
        return cls(
            schema_version=_require_field(payload, "schema_version"),
            engine_version=_require_field(payload, "engine_version"),
            policy_version=_require_field(payload, "policy_version"),
            run_id=_require_field(payload, "run_id"),
            model_id=_require_field(payload, "model_id"),
            config_hash=_require_field(payload, "config_hash"),
            data_fingerprint=_require_field(payload, "data_fingerprint"),
            methodology=methodology,
            created_at=datetime.fromisoformat(created_raw),
            trades_location=_require_field(payload, "trades_location"),
            layer=_require_field(payload, "layer"),
        )
